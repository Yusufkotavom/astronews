---
title: "Careers"
description: "Berkarir di kotacom. Bukan hanya sekedar bekerja tapi kesempatan pengembangan diri Anda yang tidak terbatas!"
publishDate: "2025-06-21T17:12:41.000Z"
author: "Yusuf Bahtiyar"
image: "/images/asset/aHR0cHM6-BUKALAPAK.png"
draft: false
---

<p>Berkarir di kotacom. Bukan hanya sekedar bekerja tapi kesempatan pengembangan diri Anda yang tidak terbatas!</p>
