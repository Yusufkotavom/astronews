---
title: "Checkout"
description: ""
publishDate: "2025-06-05T15:05:06.000Z"
author: "Yusuf Bahtiyar"
image: "/images/asset/free-shipping.svg"
draft: false
---

<div data-block-name="woocommerce/checkout" > <div data-block-name="woocommerce/checkout-fields-block" > <div data-block-name="woocommerce/checkout-express-payment-block" ></div> <div data-block-name="woocommerce/checkout-contact-information-block" ></div> <div data-block-name="woocommerce/checkout-shipping-method-block" ></div> <div data-block-name="woocommerce/checkout-pickup-options-block" ></div> <div data-block-name="woocommerce/checkout-shipping-address-block" ></div> <div data-block-name="woocommerce/checkout-billing-address-block" ></div> <div data-block-name="woocommerce/checkout-shipping-methods-block" ></div> <div data-block-name="woocommerce/checkout-payment-block" ></div> <div data-block-name="woocommerce/checkout-additional-information-block" ></div> <div data-block-name="woocommerce/checkout-order-note-block" ></div> <div data-block-name="woocommerce/checkout-terms-block" ></div> <div data-block-name="woocommerce/checkout-actions-block" ></div> </div> <div data-block-name="woocommerce/checkout-totals-block" > <div data-block-name="woocommerce/checkout-order-summary-block" > <div data-block-name="woocommerce/checkout-order-summary-cart-items-block" ></div><div data-block-name="woocommerce/checkout-order-summary-coupon-form-block" ></div><div data-block-name="woocommerce/checkout-order-summary-totals-block" > <div data-block-name="woocommerce/checkout-order-summary-subtotal-block" ></div> <div data-block-name="woocommerce/checkout-order-summary-discount-block" ></div> <div data-block-name="woocommerce/checkout-order-summary-fee-block" ></div> <div data-block-name="woocommerce/checkout-order-summary-shipping-block" ></div> <div data-block-name="woocommerce/checkout-order-summary-taxes-block" ></div></div> </div> </div> </div>
