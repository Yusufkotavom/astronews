import { defineCollection, z } from 'astro:content';

// Define the post collection schema - handle null tags
const post = defineCollection({
  schema: z.object({
    title: z.string(),
    description: z.string().optional(),
    author: z.string().optional(),
    publishDate: z.string().optional(),
    category: z.string().optional(),
    tags: z.union([z.array(z.string()), z.string(), z.null()]).optional().default([]), // Handle null values
    image: z.string().optional(),
    draft: z.boolean().optional().default(false),
    featured: z.boolean().optional().default(false),
  }).passthrough(), // Allow additional fields
});

// Define the page collection schema
const page = defineCollection({
  schema: z.object({
    title: z.string(),
    description: z.string().optional(),
    author: z.string().optional(),
    publishDate: z.string().optional(),
    category: z.string().optional(),
    image: z.string().optional(),
    draft: z.boolean().optional().default(false),
    featured: z.boolean().optional().default(false),
  }).passthrough(), // Allow additional fields
});

// Export the collections
export const collections = {
  post,
  page,
}; 