// SEO Helper Utility for WordPress Content
export interface SEOData {
  title: string;
  description: string;
  canonical: string;
  author?: string;
  publishDate?: string;
  updateDate?: string;
  image?: string;
  imageAlt?: string;
  category?: string;
  tags?: string[];
  type: 'post' | 'page' | 'category' | 'tag' | 'author';
  schemaMarkup?: string;
  robots?: string;
  socialTitle?: string;
  socialDescription?: string;
  socialImage?: string;
  socialType?: string;
}

// Interface for JSON-based SEO data
export interface JSONSEOData {
  seo_meta?: {
    seo_data?: {
      metadata?: {
        meta_title?: string;
        meta_description?: string;
        canonical_url?: string;
      };
      schema_markup?: {
        json_ld_script?: string;
      };
    };
  };
  business?: {
    type?: string;
    address?: string;
    phone?: string;
    description?: string;
  };
  hero?: {
    title?: string;
    subtitle?: string;
    image_url?: string;
  };
}

// Generate SEO data from JSON files (for service pages)
export function generateJSONSEO(jsonData: JSONSEOData, baseUrl: string = 'https://www.kotacom.id'): SEOData {
  const seoMeta = jsonData.seo_meta?.seo_data;
  const business = jsonData.business;
  const hero = jsonData.hero;

  // Use JSON SEO data if available, otherwise fall back to business data
  const title = seoMeta?.metadata?.meta_title || 
                hero?.title || 
                `${business?.type || 'Service'} - Kotacom`;
  
  const description = seoMeta?.metadata?.meta_description || 
                     hero?.subtitle || 
                     business?.description || 
                     'Professional services from Kotacom';
  
  const canonical = seoMeta?.metadata?.canonical_url || baseUrl;
  const image = hero?.image_url || '/og-image.jpg';
  const schemaMarkup = seoMeta?.schema_markup?.json_ld_script;

  return {
    title,
    description: description.length > 160 ? description.substring(0, 157) + '...' : description,
    canonical,
    image,
    imageAlt: title,
    type: 'page',
    schemaMarkup,
    robots: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1',
    socialTitle: title,
    socialDescription: description,
    socialImage: image,
    socialType: 'website'
  };
}

// Generate SEO data for WordPress posts
export function generatePostSEO(post: any, baseUrl: string = 'https://www.kotacom.id'): SEOData {
  const title = post.data.title || 'Untitled Post';
  const description = post.data.description || post.data.excerpt || 'Read our latest article';
  const canonical = `${baseUrl}/${post.slug}`;
  const publishDate = post.data.publishDate || post.data.date;
  const updateDate = post.data.updateDate;
  const author = post.data.author || 'Kotacom Team';
  const category = post.data.category;
  const tags = post.data.tags || [];
  const image = post.data.image || '/og-image.jpg';
  const imageAlt = post.data.imageAlt || title;

  // Generate schema markup for blog post
  const schemaMarkup = generateBlogPostSchema({
    title,
    description,
    url: canonical,
    author,
    publishDate,
    updateDate,
    image,
    imageAlt,
    category,
    tags
  });

  return {
    title: `${title} - Blog - Kotacom`,
    description: description.length > 160 ? description.substring(0, 157) + '...' : description,
    canonical,
    author,
    publishDate,
    updateDate,
    image,
    imageAlt,
    category,
    tags,
    type: 'post',
    schemaMarkup: JSON.stringify(schemaMarkup),
    robots: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1',
    socialTitle: title,
    socialDescription: description,
    socialImage: image,
    socialType: 'article'
  };
}

// Generate SEO data for WordPress pages
export function generatePageSEO(page: any, baseUrl: string = 'https://www.kotacom.id'): SEOData {
  const title = page.data.title || 'Untitled Page';
  const description = page.data.description || page.data.excerpt || 'Visit our page';
  const canonical = `${baseUrl}/${page.slug}`;
  const publishDate = page.data.publishDate || page.data.date;
  const updateDate = page.data.updateDate;
  const image = page.data.image || '/og-image.jpg';
  const imageAlt = page.data.imageAlt || title;

  // Generate schema markup for web page
  const schemaMarkup = generateWebPageSchema({
    title,
    description,
    url: canonical,
    publishDate,
    updateDate,
    image,
    imageAlt
  });

  return {
    title: `${title} - Kotacom`,
    description: description.length > 160 ? description.substring(0, 157) + '...' : description,
    canonical,
    publishDate,
    updateDate,
    image,
    imageAlt,
    type: 'page',
    schemaMarkup: JSON.stringify(schemaMarkup),
    robots: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1',
    socialTitle: title,
    socialDescription: description,
    socialImage: image,
    socialType: 'website'
  };
}

// Generate SEO data for category pages
export function generateCategorySEO(category: string, posts: any[], baseUrl: string = 'https://www.kotacom.id'): SEOData {
  const title = `${category} Articles`;
  const description = `Read our latest articles about ${category.toLowerCase()}. Discover insights, tips, and best practices.`;
  const canonical = `${baseUrl}/category/${category.toLowerCase()}`;
  const image = '/og-image.jpg';

  // Generate schema markup for collection page
  const schemaMarkup = generateCollectionPageSchema({
    title,
    description,
    url: canonical,
    category,
    posts: posts.slice(0, 10) // Limit to first 10 posts for schema
  });

  return {
    title: `${title} - Blog - Kotacom`,
    description,
    canonical,
    image,
    type: 'category',
    schemaMarkup: JSON.stringify(schemaMarkup),
    robots: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1',
    socialTitle: title,
    socialDescription: description,
    socialImage: image,
    socialType: 'website'
  };
}

// Generate SEO data for tag pages
export function generateTagSEO(tag: string, posts: any[], baseUrl: string = 'https://www.kotacom.id'): SEOData {
  const title = `Articles tagged "${tag}"`;
  const description = `Browse our articles tagged with "${tag}". Find relevant content and insights.`;
  const canonical = `${baseUrl}/tag/${tag.toLowerCase()}`;
  const image = '/og-image.jpg';

  // Generate schema markup for collection page
  const schemaMarkup = generateCollectionPageSchema({
    title,
    description,
    url: canonical,
    category: tag,
    posts: posts.slice(0, 10) // Limit to first 10 posts for schema
  });

  return {
    title: `${title} - Blog - Kotacom`,
    description,
    canonical,
    image,
    type: 'tag',
    schemaMarkup: JSON.stringify(schemaMarkup),
    robots: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1',
    socialTitle: title,
    socialDescription: description,
    socialImage: image,
    socialType: 'website'
  };
}

// Generate SEO data for author pages
export function generateAuthorSEO(author: string, posts: any[], baseUrl: string = 'https://www.kotacom.id'): SEOData {
  const title = `Articles by ${author}`;
  const description = `Read all articles written by ${author}. Discover insights and expertise.`;
  const canonical = `${baseUrl}/author/${author.toLowerCase().replace(/\s+/g, '-')}`;
  const image = '/og-image.jpg';

  // Generate schema markup for author page
  const schemaMarkup = generateAuthorPageSchema({
    title,
    description,
    url: canonical,
    author,
    posts: posts.slice(0, 10) // Limit to first 10 posts for schema
  });

  return {
    title: `${title} - Blog - Kotacom`,
    description,
    canonical,
    author,
    image,
    type: 'author',
    schemaMarkup: JSON.stringify(schemaMarkup),
    robots: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1',
    socialTitle: title,
    socialDescription: description,
    socialImage: image,
    socialType: 'profile'
  };
}

// Schema markup generators
function generateBlogPostSchema(data: {
  title: string;
  description: string;
  url: string;
  author: string;
  publishDate?: string;
  updateDate?: string;
  image?: string;
  imageAlt?: string;
  category?: string;
  tags?: string[];
}) {
  return {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "headline": data.title,
    "description": data.description,
    "url": data.url,
    "author": {
      "@type": "Person",
      "name": data.author
    },
    "publisher": {
      "@type": "Organization",
      "name": "Kotacom",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.kotacom.id/logo-full.svg"
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": data.url
    },
    "datePublished": data.publishDate,
    "dateModified": data.updateDate || data.publishDate,
    "image": data.image ? {
      "@type": "ImageObject",
      "url": data.image,
      "alt": data.imageAlt
    } : undefined,
    "articleSection": data.category,
    "keywords": data.tags?.join(', '),
    "wordCount": data.description.length
  };
}

function generateWebPageSchema(data: {
  title: string;
  description: string;
  url: string;
  publishDate?: string;
  updateDate?: string;
  image?: string;
  imageAlt?: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "headline": data.title,
    "description": data.description,
    "url": data.url,
    "publisher": {
      "@type": "Organization",
      "name": "Kotacom",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.kotacom.id/logo-full.svg"
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": data.url
    },
    "datePublished": data.publishDate,
    "dateModified": data.updateDate || data.publishDate,
    "image": data.image ? {
      "@type": "ImageObject",
      "url": data.image,
      "alt": data.imageAlt
    } : undefined
  };
}

function generateCollectionPageSchema(data: {
  title: string;
  description: string;
  url: string;
  category: string;
  posts: any[];
}) {
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "headline": data.title,
    "description": data.description,
    "url": data.url,
    "publisher": {
      "@type": "Organization",
      "name": "Kotacom",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.kotacom.id/logo-full.svg"
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": data.url
    },
    "about": {
      "@type": "Thing",
      "name": data.category
    },
    "hasPart": data.posts.map(post => ({
      "@type": "BlogPosting",
      "headline": post.data.title,
      "url": `https://www.kotacom.id/${post.slug}`
    }))
  };
}

function generateAuthorPageSchema(data: {
  title: string;
  description: string;
  url: string;
  author: string;
  posts: any[];
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Person",
    "name": data.author,
    "url": data.url,
    "description": data.description,
    "worksFor": {
      "@type": "Organization",
      "name": "Kotacom"
    },
    "author": data.posts.map(post => ({
      "@type": "BlogPosting",
      "headline": post.data.title,
      "url": `https://www.kotacom.id/${post.slug}`
    }))
  };
}

// Utility function to generate breadcrumb schema
export function generateBreadcrumbSchema(items: Array<{ name: string; url: string }>, baseUrl: string = 'https://www.kotacom.id') {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": items.map((item, index) => ({
      "@type": "ListItem",
      "position": index + 1,
      "name": item.name,
      "item": item.url.startsWith('http') ? item.url : `${baseUrl}${item.url}`
    }))
  };
}

// Utility function to generate organization schema
export function generateOrganizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Kotacom",
    "url": "https://www.kotacom.id",
    "logo": "https://www.kotacom.id/logo-full.svg",
    "description": "Professional web development services for your business. We create modern, responsive websites that help you grow your online presence.",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Bekasi",
      "addressRegion": "West Java",
      "addressCountry": "ID"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+62-857-9952-0350",
      "contactType": "customer service",
      "availableLanguage": "Indonesian, English"
    },
    "sameAs": [
      "https://www.facebook.com/kotacom",
      "https://www.instagram.com/kotacom",
      "https://www.linkedin.com/company/kotacom"
    ]
  };
}

// Utility function to generate website schema
export function generateWebsiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "Kotacom",
    "url": "https://www.kotacom.id",
    "description": "Professional web development services for your business",
    "publisher": {
      "@type": "Organization",
      "name": "Kotacom"
    },
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://www.kotacom.id/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };
}