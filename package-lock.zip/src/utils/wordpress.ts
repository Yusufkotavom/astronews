/**
 * WordPress API utilities for Astro
 * Handles fetching posts, pages, and other content from WordPress
 */

// WordPress API configuration
const WORDPRESS_URL = import.meta.env.WORDPRESS_URL || 'https://www.kotacom.id';
const WORDPRESS_API_BASE = `${WORDPRESS_URL}/wp-json/wp/v2`;

// Cache for API responses
const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

/**
 * Fetch data from WordPress API with caching
 */
async function fetchWithCache(endpoint: string): Promise<any> {
  const cacheKey = endpoint;
  const cached = cache.get(cacheKey);
  
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.data;
  }

  try {
    const response = await fetch(`${WORDPRESS_API_BASE}${endpoint}`, {
      headers: {
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(8000), // 8 second timeout
    });

    if (!response.ok) {
      throw new Error(`WordPress API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    // Cache the response
    cache.set(cacheKey, {
      data,
      timestamp: Date.now()
    });

    return data;
  } catch (error) {
    console.error(`Error fetching from WordPress API (${endpoint}):`, error);
    throw error;
  }
}

/**
 * Fetch WordPress posts
 */
export async function fetchWordPressPosts(params: {
  per_page?: number;
  page?: number;
  category?: number;
  search?: string;
} = {}): Promise<any[]> {
  try {
    const searchParams = new URLSearchParams({
      per_page: (params.per_page || 10).toString(),
      page: (params.page || 1).toString(),
      _embed: '1', // Include featured images and authors
      status: 'publish',
      ...(params.category && { categories: params.category.toString() }),
      ...(params.search && { search: params.search }),
    });

    return await fetchWithCache(`/posts?${searchParams.toString()}`);
  } catch (error) {
    console.error('Error fetching WordPress posts:', error);
    return [];
  }
}

/**
 * Fetch WordPress pages
 */
export async function fetchWordPressPages(params: {
  per_page?: number;
  page?: number;
  search?: string;
} = {}): Promise<any[]> {
  try {
    const searchParams = new URLSearchParams({
      per_page: (params.per_page || 10).toString(),
      page: (params.page || 1).toString(),
      _embed: '1', // Include featured images and authors
      status: 'publish',
      ...(params.search && { search: params.search }),
    });

    return await fetchWithCache(`/pages?${searchParams.toString()}`);
  } catch (error) {
    console.error('Error fetching WordPress pages:', error);
    return [];
  }
}

/**
 * Fetch a single WordPress post by slug
 */
export async function fetchWordPressPost(slug: string): Promise<any | null> {
  try {
    const posts = await fetchWithCache(`/posts?slug=${slug}&_embed=1`);
    return posts.length > 0 ? posts[0] : null;
  } catch (error) {
    console.error(`Error fetching WordPress post (${slug}):`, error);
    return null;
  }
}

/**
 * Fetch a single WordPress page by slug
 */
export async function fetchWordPressPage(slug: string): Promise<any | null> {
  try {
    const pages = await fetchWithCache(`/pages?slug=${slug}&_embed=1`);
    return pages.length > 0 ? pages[0] : null;
  } catch (error) {
    console.error(`Error fetching WordPress page (${slug}):`, error);
    return null;
  }
}

/**
 * Fetch WordPress categories
 */
export async function fetchWordPressCategories(): Promise<any[]> {
  try {
    return await fetchWithCache('/categories?per_page=100');
  } catch (error) {
    console.error('Error fetching WordPress categories:', error);
    return [];
  }
}

/**
 * Fetch WordPress tags
 */
export async function fetchWordPressTags(): Promise<any[]> {
  try {
    return await fetchWithCache('/tags?per_page=100');
  } catch (error) {
    console.error('Error fetching WordPress tags:', error);
    return [];
  }
}

/**
 * Search WordPress content
 */
export async function searchWordPressContent(query: string, type: 'posts' | 'pages' | 'both' = 'both'): Promise<any[]> {
  try {
    const results = [];
    
    if (type === 'posts' || type === 'both') {
      const posts = await fetchWordPressPosts({ search: query, per_page: 20 });
      results.push(...posts.map((post: any) => ({ ...post, _type: 'post' })));
    }
    
    if (type === 'pages' || type === 'both') {
      const pages = await fetchWordPressPages({ search: query, per_page: 20 });
      results.push(...pages.map((page: any) => ({ ...page, _type: 'page' })));
    }
    
    return results;
  } catch (error) {
    console.error('Error searching WordPress content:', error);
    return [];
  }
}

/**
 * Clear the cache
 */
export function clearWordPressCache(): void {
  cache.clear();
}

/**
 * Get cache statistics
 */
export function getWordPressCacheStats(): { size: number; entries: string[] } {
  return {
    size: cache.size,
    entries: Array.from(cache.keys())
  };
}

/**
 * Check if WordPress API is available
 */
export async function checkWordPressHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/`, {
      signal: AbortSignal.timeout(5000),
    });
    return response.ok;
  } catch (error) {
    console.error('WordPress API health check failed:', error);
    return false;
  }
} 