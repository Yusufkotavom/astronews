# 🔧 Environment Setup Guide

This guide will help you set up your environment variables for the Astro Kotacom project.

## 🚀 Quick Setup

### Step 1: Copy the example file

```bash
cp env.example .env
```

### Step 2: Configure WordPress (Required)

Edit your `.env` file and set your WordPress URL:

```env
WORDPRESS_SITE_URL=https://your-wordpress-site.com
```

### Step 3: Choose Image Strategy

#### Option A: Keep Original URLs (Recommended)
```env
KEEP_ORIGINAL_URLS=true
DOWNLOAD_IMAGES=false
```

#### Option B: Use Cloudinary (Recommended for optimization)
```env
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_STRATEGY=url-only
```

#### Option C: Use Cloudflare
```env
CLOUDFLARE_DOMAIN=images.yourdomain.com
CLOUDFLARE_STRATEGY=cdn
```

## 📋 Required Settings

### WordPress Configuration
```env
WORDPRESS_SITE_URL=https://kotacom.id
```

### Image Configuration (Choose one)
```env
# Option 1: Keep original URLs
KEEP_ORIGINAL_URLS=true
DOWNLOAD_IMAGES=false

# Option 2: Cloudinary
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_STRATEGY=url-only

# Option 3: Cloudflare
CLOUDFLARE_DOMAIN=images.kotacom.id
CLOUDFLARE_STRATEGY=cdn
```

## 🔧 Optional Settings

### Development
```env
NODE_ENV=development
PORT=4321
```

### SEO
```env
SITE_TITLE=Kotacom - Jasa IT & Percetakan
SITE_DESCRIPTION=Jasa IT, percetakan, dan layanan teknologi terpercaya
SITE_URL=https://kotacom.id
```

### Analytics
```env
GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
GTM_ID=GTM-XXXXXXX
```

## 🧪 Testing Your Configuration

### Test WordPress Connection
```bash
npm run wordpress:test
```

### Test Image Configuration
```bash
npm run wordpress:test-images
```

### Test Cloudinary Setup
```bash
npm run cloudinary:test-demo
```

### Test Cloudflare Setup
```bash
npm run cloudflare:test-demo
```

## 🔒 Security Notes

1. **Never commit `.env` file** to version control
2. **Use strong API keys** for Cloudinary/Cloudflare
3. **Rotate keys regularly** for security
4. **Keep backups** of your configuration

## 🆘 Troubleshooting

### WordPress Connection Issues
- Check if WordPress REST API is enabled
- Verify the site URL is correct
- Ensure the site is accessible

### Image Loading Issues
- Check image URLs in browser
- Verify Cloudinary/Cloudflare configuration
- Test with different image formats

### Environment Variables Not Loading
- Restart your development server
- Check for typos in variable names
- Ensure `.env` file is in project root

## 📞 Support

- **WordPress Issues**: Check WordPress REST API documentation
- **Cloudinary Issues**: Visit [Cloudinary Support](https://support.cloudinary.com)
- **Cloudflare Issues**: Visit [Cloudflare Support](https://support.cloudflare.com)
- **Astro Issues**: Visit [Astro Documentation](https://docs.astro.build)

---

**Next Steps**: After setting up your `.env` file, run `npm run dev` to start development! 