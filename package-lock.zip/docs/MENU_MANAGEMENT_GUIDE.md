# Menu Management Guide

This guide explains how to edit and manage the main navigation menu for both desktop and mobile views.

## 📋 Overview

The main menu is now managed through the `src/data/main_menu.json` file, which allows you to:
- ✅ **Edit menu items** without touching code
- ✅ **Add/remove menu items** easily
- ✅ **Manage submenus** and nested navigation
- ✅ **Update WhatsApp** contact information
- ✅ **Customize brand** information

## 🗂️ File Structure

```
src/
├── data/
│   └── main_menu.json          # Main menu configuration
├── components/
│   └── partials/
│       └── Navbar.astro        # Navigation component
└── scripts/
    └── update-menu.js          # Menu update script
```

## 📝 Editing the Menu

### 1. Edit `src/data/main_menu.json`

The menu structure follows this format:

```json
{
  "menu_items": [
    {
      "title": "Menu Item Name",
      "url": "/menu-url",
      "icon": "icon-name",
      "submenu": [
        {
          "title": "Submenu Item",
          "url": "/submenu-url",
          "icon": "submenu-icon"
        }
      ]
    }
  ],
  "whatsapp": {
    "number": "085799520350",
    "message": "Halo! Saya tertarik dengan jasa pembuatan website Anda."
  },
  "brand": {
    "name": "Kotacom",
    "logo_light": "/logo-full.svg",
    "logo_dark": "/logo-full-dark.svg"
  }
}
```

### 2. Menu Item Properties

| Property | Type | Description | Required |
|----------|------|-------------|----------|
| `title` | string | Display name of menu item | ✅ Yes |
| `url` | string | Link URL (relative or absolute) | ✅ Yes |
| `icon` | string | Icon identifier (for future use) | ✅ Yes |
| `submenu` | array | Array of submenu items | ❌ No |

### 3. Submenu Structure

Submenus can be nested up to 2 levels:

```json
{
  "title": "Services",
  "url": "/services",
  "icon": "services",
  "submenu": [
    {
      "title": "All Services",
      "url": "/services",
      "icon": "web",
      "submenu": [
        {
          "title": "Web Development",
          "url": "/services/website",
          "icon": "website"
        }
      ]
    }
  ]
}
```

## 🔄 Updating the Menu

### Method 1: Using the Script (Recommended)

1. **Edit the JSON file**: Modify `src/data/main_menu.json`
2. **Run the update script**:
   ```bash
   npm run menu:update
   ```
3. **Build the site**:
   ```bash
   npm run build
   ```

### Method 2: Manual Update

1. **Edit the JSON file**: Modify `src/data/main_menu.json`
2. **Manually update the component**: Edit `src/components/partials/Navbar.astro`
3. **Build the site**:
   ```bash
   npm run build
   ```

## 📱 Menu Display

### Desktop Menu
- **Main navigation**: Horizontal menu bar
- **Dropdown menus**: Hover to reveal submenus
- **Responsive**: Adapts to screen size

### Mobile Menu
- **Hamburger menu**: Tap to open full-screen menu
- **Accordion submenus**: Tap to expand/collapse
- **Touch-friendly**: Large touch targets

## 🎨 Menu Features

### Dark Mode Support
- ✅ **Automatic adaptation** to dark/light themes
- ✅ **Consistent styling** across all menu items
- ✅ **Smooth transitions** between themes

### Responsive Design
- ✅ **Mobile-first** approach
- ✅ **Touch-friendly** interface
- ✅ **Accessible** navigation

### Interactive Elements
- ✅ **Hover effects** on desktop
- ✅ **Smooth animations** for submenus
- ✅ **Focus indicators** for accessibility

## 📋 Current Menu Structure

Based on your `main_menu.json`:

### Main Menu Items
1. **Home** (`/`)
   - Dashboard (`/`)
   - Features (`/features`)
   - Showcase (`/showcase`)

2. **Services** (`/services`)
   - All Services (`/services`)
   - Portfolio (`/portfolio`)
   - jasa pembuatan website (`/services/website`)
   - Jasa Pembuatan Software (`/services/software`)

3. **Blog** (`/blog`)
   - All Posts (`/blog`)
   - Featured Posts (`/blog/featured`)

4. **Pricing** (`/pricing`)
   - Website Packages (`/pricing/`)
   - E-Commerce Plans (`/pricing/ecommerce`)
   - Maintenance Plans (`/pricing/maintenance`)
   - Custom Quote (`/pricing/custom`)

5. **About** (`/about`)
   - Contact (`/contact`)
   - Technical Support (`/contact/support`)
   - Request Quote (`/contact/quote`)
   - Our Location (`/contact/location`)

## 🔧 Configuration Options

### WhatsApp Settings
```json
{
  "whatsapp": {
    "number": "085799520350",
    "message": "Halo! Saya tertarik dengan jasa pembuatan website Anda."
  }
}
```

### Brand Settings
```json
{
  "brand": {
    "name": "Kotacom",
    "logo_light": "/logo-full.svg",
    "logo_dark": "/logo-full-dark.svg"
  }
}
```

## 🚀 Commands Reference

### Menu Management
```bash
# Update menu from JSON file
npm run menu:update

# Build site with updated menu
npm run build

# Development server
npm run dev
```

### Troubleshooting
```bash
# Clean build artifacts
npm run clean

# Rebuild everything
npm run clean && npm run build
```

## 📝 Examples

### Adding a New Menu Item
```json
{
  "title": "Contact",
  "url": "/contact",
  "icon": "contact"
}
```

### Adding a Menu with Submenu
```json
{
  "title": "Services",
  "url": "/services",
  "icon": "services",
  "submenu": [
    {
      "title": "Web Development",
      "url": "/services/web",
      "icon": "web"
    },
    {
      "title": "Mobile Apps",
      "url": "/services/mobile",
      "icon": "mobile"
    }
  ]
}
```

### Adding Nested Submenus
```json
{
  "title": "Services",
  "url": "/services",
  "icon": "services",
  "submenu": [
    {
      "title": "Development",
      "url": "/services/development",
      "icon": "dev",
      "submenu": [
        {
          "title": "Web Development",
          "url": "/services/web",
          "icon": "web"
        },
        {
          "title": "Mobile Development",
          "url": "/services/mobile",
          "icon": "mobile"
        }
      ]
    }
  ]
}
```

## ⚠️ Important Notes

### URL Format
- **Internal links**: Use relative URLs (e.g., `/about`, `/services`)
- **External links**: Use full URLs (e.g., `https://example.com`)
- **Anchor links**: Use hash URLs (e.g., `/#section`)

### Icon Names
- Icons are currently for future use
- Use descriptive names (e.g., `home`, `services`, `contact`)
- Avoid special characters or spaces

### Menu Limits
- **Maximum depth**: 2 levels (main menu → submenu → sub-submenu)
- **Recommended items**: 5-7 main menu items
- **Submenu items**: 3-5 items per submenu

## 🔍 Troubleshooting

### Menu Not Updating
1. **Check JSON syntax**: Ensure valid JSON format
2. **Run update script**: `npm run menu:update`
3. **Rebuild site**: `npm run build`
4. **Clear cache**: `npm run clean`

### Build Errors
1. **Check file paths**: Ensure URLs are correct
2. **Validate JSON**: Use a JSON validator
3. **Check component**: Verify Navbar.astro syntax

### Mobile Menu Issues
1. **Test touch targets**: Ensure items are tappable
2. **Check animations**: Verify smooth transitions
3. **Test accessibility**: Ensure keyboard navigation works

## 📞 Support

If you encounter issues:
1. **Check the console** for error messages
2. **Validate your JSON** using a JSON validator
3. **Test the menu** on different devices
4. **Review the examples** above for guidance

---

*This guide covers all aspects of menu management. For additional help, refer to the examples or contact support.* 