# Jinja2 Template Fields Documentation

This document lists all available Jinja2 template fields from the `base.jinja` template, organized by sections.

## 📋 Table of Contents
- [SEO & Meta Tags](#seo--meta-tags)
- [Business Information](#business-information)
- [Hero Section](#hero-section)
- [Features Section](#features-section)
- [About Us Section](#about-us-section)
- [Services Section](#services-section)
- [Why Us Section](#why-us-section)
- [What You Get Section](#what-you-get-section)
- [Why Need Section](#why-need-section)
- [Pricing Section](#pricing-section)
- [Portfolio Section](#portfolio-section)
- [Case Studies Section](#case-studies-section)
- [Testimonials Section](#testimonials-section)
- [FAQ Section](#faq-section)
- [Content Section](#content-section)
- [Local Coverage Section](#local-coverage-section)
- [Kabupaten/Kota Section](#kabupatenkota-section)
- [Final CTA Section](#final-cta-section)
- [Generated Images Metadata](#generated-images-metadata)

---

## 🔍 SEO & Meta Tags

### Meta Tags
```jinja
{{seo_meta.seo_data.metadata.meta_title}}
{{seo_meta.seo_data.metadata.meta_description}}
{{seo_meta.seo_data.metadata.canonical_url}}
```

### Schema Markup
```jinja
{{seo_meta.seo_data.schema_markup.json_ld_script}}
```

### Open Graph Tags
```jinja
{{business.type}}
{{business.description}}
{{business.phone}}
{{business.address}}
```

---

## 🏢 Business Information

### Basic Info
```jinja
{{business.type}}
{{business.description}}
{{business.phone}}
{{business.address}}
```

---

## 🎯 Hero Section

### Main Content
```jinja
{{hero.badge_text}}
{{hero.title}}
{{hero.subtitle}}
{{hero.image_url}}
```

### Hero Features (4 items)
```jinja
{{hero.feature[0].point}}
{{hero.feature[0].description}}

{{hero.feature[1].point}}
{{hero.feature[1].description}}

{{hero.feature[2].point}}
{{hero.feature[2].description}}

{{hero.feature[3].point}}
{{hero.feature[3].description}}
```

---

## ⚡ Features Section

### Section Header
```jinja
{{features.badge_text}}
{{features.title}}
{{features.subtitle}}
{{features.image_url}}
```

### Feature Cards (6 items)
```jinja
{{features.point[0].title}}
{{features.point[0].description}}

{{features.point[1].title}}
{{features.point[1].description}}

{{features.point[2].title}}
{{features.point[2].description}}

{{features.point[3].title}}
{{features.point[3].description}}

{{features.point[4].title}}
{{features.point[4].description}}

{{features.point[5].title}}
{{features.point[5].description}}
```

---

## ℹ️ About Us Section

### Section Content
```jinja
{{info.img_alt}}
{{info.badge_text}}
{{info.title}}
{{info.subtitle}}
{{info.description}}
{{info.image_url}}
```

### About Points (5 items)
```jinja
{{info.point[0]}}
{{info.point[1]}}
{{info.point[2]}}
{{info.point[3]}}
{{info.point[4]}}
```

---

## 🛠️ Services Section

### Section Header
```jinja
{{services.badge_text}}
{{services.title}}
{{services.subtitle}}
```

### Service Cards (3 items)
```jinja
{{services.point[0].title}}
{{services.point[0].description}}
{{services.point[0].feature[0]}}
{{services.point[0].feature[1]}}
{{services.point[0].feature[2]}}
{{services.point[0].feature[3]}}
{{services.point[0].feature[4]}}

{{services.point[1].title}}
{{services.point[1].description}}
{{services.point[1].feature[0]}}
{{services.point[1].feature[1]}}
{{services.point[1].feature[2]}}
{{services.point[1].feature[3]}}
{{services.point[1].feature[4]}}

{{services.point[2].title}}
{{services.point[2].description}}
{{services.point[2].feature[0]}}
{{services.point[2].feature[1]}}
{{services.point[2].feature[2]}}
{{services.point[2].feature[3]}}
{{services.point[2].feature[4]}}
```

---

## 💪 Why Us Section

### Section Content
```jinja
{{why_us.badge_text}}
{{why_us.title}}
{{why_us.subtitle}}
{{why_us.description}}
```

### Why Us Cards (4 items)
```jinja
{{why_us.point[0].title}}
{{why_us.point[0].description}}

{{why_us.point[1].title}}
{{why_us.point[1].description}}

{{why_us.point[2].title}}
{{why_us.point[2].description}}

{{why_us.point[3].title}}
{{why_us.point[3].description}}
```

---

## 🎁 What You Get Section

### Section Header
```jinja
{{what_you_get.title}}
{{what_you_get.subtitle}}
```

### Benefit Cards (4 items)
```jinja
{{what_you_get.points[0].title}}
{{what_you_get.points[0].description}}

{{what_you_get.points[1].title}}
{{what_you_get.points[1].description}}

{{what_you_get.points[2].title}}
{{what_you_get.points[2].description}}

{{what_you_get.points[3].title}}
{{what_you_get.points[3].description}}
```

---

## 🤔 Why Need Section

### Section Content
```jinja
{{why_need.badge_text}}
{{why_need.title}}
{{why_need.subtitle}}
{{why_need.description}}
```

### Reason Cards (3 items)
```jinja
{{why_need.point[0].title}}
{{why_need.point[0].description}}

{{why_need.point[1].title}}
{{why_need.point[1].description}}

{{why_need.point[2].title}}
{{why_need.point[2].description}}
```

---

## 💰 Pricing Section

### Section Header
```jinja
{{pricing.badge_text}}
{{pricing.title}}
{{pricing.description}}
```

### Pricing Plan 1 (Basic)
```jinja
{{pricing.plan[0].badge}}
{{pricing.plan[0].title}}
{{pricing.plan[0].price}}
{{pricing.plan[0].description}}
{{pricing.plan[0].feature[0]}}
{{pricing.plan[0].feature[1]}}
{{pricing.plan[0].feature[2]}}
{{pricing.plan[0].feature[3]}}
{{pricing.plan[0].feature[4]}}
{{pricing.plan[0].feature[5]}}
{{pricing.plan[0].feature[6]}}
```

### Pricing Plan 2 (Standard)
```jinja
{{pricing.plan[1].badge}}
{{pricing.plan[1].title}}
{{pricing.plan[1].price}}
{{pricing.plan[1].description}}
{{pricing.plan[1].feature[0]}}
{{pricing.plan[1].feature[1]}}
{{pricing.plan[1].feature[2]}}
{{pricing.plan[1].feature[3]}}
{{pricing.plan[1].feature[4]}}
{{pricing.plan[1].feature[5]}}
{{pricing.plan[1].feature[6]}}
{{pricing.plan[1].feature[7]}}
```

### Pricing Plan 3 (Premium)
```jinja
{{pricing.plan[2].badge}}
{{pricing.plan[2].title}}
{{pricing.plan[2].price}}
{{pricing.plan[2].description}}
{{pricing.plan[2].feature[0]}}
{{pricing.plan[2].feature[1]}}
{{pricing.plan[2].feature[2]}}
{{pricing.plan[2].feature[3]}}
{{pricing.plan[2].feature[4]}}
{{pricing.plan[2].feature[5]}}
{{pricing.plan[2].feature[6]}}
{{pricing.plan[2].feature[7]}}
{{pricing.plan[2].feature[8]}}
```

---

## 📁 Portfolio Section

### Section Header
```jinja
{{portfolio.title}}
{{portfolio.description}}
```

### Portfolio Items (3 items)
```jinja
{{portfolio.list[0].type}}
{{portfolio.list[0].title}}
{{portfolio.list[0].description}}

{{portfolio.list[1].type}}
{{portfolio.list[1].title}}
{{portfolio.list[1].description}}

{{portfolio.list[2].type}}
{{portfolio.list[2].title}}
{{portfolio.list[2].description}}
```

---

## 📊 Case Studies Section

### Section Header
```jinja
{{case.badge_text}}
{{case.title}}
{{case.description}}
```

### Case Study Cards (2 items)
```jinja
{{case.list[0].type}}
{{case.list[0].title}}
{{case.list[0].description}}

{{case.list[1].type}}
{{case.list[1].title}}
{{case.list[1].description}}
```

---

## 💬 Testimonials Section

### Section Header
```jinja
{{testimonials.badge_text}}
{{testimonials.title}}
{{testimonials.subtitle}}
```

### Testimonial Cards (3 items)
```jinja
{{testimonials.card[0].headline}}
{{testimonials.card[0].quote}}
{{testimonials.card[0].name}}
{{testimonials.card[0].position}}

{{testimonials.card[1].headline}}
{{testimonials.card[1].quote}}
{{testimonials.card[1].name}}
{{testimonials.card[1].position}}

{{testimonials.card[2].headline}}
{{testimonials.card[2].quote}}
{{testimonials.card[2].name}}
{{testimonials.card[2].position}}
```

---

## ❓ FAQ Section

### Section Header
```jinja
{{faq.badge_text}}
{{faq.title}}
{{faq.subtitle}}
```

### FAQ Items (6 items)
```jinja
{{faq.points[0].question}}
{{faq.points[0].answer}}

{{faq.points[1].question}}
{{faq.points[1].answer}}

{{faq.points[2].question}}
{{faq.points[2].answer}}

{{faq.points[3].question}}
{{faq.points[3].answer}}

{{faq.points[4].question}}
{{faq.points[4].answer}}

{{faq.points[5].question}}
{{faq.points[5].answer}}
```

---

## 📝 Content Section

### Content Details
```jinja
{{content.title}}
{{content.subtitle}}
{{content.description}}
{{content.image_url}}
```

---

## 🏙️ Local Coverage Section

### Section Content
```jinja
{{local.title}}
{{local.subtitle}}
{{local.description}}
```

### City Cards (3 items)
```jinja
{{local.city[0].title}}
{{local.city[0].description}}

{{local.city[1].title}}
{{local.city[1].description}}

{{local.city[2].title}}
{{local.city[2].description}}
```

---

## 🗺️ Kabupaten/Kota Section

### Kabupaten/Kota Cards (2 items)
```jinja
{{kabupaten_kota[0].nama}}
{{kabupaten_kota[0].description}}
{{kabupaten_kota[0].kecamatan[0].nama}}
{{kabupaten_kota[0].kecamatan[0].link}}
{{kabupaten_kota[0].kecamatan[1].nama}}
{{kabupaten_kota[0].kecamatan[1].link}}
{{kabupaten_kota[0].kecamatan[2].nama}}
{{kabupaten_kota[0].kecamatan[2].link}}

{{kabupaten_kota[1].nama}}
{{kabupaten_kota[1].description}}
{{kabupaten_kota[1].kecamatan[0].nama}}
{{kabupaten_kota[1].kecamatan[0].link}}
{{kabupaten_kota[1].kecamatan[1].nama}}
{{kabupaten_kota[1].kecamatan[1].link}}
{{kabupaten_kota[1].kecamatan[2].nama}}
{{kabupaten_kota[1].kecamatan[2].link}}
```

---

## 📞 Final CTA Section

### CTA Content
```jinja
{{final_cta.badge_text}}
{{final_cta.title}}
{{final_cta.subtitle}}
```

---

## 🖼️ Generated Images Metadata

### Image Generation Info
```jinja
{{keyword}}
{{generated_images.generated_at}}
{{generated_images.total_images}}
{{generated_images.search_keyword}}
{{generated_images.source}}
```

---

## 📋 Usage Examples

### Basic Usage
```jinja
<!-- Display hero title -->
<h1>{{hero.title}}</h1>

<!-- Display first feature -->
<div class="feature">
    <h3>{{hero.feature[0].point}}</h3>
    <p>{{hero.feature[0].description}}</p>
</div>

<!-- Display business contact -->
<p>Phone: {{business.phone}}</p>
<p>Address: {{business.address}}</p>
```

### Conditional Usage
```jinja
{% if hero.image_url %}
    <img src="{{hero.image_url}}" alt="{{hero.title}}">
{% endif %}

{% if business.phone %}
    <a href="tel:{{business.phone}}">Call Now</a>
{% endif %}
```

### SEO Implementation
```jinja
<title>{{seo_meta.seo_data.metadata.meta_title}}</title>
<meta name="description" content="{{seo_meta.seo_data.metadata.meta_description}}">
<script type="application/ld+json">
    {{seo_meta.seo_data.schema_markup.json_ld_script}}
</script>
```

---

## 🔧 Notes

- All fields are **direct variable references** (no loops used)
- Array indices are **zero-based** (e.g., `[0]`, `[1]`, `[2]`)
- Images are **Cloudinary optimized** URLs with auto-formatting
- SEO data includes **complete schema markup** for search engines
- All text content is in **Indonesian language**
- Contact information includes **phone and WhatsApp** links