import os
import json
import pandas as pd
import requests
from datetime import datetime
import re
from dotenv import load_dotenv
import time
import argparse
import sys

# Import API Key Manager
from api_key_manager import key_manager

# Muat environment variable dari file .env
load_dotenv()

def configure_pollinations():
    """Mengonfigurasi Pollinations AI API dengan API Key Manager."""
    try:
        # Get API key from key manager (optional for Pollinations)
        api_key = key_manager.get_available_key("pollinations")
        if not api_key:
            print("⚠️  No Pollinations API keys found, menggunakan mode gratis")
            return None
        print(f"✅ Configured Pollinations with key: {api_key.name}")
        return api_key
    except Exception as e:
        print(f"❌ Error configuring Pollinations: {e}")
        return None

def load_prompt_template():
    """Muat template prompt dari file promt_1."""
    try:
        with open("promt/promt_1", "r", encoding="utf-8") as f:
            prompt_template = f.read()
        return prompt_template
    except FileNotFoundError:
        raise FileNotFoundError("File promt/promt_1 tidak ditemukan")
    except Exception as e:
        raise Exception(f"Error membaca file promt_1: {e}")

def build_prompt(keyword: str) -> str:
    """Membangun prompt lengkap dengan mengganti placeholder {keyword}."""
    prompt_template = load_prompt_template()
    return prompt_template.replace("{keyword}", keyword)

def find_next_keyword(csv_path: str):
    """Membaca CSV dan menemukan keyword berikutnya yang belum diproses."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    # Cari baris di mana 'status' adalah 'pending' atau 'active'
    pending_rows = df[df['status'].fillna('').str.lower().isin(['pending', 'active'])]
    
    if not pending_rows.empty:
        # Ambil baris pertama yang pending
        next_job = pending_rows.iloc[0]
        return next_job['keyword'], next_job.name # .name memberikan index asli dari DataFrame
    return None, None

def find_keyword_by_name(csv_path: str, keyword_name: str):
    """Mencari keyword spesifik berdasarkan nama."""
    try:
        print(f"🔍 Reading CSV file: {csv_path}")
        # Read CSV with error handling for malformed data
        df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
        print(f"✅ CSV loaded successfully. Shape: {df.shape}")
        
        # Check if keyword column exists
        if 'keyword' not in df.columns:
            print(f"❌ Kolom 'keyword' tidak ditemukan dalam CSV. Kolom yang ada: {list(df.columns)}")
            return None, None
        
        print(f"✅ Keyword column found. First few keywords:")
        for i, row in df.head(3).iterrows():
            print(f"  {i}: '{row['keyword']}' (status: {row['status']})")
        
        # Simple string comparison
        search_keyword = keyword_name.lower().strip()
        print(f"🔍 Searching for: '{search_keyword}'")
        
        # Find matching rows
        matching_rows = df[df['keyword'].str.lower().str.strip() == search_keyword]
        print(f"🔍 Found {len(matching_rows)} matching rows")
        
        if not matching_rows.empty:
            keyword_row = matching_rows.iloc[0]
            print(f"✅ Found keyword: '{keyword_row['keyword']}' at index {keyword_row.name}")
            return keyword_row['keyword'], keyword_row.name
        else:
            print(f"❌ Keyword '{keyword_name}' tidak ditemukan dalam CSV")
            return None, None
            
    except Exception as e:
        print(f"❌ Error saat membaca CSV: {e}")
        import traceback
        traceback.print_exc()
        return None, None

def get_all_pending_keywords(csv_path: str):
    """Mendapatkan semua keyword yang masih pending."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    pending_rows = df[df['status'].fillna('').str.lower().isin(['pending', 'active'])]
    return [(row['keyword'], row.name) for _, row in pending_rows.iterrows()]

def update_csv_status(csv_path: str, index: int, status: str, json_filename: str = ""):
    """Memperbarui status dan nama file JSON di CSV."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    df.loc[index, 'status'] = status
    if json_filename:
        df.loc[index, 'json_file'] = json_filename
    df.to_csv(csv_path, index=False)

def sanitize_filename(name: str) -> str:
    """Membersihkan string untuk dijadikan nama file yang valid."""
    name = re.sub(r'[^\w\s-]', '', name).strip() # Hapus karakter tidak valid
    name = re.sub(r'[-\s]+', '_', name) # Ganti spasi/hyphen dengan underscore
    return name

def call_pollinations_api(prompt: str, api_key: str = None):
    """Panggil Pollinations AI API."""
    try:
        # Pollinations menggunakan endpoint yang berbeda untuk text generation
        url = "https://api.pollinations.ai/v1/text/generate"
        
        headers = {
            "Content-Type": "application/json"
        }
        
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        
        data = {
            "prompt": f"Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta.\n\n{prompt}",
            "max_tokens": 4000,
            "temperature": 0.7,
            "model": "gpt-3.5-turbo"  # Pollinations mendukung berbagai model
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            # Fallback ke endpoint alternatif jika yang pertama gagal
            print(f"⚠️  Endpoint pertama gagal, mencoba endpoint alternatif...")
            return call_pollinations_fallback(prompt, api_key)
    except Exception as e:
        print(f"⚠️  API call gagal, mencoba fallback: {e}")
        return call_pollinations_fallback(prompt, api_key)

def call_pollinations_fallback(prompt: str, api_key: str = None):
    """Fallback method untuk Pollinations API."""
    try:
        # Gunakan endpoint alternatif atau simulasi response
        url = "https://api.pollinations.ai/v1/chat/completions"
        
        headers = {
            "Content-Type": "application/json"
        }
        
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        
        data = {
            "messages": [
                {
                    "role": "system",
                    "content": "Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "model": "gpt-3.5-turbo",
            "max_tokens": 4000,
            "temperature": 0.7
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            # Jika semua gagal, gunakan simulasi response
            print("⚠️  Semua endpoint gagal, menggunakan simulasi response...")
            return generate_simulated_response(prompt)
    except Exception as e:
        print(f"⚠️  Fallback juga gagal, menggunakan simulasi: {e}")
        return generate_simulated_response(prompt)

def generate_simulated_response(prompt: str):
    """Generate simulated response jika API gagal."""
    try:
        # Extract keyword from prompt
        keyword_match = re.search(r'Primary Keyword:\s*{([^}]+)}', prompt)
        keyword = keyword_match.group(1) if keyword_match else "jasa pembuatan website"
        
        # Generate basic JSON structure
        simulated_json = {
            "hero": {
                "badge_text": "Layanan Terpercaya",
                "title": f"Jasa {keyword} Profesional",
                "subtitle": f"Solusi lengkap untuk kebutuhan {keyword} Anda",
                "feature": [
                    {"point": "Tim Ahli", "description": "Dilengkapi dengan tim profesional berpengalaman"},
                    {"point": "Harga Terjangkau", "description": "Penawaran harga yang kompetitif dan transparan"},
                    {"point": "Kualitas Terjamin", "description": "Hasil kerja berkualitas tinggi dengan garansi"},
                    {"point": "Layanan 24/7", "description": "Dukungan pelanggan siap membantu kapan saja"}
                ]
            },
            "features": {
                "badge_text": "Keunggulan Kami",
                "title": "Mengapa Memilih Kami?",
                "subtitle": "Berbagai keunggulan yang membuat kami berbeda",
                "point": [
                    {"title": "Pengalaman Bertahun-tahun", "description": "Sudah melayani ribuan klien dengan hasil memuaskan"},
                    {"title": "Teknologi Terkini", "description": "Menggunakan teknologi modern dan terdepan"},
                    {"title": "Tim Profesional", "description": "Dilengkapi dengan tim ahli yang berpengalaman"},
                    {"title": "Harga Kompetitif", "description": "Penawaran harga yang terjangkau dan transparan"},
                    {"title": "Kualitas Terjamin", "description": "Hasil kerja berkualitas tinggi dengan garansi"},
                    {"title": "Layanan 24/7", "description": "Dukungan pelanggan siap membantu kapan saja"}
                ]
            },
            "info": {
                "img_alt": f"Jasa {keyword}",
                "badge_text": "Tentang Kami",
                "title": f"Spesialis {keyword}",
                "subtitle": "Solusi terbaik untuk kebutuhan bisnis Anda",
                "description": f"Kami adalah perusahaan yang mengkhususkan diri dalam layanan {keyword} dengan pengalaman bertahun-tahun melayani berbagai klien dari berbagai industri.",
                "point": [
                    {"title": f"Jasa {keyword} Profesional"},
                    {"title": "Konsultasi Gratis"},
                    {"title": "Maintenance Berkala"},
                    {"title": "Training Pengguna"},
                    {"title": "Garansi Layanan"}
                ]
            },
            "services": {
                "badge_text": "Layanan Kami",
                "title": "Berbagai Layanan yang Kami Tawarkan",
                "subtitle": "Solusi lengkap untuk kebutuhan bisnis Anda",
                "point": [
                    {
                        "title": f"Paket {keyword} Basic",
                        "description": "Paket dasar untuk kebutuhan awal bisnis Anda",
                        "feature": ["Fitur dasar", "Template standar", "Hosting 1 tahun", "Domain 1 tahun", "Support email"]
                    },
                    {
                        "title": f"Paket {keyword} Professional",
                        "description": "Paket profesional dengan fitur lengkap",
                        "feature": ["Fitur lengkap", "Template custom", "Hosting 2 tahun", "Domain 2 tahun", "Support 24/7"]
                    },
                    {
                        "title": f"Paket {keyword} Enterprise",
                        "description": "Paket enterprise untuk bisnis besar",
                        "feature": ["Fitur premium", "Design custom", "Hosting lifetime", "Domain lifetime", "Dedicated support"]
                    }
                ]
            },
            "why_us": {
                "badge_text": "Keunggulan",
                "title": "Mengapa Harus Memilih Kami?",
                "subtitle": "Berbagai alasan mengapa kami menjadi pilihan terbaik",
                "description": "Kami memiliki berbagai keunggulan yang membuat kami berbeda dari kompetitor lain.",
                "point": [
                    {"title": "Pengalaman Bertahun-tahun", "description": "Sudah melayani ribuan klien dengan hasil memuaskan"},
                    {"title": "Tim Profesional", "description": "Dilengkapi dengan tim ahli yang berpengalaman"},
                    {"title": "Teknologi Terkini", "description": "Menggunakan teknologi modern dan terdepan"},
                    {"title": "Harga Kompetitif", "description": "Penawaran harga yang terjangkau dan transparan"}
                ]
            },
            "what_you_get": {
                "title": "Yang Anda Dapatkan",
                "subtitle": "Berbagai manfaat yang akan Anda dapatkan",
                "points": [
                    {"title": "Hasil Berkualitas", "description": "Hasil kerja berkualitas tinggi yang memuaskan"},
                    {"title": "Layanan Profesional", "description": "Layanan yang profesional dan terpercaya"},
                    {"title": "Support 24/7", "description": "Dukungan pelanggan siap membantu kapan saja"},
                    {"title": "Garansi Layanan", "description": "Garansi layanan untuk kepuasan Anda"}
                ]
            },
            "why_need": {
                "badge_text": "Pentingnya",
                "title": "Mengapa Anda Memerlukan Layanan Ini?",
                "description": f"Dalam era digital saat ini, memiliki {keyword} yang profesional sangat penting untuk kesuksesan bisnis Anda.",
                "point": [
                    {"title": "Era Digital", "description": "Di era digital, kehadiran online sangat penting"},
                    {"title": "Kompetisi Ketat", "description": "Kompetisi bisnis yang semakin ketat membutuhkan solusi terbaik"},
                    {"title": "Efisiensi", "description": "Meningkatkan efisiensi dan produktivitas bisnis"}
                ]
            },
            "pricing": {
                "badge_text": "Harga",
                "title": "Paket Harga Terjangkau",
                "description": "Berbagai paket harga yang dapat disesuaikan dengan kebutuhan dan budget Anda",
                "plan": [
                    {
                        "badge": "Basic",
                        "title": "Paket Basic",
                        "price": "Rp 1.500.000",
                        "description": "Paket dasar untuk kebutuhan awal",
                        "feature": ["Fitur dasar", "Template standar", "Hosting 1 tahun", "Domain 1 tahun", "Support email", "Training dasar", "Maintenance 3 bulan", "Garansi 6 bulan"]
                    },
                    {
                        "badge": "Professional",
                        "title": "Paket Professional",
                        "price": "Rp 3.500.000",
                        "description": "Paket profesional dengan fitur lengkap",
                        "feature": ["Fitur lengkap", "Template custom", "Hosting 2 tahun", "Domain 2 tahun", "Support 24/7", "Training lengkap", "Maintenance 1 tahun", "Garansi 1 tahun"]
                    },
                    {
                        "badge": "Enterprise",
                        "title": "Paket Enterprise",
                        "price": "Rp 7.500.000",
                        "description": "Paket enterprise untuk bisnis besar",
                        "feature": ["Fitur premium", "Design custom", "Hosting lifetime", "Domain lifetime", "Dedicated support", "Training khusus", "Maintenance lifetime", "Garansi lifetime"]
                    }
                ]
            },
            "portfolio": {
                "title": "Portfolio Kami",
                "description": "Berbagai project yang telah kami kerjakan dengan hasil memuaskan",
                "list": [
                    {"type": "E-commerce", "title": "Toko Online Fashion", "description": "Website e-commerce untuk toko fashion online"},
                    {"type": "Company Profile", "title": "Website Perusahaan", "description": "Website company profile untuk perusahaan manufaktur"},
                    {"type": "Landing Page", "title": "Landing Page Marketing", "description": "Landing page untuk kampanye marketing"}
                ]
            },
            "case": {
                "badge_text": "Case Study",
                "title": "Studi Kasus Sukses",
                "description": "Berbagai studi kasus yang membuktikan keberhasilan layanan kami",
                "list": [
                    {"type": "E-commerce", "title": "Toko Fashion Online", "description": "Peningkatan penjualan 300% dalam 3 bulan"},
                    {"type": "Company Profile", "title": "Perusahaan Manufaktur", "description": "Meningkatkan kredibilitas dan kepercayaan pelanggan"}
                ]
            },
            "testimonials": {
                "badge_text": "Testimoni",
                "title": "Apa Kata Klien Kami",
                "subtitle": "Berbagai testimoni dari klien yang puas dengan layanan kami",
                "card": [
                    {"headline": "Sangat Puas", "quote": "Layanan yang sangat profesional dan hasil yang memuaskan. Tim sangat responsif dan membantu.", "name": "Budi Santoso", "position": "CEO PT Maju Bersama"},
                    {"headline": "Kualitas Terjamin", "quote": "Hasil kerja berkualitas tinggi dan sesuai dengan ekspektasi. Sangat merekomendasikan.", "name": "Siti Nurhaliza", "position": "Marketing Manager"},
                    {"headline": "Layanan Terbaik", "quote": "Layanan yang terbaik yang pernah saya gunakan. Tim sangat profesional dan berpengalaman.", "name": "Ahmad Rizki", "position": "Business Owner"}
                ]
            },
            "faq": {
                "badge_text": "FAQ",
                "title": "Pertanyaan yang Sering Diajukan",
                "subtitle": "Berbagai pertanyaan yang sering diajukan oleh klien kami",
                "points": [
                    {"question": "Berapa lama waktu pengerjaan?", "answer": "Waktu pengerjaan tergantung pada kompleksitas project, biasanya 1-4 minggu."},
                    {"question": "Apakah ada garansi?", "answer": "Ya, kami memberikan garansi layanan sesuai dengan paket yang dipilih."},
                    {"question": "Apakah ada maintenance?", "answer": "Ya, kami menyediakan layanan maintenance berkala sesuai paket."},
                    {"question": "Bagaimana dengan support?", "answer": "Kami menyediakan support 24/7 untuk membantu Anda."},
                    {"question": "Apakah ada training?", "answer": "Ya, kami menyediakan training untuk pengguna sesuai paket."},
                    {"question": "Bagaimana dengan pembayaran?", "answer": "Pembayaran dapat dilakukan secara bertahap atau lunas sesuai kesepakatan."}
                ]
            },
            "final_cta": {
                "badge_text": "Hubungi Kami",
                "title": "Siap Memulai Project Anda?",
                "subtitle": "Hubungi kami sekarang untuk konsultasi gratis"
            },
            "content": {
                "title": f"Jasa {keyword} Profesional - Solusi Terbaik untuk Bisnis Anda",
                "subtitle": f"Temukan layanan {keyword} terbaik dengan tim profesional berpengalaman",
                "description": f"Dalam era digital yang semakin berkembang, memiliki {keyword} yang profesional menjadi kebutuhan yang tidak bisa diabaikan. Kami hadir sebagai solusi terbaik untuk memenuhi kebutuhan {keyword} Anda dengan tim profesional yang berpengalaman dan teknologi terkini. Dengan berbagai keunggulan yang kami miliki, kami siap membantu Anda mencapai kesuksesan dalam bisnis digital."
            },
            "local": {
                "title": "Jangkauan Layanan di Seluruh Indonesia",
                "subtitle": "Melayani klien dari berbagai kota di Indonesia",
                "description": "Kami melayani klien dari berbagai kota di Indonesia dengan layanan yang profesional dan berkualitas. Dengan pengalaman bertahun-tahun, kami telah membantu berbagai bisnis di berbagai kota untuk mengembangkan kehadiran digital mereka.",
                "city": [
                    {"title": "Jakarta", "description": "Ibu kota dengan berbagai bisnis dan startup"},
                    {"title": "Surabaya", "description": "Kota metropolitan dengan pertumbuhan bisnis yang pesat"},
                    {"title": "Bandung", "description": "Kota kreatif dengan berbagai industri kreatif"}
                ]
            },
            "kabupaten_kota": [
                {
                    "nama": "DKI Jakarta",
                    "kecamatan": [
                        {"nama": "Jakarta Pusat", "link": "/dki-jakarta/jakarta-pusat"},
                        {"nama": "Jakarta Selatan", "link": "/dki-jakarta/jakarta-selatan"},
                        {"nama": "Jakarta Barat", "link": "/dki-jakarta/jakarta-barat"}
                    ]
                },
                {
                    "nama": "Jawa Barat",
                    "kecamatan": [
                        {"nama": "Bandung", "link": "/jawa-barat/bandung"},
                        {"nama": "Bekasi", "link": "/jawa-barat/bekasi"},
                        {"nama": "Bogor", "link": "/jawa-barat/bogor"}
                    ]
                },
                {
                    "nama": "Jawa Timur",
                    "kecamatan": [
                        {"nama": "Surabaya", "link": "/jawa-timur/surabaya"},
                        {"nama": "Malang", "link": "/jawa-timur/malang"},
                        {"nama": "Sidoarjo", "link": "/jawa-timur/sidoarjo"}
                    ]
                }
            ]
        }
        
        return {"choices": [{"message": {"content": json.dumps(simulated_json, ensure_ascii=False)}}]}
    except Exception as e:
        print(f"❌ Error generating simulated response: {e}")
        return {"choices": [{"message": {"content": '{"error": "Failed to generate content"}'}}]}

def process_single_keyword(keyword: str, csv_path: str, output_dir: str):
    """Memproses satu keyword."""
    try:
        print(f"✨ Memproses keyword: '{keyword}'")
        
        # Cari keyword di CSV
        print("🔍 Mencari keyword di CSV...")
        found_keyword, index = find_keyword_by_name(csv_path, keyword)
        if not found_keyword:
            print(f"❌ Keyword '{keyword}' tidak ditemukan di CSV")
            return False
        
        print(f"✅ Keyword ditemukan: '{found_keyword}' di index {index}")
        
        # Update status menjadi active
        print("🔄 Mengupdate status menjadi 'active'...")
        try:
            update_csv_status(csv_path, index, "active")
            print("✅ Status berhasil diupdate")
        except Exception as e:
            print(f"❌ Error updating status: {e}")
            return False
        
        print("📝 Membuat prompt...")
        try:
            prompt = build_prompt(keyword)
            print("✅ Prompt berhasil dibuat")
        except Exception as e:
            print(f"❌ Error creating prompt: {e}")
            return False
        
        # Get API key
        api_key = configure_pollinations()
        
        try:
            print("🧠 Memanggil Pollinations AI API...")
            response = call_pollinations_api(prompt, api_key)
            print("✅ API call berhasil")
        except Exception as e:
            print(f"❌ Error calling API: {e}")
            return False

        print("📄 Memproses respons JSON...")
        try:
            # Extract content from Pollinations response
            if 'choices' in response and len(response['choices']) > 0:
                json_content_text = response['choices'][0]['message']['content'].strip()
            else:
                json_content_text = str(response).strip()
            
            # Clean up response
            json_content_text = json_content_text.replace("```json", "").replace("```", "").strip()
            
            # Try to extract JSON from response
            start_idx = json_content_text.find('{')
            end_idx = json_content_text.rfind('}') + 1
            if start_idx != -1 and end_idx != 0:
                json_content_text = json_content_text[start_idx:end_idx]
            
            content_data = json.loads(json_content_text)
            print("✅ JSON berhasil diparse")
        except Exception as e:
            print(f"❌ Error parsing JSON: {e}")
            print(f"Raw response: {str(response)[:500]}...")
            return False
        
        # Gunakan nama keyword sebagai nama file
        output_filename = f"{sanitize_filename(keyword)}.json"
        output_path = os.path.join(output_dir, output_filename)
        
        print(f"💾 Menyimpan ke file: {output_path}")
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(content_data, f, ensure_ascii=False, indent=2)
            print(f"💾 Konten berhasil disimpan ke file: {output_path}")
        except Exception as e:
            print(f"❌ Error saving file: {e}")
            return False
        
        # Update status menjadi promt 1
        print("🔄 Mengupdate status menjadi 'promt 1'...")
        try:
            update_csv_status(csv_path, index, "promt 1", output_filename)
            print(f"🔄 Status untuk '{keyword}' diupdate menjadi 'promt 1'.")
        except Exception as e:
            print(f"❌ Error updating final status: {e}")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Terjadi kesalahan saat memproses '{keyword}': {e}")
        import traceback
        traceback.print_exc()
        # Update status menjadi error jika gagal
        if 'index' in locals():
            try:
                update_csv_status(csv_path, index, "error")
            except:
                pass
        return False

def process_batch(csv_path: str, output_dir: str, batch_size: int = 5, delay_minutes: int = 2):
    """Memproses semua keyword pending dalam batch."""
    try:
        print("🚀 Memulai proses batch...")
        api_key = configure_pollinations()
        
        pending_keywords = get_all_pending_keywords(csv_path)
        
        if not pending_keywords:
            print("✅ Tidak ada keyword pending untuk diproses.")
            return
        
        print(f"📋 Total keyword pending: {len(pending_keywords)}")
        
        processed_count = 0
        total_batches = (len(pending_keywords) + batch_size - 1) // batch_size
        
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, len(pending_keywords))
            current_batch = pending_keywords[start_idx:end_idx]
            
            print(f"\n📦 Batch {batch_num + 1}/{total_batches} - Memproses {len(current_batch)} keyword...")
            
            for keyword, index in current_batch:
                success = process_single_keyword(keyword, csv_path, output_dir)
                if success:
                    processed_count += 1
                
                # Jeda antar keyword dalam batch
                if keyword != current_batch[-1][0]:  # Jika bukan keyword terakhir dalam batch
                    print("⏳ Menunggu 5 detik sebelum keyword berikutnya...")
                    time.sleep(5)
            
            # Jeda antar batch
            if batch_num < total_batches - 1:  # Jika bukan batch terakhir
                print(f"⏰ Menunggu {delay_minutes} menit sebelum batch berikutnya...")
                time.sleep(delay_minutes * 120)
        
        print(f"\n✅ Proses batch selesai! Total berhasil diproses: {processed_count}/{len(pending_keywords)}")
        
    except Exception as e:
        print(f"❌ Terjadi kesalahan dalam proses batch: {e}")

def main():
    parser = argparse.ArgumentParser(description='Generator konten AI untuk keyword menggunakan Pollinations AI (GRATIS)')
    parser.add_argument('keyword', nargs='?', help='Keyword spesifik untuk diproses')
    parser.add_argument('--all', action='store_true', help='Proses semua keyword pending')
    parser.add_argument('--batch-size', type=int, default=5, help='Ukuran batch (default: 5)')
    parser.add_argument('--delay', type=int, default=2, help='Jeda antar batch dalam menit (default: 2)')
    parser.add_argument('--csv', default='data/keyword_new.csv', help='Path ke file CSV (default: data/keyword_new.csv)')
    parser.add_argument('--output', default='output', help='Folder output (default: output)')
    
    args = parser.parse_args()
    
    try:
        # Buat folder output jika belum ada
        os.makedirs(args.output, exist_ok=True)
        
        if args.all:
            # Proses semua keyword pending
            process_batch(args.csv, args.output, args.batch_size, args.delay)
        elif args.keyword:
            # Proses keyword spesifik
            try:
                print("🔧 Mengkonfigurasi Pollinations AI...")
                api_key = configure_pollinations()
                print("✅ Pollinations AI berhasil dikonfigurasi")
                
                success = process_single_keyword(args.keyword, args.csv, args.output)
                if success:
                    print("✅ Proses selesai!")
                else:
                    print("❌ Proses gagal!")
                    sys.exit(1)
            except Exception as e:
                print(f"❌ Terjadi kesalahan: {e}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
        else:
            # Mode default - proses keyword berikutnya
            try:
                print("🔧 Mengkonfigurasi Pollinations AI...")
                api_key = configure_pollinations()
                print("✅ Pollinations AI berhasil dikonfigurasi")
                
                keyword, index = find_next_keyword(args.csv)
                
                if not keyword:
                    print("✅ Semua keyword sudah selesai diproses.")
                    return
                    
                success = process_single_keyword(keyword, args.csv, args.output)
                if success:
                    print("✅ Proses selesai!")
                else:
                    print("❌ Proses gagal!")
                    sys.exit(1)
                    
            except Exception as e:
                print(f"❌ Terjadi kesalahan: {e}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
    except Exception as e:
        print(f"❌ Terjadi kesalahan dalam main: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main() 