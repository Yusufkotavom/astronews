#!/usr/bin/env python3
"""
Simple Python script to render JSON data into Jinja2 template
"""

import json
import os
from jinja2 import Environment, FileSystemLoader

def load_json_data(json_file_path):
    """Load JSON data from file"""
    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"❌ Error: File '{json_file_path}' tidak ditemukan.")
        return None
    except json.JSONDecodeError as e:
        print(f"❌ Error: Invalid JSON format in '{json_file_path}': {e}")
        return None

def load_template(template_file_path):
    """Load Jinja2 template from file"""
    try:
        # Get directory containing the template
        template_dir = os.path.dirname(template_file_path)
        template_name = os.path.basename(template_file_path)
        
        # Create Jinja2 environment
        env = Environment(loader=FileSystemLoader(template_dir))
        template = env.get_template(template_name)
        return template
    except Exception as e:
        print(f"❌ Error loading template '{template_file_path}': {e}")
        return None

def render_template(template, data, output_file_path):
    """Render template with data and save to file"""
    try:
        # Render the template
        rendered_html = template.render(**data)
        
        # Save to output file
        with open(output_file_path, 'w', encoding='utf-8') as f:
            f.write(rendered_html)
        
        print(f"✅ Berhasil render template ke: {output_file_path}")
        return True
    except Exception as e:
        print(f"❌ Error rendering template: {e}")
        return False

def main():
    """Main function"""
    print("🚀 Memulai proses render Jinja2 template...")
    
    # File paths
    json_file = "demo_data/sample_website_service.json"
    template_file = "demo_data/base.json"
    output_file = "output/rendered_website.html"
    
    # Create output directory if it doesn't exist
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    # 1. Load JSON data
    print(f"📄 Loading JSON data dari: {json_file}")
    data = load_json_data(json_file)
    if data is None:
        return
    
    # 2. Load Jinja2 template
    print(f"📋 Loading template dari: {template_file}")
    template = load_template(template_file)
    if template is None:
        return
    
    # 3. Render template
    print("🔄 Rendering template...")
    success = render_template(template, data, output_file)
    
    if success:
        print("🎉 Proses render selesai!")
        print(f"📁 File output: {output_file}")
        
        # Show file size
        file_size = os.path.getsize(output_file)
        print(f"📊 Ukuran file: {file_size:,} bytes")
    else:
        print("❌ Gagal merender template")

if __name__ == "__main__":
    main() 