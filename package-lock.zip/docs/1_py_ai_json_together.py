import os
import json
import pandas as pd
import requests
from datetime import datetime
import re
from dotenv import load_dotenv
import time
import argparse
import sys

# Import API Key Manager
from api_key_manager import key_manager

# Muat environment variable dari file .env
load_dotenv()

def configure_together():
    """Mengonfigurasi Together AI API dengan API Key Manager."""
    try:
        # Get API key from key manager
        api_key = key_manager.get_available_key("together")
        if not api_key:
            print("❌ No available Together AI API keys found")
            print("💡 Dapatkan API key gratis dari: https://together.ai/")
            return None
        print(f"✅ Configured Together AI with key: {api_key.name}")
        return api_key
    except Exception as e:
        print(f"❌ Error configuring Together AI: {e}")
        return None

def load_prompt_template():
    """Muat template prompt dari file promt_1."""
    try:
        with open("promt/promt_1", "r", encoding="utf-8") as f:
            prompt_template = f.read()
        return prompt_template
    except FileNotFoundError:
        raise FileNotFoundError("File promt/promt_1 tidak ditemukan")
    except Exception as e:
        raise Exception(f"Error membaca file promt_1: {e}")

def build_prompt(keyword: str) -> str:
    """Membangun prompt lengkap dengan mengganti placeholder {keyword}."""
    prompt_template = load_prompt_template()
    return prompt_template.replace("{keyword}", keyword)

def find_next_keyword(csv_path: str):
    """Membaca CSV dan menemukan keyword berikutnya yang belum diproses."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    # Cari baris di mana 'status' adalah 'pending' atau 'active'
    pending_rows = df[df['status'].fillna('').str.lower().isin(['pending', 'active'])]
    
    if not pending_rows.empty:
        # Ambil baris pertama yang pending
        next_job = pending_rows.iloc[0]
        return next_job['keyword'], next_job.name # .name memberikan index asli dari DataFrame
    return None, None

def find_keyword_by_name(csv_path: str, keyword_name: str):
    """Mencari keyword spesifik berdasarkan nama."""
    try:
        print(f"🔍 Reading CSV file: {csv_path}")
        # Read CSV with error handling for malformed data
        df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
        print(f"✅ CSV loaded successfully. Shape: {df.shape}")
        
        # Check if keyword column exists
        if 'keyword' not in df.columns:
            print(f"❌ Kolom 'keyword' tidak ditemukan dalam CSV. Kolom yang ada: {list(df.columns)}")
            return None, None
        
        print(f"✅ Keyword column found. First few keywords:")
        for i, row in df.head(3).iterrows():
            print(f"  {i}: '{row['keyword']}' (status: {row['status']})")
        
        # Simple string comparison
        search_keyword = keyword_name.lower().strip()
        print(f"🔍 Searching for: '{search_keyword}'")
        
        # Find matching rows
        matching_rows = df[df['keyword'].str.lower().str.strip() == search_keyword]
        print(f"🔍 Found {len(matching_rows)} matching rows")
        
        if not matching_rows.empty:
            keyword_row = matching_rows.iloc[0]
            print(f"✅ Found keyword: '{keyword_row['keyword']}' at index {keyword_row.name}")
            return keyword_row['keyword'], keyword_row.name
        else:
            print(f"❌ Keyword '{keyword_name}' tidak ditemukan dalam CSV")
            return None, None
            
    except Exception as e:
        print(f"❌ Error saat membaca CSV: {e}")
        import traceback
        traceback.print_exc()
        return None, None

def get_all_pending_keywords(csv_path: str):
    """Mendapatkan semua keyword yang masih pending."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    pending_rows = df[df['status'].fillna('').str.lower().isin(['pending', 'active'])]
    return [(row['keyword'], row.name) for _, row in pending_rows.iterrows()]

def update_csv_status(csv_path: str, index: int, status: str, json_filename: str = ""):
    """Memperbarui status dan nama file JSON di CSV."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    df.loc[index, 'status'] = status
    if json_filename:
        df.loc[index, 'json_file'] = json_filename
    df.to_csv(csv_path, index=False)

def sanitize_filename(name: str) -> str:
    """Membersihkan string untuk dijadikan nama file yang valid."""
    name = re.sub(r'[^\w\s-]', '', name).strip() # Hapus karakter tidak valid
    name = re.sub(r'[-\s]+', '_', name) # Ganti spasi/hyphen dengan underscore
    return name

def call_together_api(prompt: str, api_key: str):
    """Panggil Together AI API."""
    try:
        url = "https://api.together.xyz/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "meta-llama/Llama-2-70b-chat-hf",
            "messages": [
                {
                    "role": "system",
                    "content": "Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": 4000,
            "temperature": 0.7,
            "top_p": 0.9
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Together AI API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Together AI: {e}")

def process_single_keyword(keyword: str, csv_path: str, output_dir: str):
    """Memproses satu keyword."""
    try:
        print(f"✨ Memproses keyword: '{keyword}'")
        
        # Cari keyword di CSV
        print("🔍 Mencari keyword di CSV...")
        found_keyword, index = find_keyword_by_name(csv_path, keyword)
        if not found_keyword:
            print(f"❌ Keyword '{keyword}' tidak ditemukan di CSV")
            return False
        
        print(f"✅ Keyword ditemukan: '{found_keyword}' di index {index}")
        
        # Update status menjadi active
        print("🔄 Mengupdate status menjadi 'active'...")
        try:
            update_csv_status(csv_path, index, "active")
            print("✅ Status berhasil diupdate")
        except Exception as e:
            print(f"❌ Error updating status: {e}")
            return False
        
        print("📝 Membuat prompt...")
        try:
            prompt = build_prompt(keyword)
            print("✅ Prompt berhasil dibuat")
        except Exception as e:
            print(f"❌ Error creating prompt: {e}")
            return False
        
        # Get API key
        api_key = configure_together()
        if not api_key:
            return False
        
        try:
            print("🧠 Memanggil Together AI API...")
            response = call_together_api(prompt, api_key)
            print("✅ API call berhasil")
        except Exception as e:
            print(f"❌ Error calling API: {e}")
            return False

        print("📄 Memproses respons JSON...")
        try:
            # Extract content from Together AI response
            if 'choices' in response and len(response['choices']) > 0:
                json_content_text = response['choices'][0]['message']['content'].strip()
            else:
                json_content_text = str(response).strip()
            
            # Clean up response
            json_content_text = json_content_text.replace("```json", "").replace("```", "").strip()
            
            # Try to extract JSON from response
            start_idx = json_content_text.find('{')
            end_idx = json_content_text.rfind('}') + 1
            if start_idx != -1 and end_idx != 0:
                json_content_text = json_content_text[start_idx:end_idx]
            
            content_data = json.loads(json_content_text)
            print("✅ JSON berhasil diparse")
        except Exception as e:
            print(f"❌ Error parsing JSON: {e}")
            print(f"Raw response: {str(response)[:500]}...")
            return False
        
        # Gunakan nama keyword sebagai nama file
        output_filename = f"{sanitize_filename(keyword)}.json"
        output_path = os.path.join(output_dir, output_filename)
        
        print(f"💾 Menyimpan ke file: {output_path}")
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(content_data, f, ensure_ascii=False, indent=2)
            print(f"💾 Konten berhasil disimpan ke file: {output_path}")
        except Exception as e:
            print(f"❌ Error saving file: {e}")
            return False
        
        # Update status menjadi promt 1
        print("🔄 Mengupdate status menjadi 'promt 1'...")
        try:
            update_csv_status(csv_path, index, "promt 1", output_filename)
            print(f"🔄 Status untuk '{keyword}' diupdate menjadi 'promt 1'.")
        except Exception as e:
            print(f"❌ Error updating final status: {e}")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Terjadi kesalahan saat memproses '{keyword}': {e}")
        import traceback
        traceback.print_exc()
        # Update status menjadi error jika gagal
        if 'index' in locals():
            try:
                update_csv_status(csv_path, index, "error")
            except:
                pass
        return False

def process_batch(csv_path: str, output_dir: str, batch_size: int = 5, delay_minutes: int = 2):
    """Memproses semua keyword pending dalam batch."""
    try:
        print("🚀 Memulai proses batch...")
        api_key = configure_together()
        if not api_key:
            return
        
        pending_keywords = get_all_pending_keywords(csv_path)
        
        if not pending_keywords:
            print("✅ Tidak ada keyword pending untuk diproses.")
            return
        
        print(f"📋 Total keyword pending: {len(pending_keywords)}")
        
        processed_count = 0
        total_batches = (len(pending_keywords) + batch_size - 1) // batch_size
        
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, len(pending_keywords))
            current_batch = pending_keywords[start_idx:end_idx]
            
            print(f"\n📦 Batch {batch_num + 1}/{total_batches} - Memproses {len(current_batch)} keyword...")
            
            for keyword, index in current_batch:
                success = process_single_keyword(keyword, csv_path, output_dir)
                if success:
                    processed_count += 1
                
                # Jeda antar keyword dalam batch
                if keyword != current_batch[-1][0]:  # Jika bukan keyword terakhir dalam batch
                    print("⏳ Menunggu 5 detik sebelum keyword berikutnya...")
                    time.sleep(5)
            
            # Jeda antar batch
            if batch_num < total_batches - 1:  # Jika bukan batch terakhir
                print(f"⏰ Menunggu {delay_minutes} menit sebelum batch berikutnya...")
                time.sleep(delay_minutes * 120)
        
        print(f"\n✅ Proses batch selesai! Total berhasil diproses: {processed_count}/{len(pending_keywords)}")
        
    except Exception as e:
        print(f"❌ Terjadi kesalahan dalam proses batch: {e}")

def main():
    parser = argparse.ArgumentParser(description='Generator konten AI untuk keyword menggunakan Together AI (GRATIS)')
    parser.add_argument('keyword', nargs='?', help='Keyword spesifik untuk diproses')
    parser.add_argument('--all', action='store_true', help='Proses semua keyword pending')
    parser.add_argument('--batch-size', type=int, default=5, help='Ukuran batch (default: 5)')
    parser.add_argument('--delay', type=int, default=2, help='Jeda antar batch dalam menit (default: 2)')
    parser.add_argument('--csv', default='data/keyword_new.csv', help='Path ke file CSV (default: data/keyword_new.csv)')
    parser.add_argument('--output', default='output', help='Folder output (default: output)')
    
    args = parser.parse_args()
    
    try:
        # Buat folder output jika belum ada
        os.makedirs(args.output, exist_ok=True)
        
        if args.all:
            # Proses semua keyword pending
            process_batch(args.csv, args.output, args.batch_size, args.delay)
        elif args.keyword:
            # Proses keyword spesifik
            try:
                print("🔧 Mengkonfigurasi Together AI...")
                api_key = configure_together()
                if not api_key:
                    sys.exit(1)
                print("✅ Together AI berhasil dikonfigurasi")
                
                success = process_single_keyword(args.keyword, args.csv, args.output)
                if success:
                    print("✅ Proses selesai!")
                else:
                    print("❌ Proses gagal!")
                    sys.exit(1)
            except Exception as e:
                print(f"❌ Terjadi kesalahan: {e}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
        else:
            # Mode default - proses keyword berikutnya
            try:
                print("🔧 Mengkonfigurasi Together AI...")
                api_key = configure_together()
                if not api_key:
                    sys.exit(1)
                print("✅ Together AI berhasil dikonfigurasi")
                
                keyword, index = find_next_keyword(args.csv)
                
                if not keyword:
                    print("✅ Semua keyword sudah selesai diproses.")
                    return
                    
                success = process_single_keyword(keyword, args.csv, args.output)
                if success:
                    print("✅ Proses selesai!")
                else:
                    print("❌ Proses gagal!")
                    sys.exit(1)
                    
            except Exception as e:
                print(f"❌ Terjadi kesalahan: {e}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
    except Exception as e:
        print(f"❌ Terjadi kesalahan dalam main: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main() 