# WordPress Integration Guide

This guide explains how to integrate your WordPress site with Astro for a fast, static website.

## 🚀 Quick Start

### 1. Setup WordPress Configuration

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your WordPress URL
nano .env
```

### 2. Test WordPress Connection

```bash
npm run wordpress:setup
```

### 3. Import WordPress Posts

```bash
npm run wordpress:import
```

### 4. Build and Deploy

```bash
npm run build
# Deploy to Vercel
```

## 📋 Configuration

### Environment Variables (.env)

```env
# WordPress Site URL (required)
WORDPRESS_SITE_URL=https://your-wordpress-site.com

# Number of posts to import (optional, default: 100)
WORDPRESS_POSTS_PER_PAGE=100
```

### WordPress Configuration (scripts/wordpress-config.js)

You can customize:
- Category mappings
- Tag mappings
- Default author
- Content settings
- Image settings

## 🔧 Available Commands

| Command | Description |
|---------|-------------|
| `npm run wordpress:setup` | Test WordPress connection and show configuration |
| `npm run wordpress:import` | Import posts from WordPress to Astro |
| `npm run wordpress:test` | Test WordPress connection |
| `npm run build` | Build site with imported posts |

## 📁 File Structure

```
scripts/
├── wordpress-config.js      # WordPress configuration
├── import-wordpress-posts.js # Import script
└── setup-wordpress.js       # Setup and test script

src/content/post/            # Imported WordPress posts (Markdown)
.env                         # Environment variables
.env.example                 # Environment template
```

## 🔍 Troubleshooting

### Connection Issues

1. **WordPress site not accessible**
   - Check if WordPress is running
   - Verify the URL is correct
   - Test in browser

2. **REST API not working**
   - Enable WordPress REST API
   - Check for security plugins blocking API
   - Verify permalink settings

3. **Import fails**
   - Check WordPress site accessibility
   - Verify API endpoints
   - Check network connectivity

### Common Solutions

```bash
# Test connection
npm run wordpress:setup

# Check WordPress REST API
curl https://your-wordpress-site.com/wp-json/wp/v2/posts

# Import with verbose logging
npm run wordpress:import
```

## 📊 Import Process

1. **Connection Test** - Verify WordPress site is accessible
2. **API Fetch** - Get posts via WordPress REST API
3. **Content Conversion** - Convert HTML to Markdown
4. **Frontmatter Creation** - Generate Astro frontmatter
5. **File Writing** - Save as Markdown files
6. **Build** - Generate static site

## 🎯 Benefits

- **⚡ Super Fast** - No API calls at runtime
- **🔍 SEO Optimized** - All content static
- **📱 Mobile Friendly** - Responsive design
- **🔒 Secure** - No WordPress vulnerabilities
- **💰 Cost Effective** - No server resources needed

## 🔄 Workflow

### Development
1. Make changes to Astro site
2. Test locally: `npm run dev`
3. Import WordPress posts: `npm run wordpress:import`
4. Build: `npm run build`

### Production
1. Import latest WordPress posts
2. Build site
3. Deploy to Vercel
4. Site is live with latest content

## 📝 Customization

### Category Mapping
Edit `scripts/wordpress-config.js`:

```javascript
CATEGORY_MAPPING: {
  'uncategorized': 'General',
  'berita': 'News',
  'artikel': 'Article',
  // Add your mappings
}
```

### Tag Mapping
```javascript
TAG_MAPPING: {
  'wordpress': 'WordPress',
  'seo': 'SEO',
  // Add your mappings
}
```

### Content Settings
```javascript
MAX_CONTENT_LENGTH: 5000,
EXCERPT_LENGTH: 160,
FEATURED_IMAGE_SIZE: 'medium',
```

## 🚨 Important Notes

1. **WordPress must be accessible** from your build environment
2. **REST API must be enabled** in WordPress
3. **Posts are imported as static files** - no real-time updates
4. **Run import before each build** for latest content
5. **Backup your content** before making changes

## 📞 Support

If you encounter issues:

1. Check the troubleshooting section
2. Run `npm run wordpress:setup` for diagnostics
3. Verify WordPress site accessibility
4. Check network connectivity
5. Review error messages in console

## 🎉 Success Checklist

- [ ] WordPress site is accessible
- [ ] REST API is working
- [ ] Posts are imported successfully
- [ ] Site builds without errors
- [ ] All pages are working
- [ ] Search functionality works
- [ ] Categories and tags are generated
- [ ] Site is deployed to Vercel

Your WordPress integration is now complete! 🚀