#!/usr/bin/env python3
"""
API Key Manager for AI Services
Handles key rotation, timeouts, and automatic fallbacks
"""

import json
import os
import time
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import threading
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

@dataclass
class APIKey:
    """Represents an API key with usage tracking"""
    key: str
    service: str
    name: str
    is_active: bool = True
    last_used: Optional[datetime] = None
    success_count: int = 0
    failure_count: int = 0
    rate_limit_reset: Optional[datetime] = None
    daily_usage: int = 0
    daily_limit: int = 1500  # Default Gemini limit
    
    def get_success_rate(self) -> float:
        """Calculate success rate"""
        total = self.success_count + self.failure_count
        return self.success_count / total if total > 0 else 1.0
    
    def is_rate_limited(self) -> bool:
        """Check if key is currently rate limited"""
        if self.rate_limit_reset and datetime.now() < self.rate_limit_reset:
            return True
        return False
    
    def is_daily_limit_reached(self) -> bool:
        """Check if daily limit is reached"""
        # Reset daily usage if it's a new day
        if self.last_used and self.last_used.date() < datetime.now().date():
            self.daily_usage = 0
        return self.daily_usage >= self.daily_limit

class APIKeyManager:
    def __init__(self, config_file: str = "api_keys.json"):
        self.config_file = config_file
        self.keys: Dict[str, List[APIKey]] = {}
        self.lock = threading.Lock()
        self.timeout_seconds = 60  # 1 minute timeout as requested
        self.max_retries = 3
        
        # Load configuration
        self.load_config()
        
        # Initialize key tracking
        self.initialize_keys()
    
    def load_config(self):
        """Load API keys from configuration file or environment variables"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
            else:
                config = self.load_from_env()
            
            self.config = config
            print(f"✅ Loaded API configuration for {len(config)} services")
            
        except Exception as e:
            print(f"❌ Error loading API configuration: {e}")
            self.config = {}
    
    def load_from_env(self) -> Dict:
        """Load API keys from environment variables as fallback"""
        config = {
            "gemini": [],
            "openai": [],
            "anthropic": [],
            "unsplash": [],
            "cohere": [],
            "perplexity": [],
            "together": [],
            "blackbox": [],
            "pollinations": [],
            "huggingface": []
        }
        
        # Load Gemini keys
        gemini_keys = os.getenv("GOOGLE_API_KEY")
        if gemini_keys:
            config["gemini"].append({
                "key": gemini_keys,
                "name": "Primary Gemini Key"
            })
        
        # Load OpenAI keys
        openai_keys = os.getenv("OPENAI_API_KEY")
        if openai_keys:
            config["openai"].append({
                "key": openai_keys,
                "name": "Primary OpenAI Key"
            })
        
        # Load Anthropic keys
        anthropic_keys = os.getenv("ANTHROPIC_API_KEY")
        if anthropic_keys:
            config["anthropic"].append({
                "key": anthropic_keys,
                "name": "Primary Anthropic Key"
            })
        
        # Load Unsplash keys
        unsplash_keys = os.getenv("UNSPLASH_API_KEY")
        if unsplash_keys:
            config["unsplash"].append({
                "key": unsplash_keys,
                "name": "Primary Unsplash Key"
            })
        
        # Load Cohere keys
        cohere_keys = os.getenv("COHERE_API_KEY")
        if cohere_keys:
            config["cohere"].append({
                "key": cohere_keys,
                "name": "Primary Cohere Key"
            })
        
        # Load Perplexity keys
        perplexity_keys = os.getenv("PERPLEXITY_API_KEY")
        if perplexity_keys:
            config["perplexity"].append({
                "key": perplexity_keys,
                "name": "Primary Perplexity Key"
            })
        
        # Load Together keys
        together_keys = os.getenv("TOGETHER_API_KEY")
        if together_keys:
            config["together"].append({
                "key": together_keys,
                "name": "Primary Together Key"
            })
        
        # Load Blackbox keys
        blackbox_keys = os.getenv("BLACKBOX_API_KEY")
        if blackbox_keys:
            config["blackbox"].append({
                "key": blackbox_keys,
                "name": "Primary Blackbox Key"
            })
        
        # Load Pollinations keys
        pollinations_keys = os.getenv("POLLINATIONS_API_KEY")
        if pollinations_keys:
            config["pollinations"].append({
                "key": pollinations_keys,
                "name": "Primary Pollinations Key"
            })
        
        # Load Hugging Face keys
        huggingface_keys = os.getenv("HUGGINGFACE_API_KEY")
        if huggingface_keys:
            config["huggingface"].append({
                "key": huggingface_keys,
                "name": "Primary Hugging Face Key"
            })
        
        return config
    
    def initialize_keys(self):
        """Initialize APIKey objects from configuration"""
        for service, keys_list in self.config.items():
            self.keys[service] = []
            for key_data in keys_list:
                api_key = APIKey(
                    key=key_data["key"],
                    service=service,
                    name=key_data.get("name", f"{service} Key"),
                    daily_limit=key_data.get("daily_limit", self.get_default_limit(service))
                )
                self.keys[service].append(api_key)
    
    def get_default_limit(self, service: str) -> int:
        """Get default daily limit for service"""
        limits = {
            "gemini": 1500,
            "openai": 500,
            "anthropic": 500,
            "unsplash": 5000,
            "cohere": 1000,
            "perplexity": 1000,
            "together": 1000,
            "blackbox": 1000,
            "pollinations": 1000,
            "huggingface": 1000
        }
        return limits.get(service, 1000)
    
    def get_available_key(self, service: str) -> Optional[APIKey]:
        """Get the best available key for a service"""
        with self.lock:
            if service not in self.keys:
                return None
            
            available_keys = [
                key for key in self.keys[service]
                if key.is_active and not key.is_rate_limited() and not key.is_daily_limit_reached()
            ]
            
            if not available_keys:
                print(f"❌ No available keys for {service}")
                return None
            
            # Sort by success rate and last used time
            available_keys.sort(
                key=lambda k: (k.get_success_rate(), k.last_used or datetime.min),
                reverse=True
            )
            
            return available_keys[0]
    
    def mark_key_success(self, key: APIKey):
        """Mark a key as successfully used"""
        with self.lock:
            key.success_count += 1
            key.last_used = datetime.now()
            key.daily_usage += 1
            print(f"✅ Key '{key.name}' used successfully (success rate: {key.get_success_rate():.2%})")
    
    def mark_key_failure(self, key: APIKey, error_type: str = "unknown"):
        """Mark a key as failed"""
        with self.lock:
            key.failure_count += 1
            key.last_used = datetime.now()
            
            # Handle rate limiting
            if "rate limit" in error_type.lower() or "quota" in error_type.lower():
                key.rate_limit_reset = datetime.now() + timedelta(minutes=15)
                print(f"⏰ Key '{key.name}' rate limited until {key.rate_limit_reset}")
            elif "timeout" in error_type.lower():
                print(f"⏱️ Key '{key.name}' timed out")
            else:
                print(f"❌ Key '{key.name}' failed: {error_type}")
    
    def execute_with_rotation(self, service: str, function, *args, **kwargs) -> Any:
        """Execute a function with automatic key rotation and retry logic"""
        last_error = None
        
        for attempt in range(self.max_retries):
            # Get available key
            key = self.get_available_key(service)
            if not key:
                if last_error:
                    raise last_error
                raise Exception(f"No available keys for {service}")
            
            try:
                print(f"🔄 Attempt {attempt + 1}/{self.max_retries} with key '{key.name}'")
                
                # Execute function with timeout
                result = self.execute_with_timeout(function, key, *args, **kwargs)
                
                # Mark success
                self.mark_key_success(key)
                return result
                
            except Exception as e:
                error_msg = str(e).lower()
                self.mark_key_failure(key, str(e))
                last_error = e
                
                # Determine if we should retry
                if "rate limit" in error_msg or "quota" in error_msg:
                    print(f"⏰ Rate limit hit, trying next key...")
                    continue
                elif "timeout" in error_msg:
                    print(f"⏱️ Timeout occurred, trying next key...")
                    continue
                elif "401" in error_msg or "invalid" in error_msg or "unauthorized" in error_msg:
                    print(f"🔑 Authentication error, trying next key...")
                    continue
                else:
                    print(f"❌ Non-retryable error: {e}")
                    break
        
        # All retries exhausted
        if last_error:
            raise last_error
        raise Exception(f"All keys for {service} failed after {self.max_retries} attempts")
    
    def execute_with_timeout(self, function, key: APIKey, *args, **kwargs) -> Any:
        """Execute function with timeout - Windows compatible"""
        import threading
        import queue
        
        # Use threading for timeout (Windows compatible)
        result_queue = queue.Queue()
        exception_queue = queue.Queue()
        
        def execute_function():
            try:
                result = function(key.key, *args, **kwargs)
                result_queue.put(result)
            except Exception as e:
                exception_queue.put(e)
        
        # Start function in separate thread
        thread = threading.Thread(target=execute_function)
        thread.daemon = True
        thread.start()
        
        # Wait for result with timeout
        try:
            thread.join(timeout=self.timeout_seconds)
            
            if thread.is_alive():
                # Function is still running, timeout occurred
                raise TimeoutError(f"Operation timed out after {self.timeout_seconds} seconds")
            
            # Check for exceptions
            if not exception_queue.empty():
                raise exception_queue.get()
            
            # Get result
            if not result_queue.empty():
                return result_queue.get()
            else:
                raise Exception("Function completed but no result returned")
                
        except TimeoutError:
            raise
        except Exception as e:
            raise
    
    def get_service_status(self) -> Dict:
        """Get status of all services and keys"""
        status = {}
        
        for service, keys in self.keys.items():
            status[service] = {
                "total_keys": len(keys),
                "active_keys": sum(1 for k in keys if k.is_active),
                "available_keys": sum(1 for k in keys if k.is_active and not k.is_rate_limited() and not k.is_daily_limit_reached()),
                "keys": []
            }
            
            for key in keys:
                status[service]["keys"].append({
                    "name": key.name,
                    "is_active": key.is_active,
                    "success_rate": key.get_success_rate(),
                    "daily_usage": f"{key.daily_usage}/{key.daily_limit}",
                    "is_rate_limited": key.is_rate_limited(),
                    "last_used": key.last_used.isoformat() if key.last_used else None
                })
        
        return status
    
    def print_status(self):
        """Print current status of all services"""
        status = self.get_service_status()
        
        print("\n📊 API Key Manager Status")
        print("=" * 50)
        
        for service, info in status.items():
            print(f"\n🔧 {service.upper()}")
            print(f"   Total Keys: {info['total_keys']}")
            print(f"   Active Keys: {info['active_keys']}")
            print(f"   Available Keys: {info['available_keys']}")
            
            for key_info in info['keys']:
                status_icon = "✅" if key_info['is_active'] and not key_info['is_rate_limited'] else "❌"
                print(f"   {status_icon} {key_info['name']}")
                print(f"      Success Rate: {key_info['success_rate']:.2%}")
                print(f"      Daily Usage: {key_info['daily_usage']}")
                if key_info['is_rate_limited']:
                    print(f"      ⏰ Rate Limited")
    
    def add_key(self, service: str, key: str, name: str = None, daily_limit: int = None):
        """Add a new API key dynamically"""
        with self.lock:
            if service not in self.keys:
                self.keys[service] = []
            
            # Generate name if not provided
            if not name:
                name = f"{service.title()} Key {len(self.keys[service]) + 1}"
            
            # Get default limit if not provided
            if daily_limit is None:
                daily_limit = self.get_default_limit(service)
            
            # Create new API key
            api_key = APIKey(
                key=key,
                service=service,
                name=name,
                daily_limit=daily_limit
            )
            
            self.keys[service].append(api_key)
            print(f"✅ Added new {service} key: {name}")
            
            # Update config
            self.update_config()
    
    def remove_key(self, service: str, key_name: str):
        """Remove an API key by name"""
        with self.lock:
            if service not in self.keys:
                print(f"❌ Service '{service}' not found")
                return False
            
            # Find key by name
            for i, key in enumerate(self.keys[service]):
                if key.name == key_name:
                    removed_key = self.keys[service].pop(i)
                    print(f"✅ Removed {service} key: {removed_key.name}")
                    self.update_config()
                    return True
            
            print(f"❌ Key '{key_name}' not found in {service}")
            return False
    
    def update_key(self, service: str, key_name: str, new_key: str = None, new_name: str = None, new_limit: int = None):
        """Update an existing API key"""
        with self.lock:
            if service not in self.keys:
                print(f"❌ Service '{service}' not found")
                return False
            
            # Find key by name
            for key in self.keys[service]:
                if key.name == key_name:
                    if new_key:
                        key.key = new_key
                    if new_name:
                        key.name = new_name
                    if new_limit:
                        key.daily_limit = new_limit
                    
                    print(f"✅ Updated {service} key: {key.name}")
                    self.update_config()
                    return True
            
            print(f"❌ Key '{key_name}' not found in {service}")
            return False
    
    def list_keys(self, service: str = None):
        """List all keys or keys for a specific service"""
        if service:
            if service not in self.keys:
                print(f"❌ Service '{service}' not found")
                return
            
            print(f"\n🔑 {service.upper()} Keys:")
            for i, key in enumerate(self.keys[service], 1):
                status = "✅ Active" if key.is_active else "❌ Inactive"
                print(f"   {i}. {key.name} - {status}")
                print(f"      Key: {key.key[:10]}...{key.key[-4:]}")
                print(f"      Daily Limit: {key.daily_limit}")
        else:
            for service_name, keys in self.keys.items():
                print(f"\n🔑 {service_name.upper()} Keys ({len(keys)}):")
                for i, key in enumerate(keys, 1):
                    status = "✅ Active" if key.is_active else "❌ Inactive"
                    print(f"   {i}. {key.name} - {status}")
    
    def update_config(self):
        """Update the configuration file with current keys"""
        try:
            config = {}
            for service, keys in self.keys.items():
                config[service] = []
                for key in keys:
                    config[service].append({
                        "key": key.key,
                        "name": key.name,
                        "daily_limit": key.daily_limit
                    })
            
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            print(f"✅ Configuration updated: {self.config_file}")
        except Exception as e:
            print(f"❌ Error updating configuration: {e}")
    
    def reset_key_stats(self, service: str = None, key_name: str = None):
        """Reset statistics for keys"""
        with self.lock:
            if service and key_name:
                # Reset specific key
                if service in self.keys:
                    for key in self.keys[service]:
                        if key.name == key_name:
                            key.success_count = 0
                            key.failure_count = 0
                            key.daily_usage = 0
                            key.rate_limit_reset = None
                            print(f"✅ Reset stats for {service} key: {key_name}")
                            return True
                    print(f"❌ Key '{key_name}' not found in {service}")
                else:
                    print(f"❌ Service '{service}' not found")
            else:
                # Reset all keys
                for service_name, keys in self.keys.items():
                    for key in keys:
                        key.success_count = 0
                        key.failure_count = 0
                        key.daily_usage = 0
                        key.rate_limit_reset = None
                print("✅ Reset stats for all keys")

# Global instance
key_manager = APIKeyManager()

def get_gemini_key() -> str:
    """Get Gemini API key with rotation"""
    key = key_manager.get_available_key("gemini")
    if not key:
        raise Exception("No available Gemini keys")
    return key.key

def get_openai_key() -> str:
    """Get OpenAI API key with rotation"""
    key = key_manager.get_available_key("openai")
    if not key:
        raise Exception("No available OpenAI keys")
    return key.key

def get_anthropic_key() -> str:
    """Get Anthropic API key with rotation"""
    key = key_manager.get_available_key("anthropic")
    if not key:
        raise Exception("No available Anthropic keys")
    return key.key

def get_unsplash_key() -> str:
    """Get Unsplash API key with rotation"""
    key = key_manager.get_available_key("unsplash")
    if not key:
        raise Exception("No available Unsplash keys")
    return key.key

def get_cohere_key() -> str:
    """Get Cohere API key with rotation"""
    key = key_manager.get_available_key("cohere")
    if not key:
        raise Exception("No available Cohere keys")
    return key.key

def get_perplexity_key() -> str:
    """Get Perplexity API key with rotation"""
    key = key_manager.get_available_key("perplexity")
    if not key:
        raise Exception("No available Perplexity keys")
    return key.key

def get_together_key() -> str:
    """Get Together AI API key with rotation"""
    key = key_manager.get_available_key("together")
    if not key:
        raise Exception("No available Together AI keys")
    return key.key

def get_blackbox_key() -> str:
    """Get Blackbox AI API key with rotation"""
    key = key_manager.get_available_key("blackbox")
    if not key:
        raise Exception("No available Blackbox AI keys")
    return key.key

def get_pollinations_key() -> str:
    """Get Pollinations AI API key with rotation"""
    key = key_manager.get_available_key("pollinations")
    if not key:
        raise Exception("No available Pollinations AI keys")
    return key.key

def get_huggingface_key() -> str:
    """Get Hugging Face API key with rotation"""
    key = key_manager.get_available_key("huggingface")
    if not key:
        raise Exception("No available Hugging Face keys")
    return key.key

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="API Key Manager - Manage your API keys dynamically")
    parser.add_argument("--status", action="store_true", help="Show status of all keys")
    parser.add_argument("--list", metavar="SERVICE", help="List keys for specific service (gemini, openai, anthropic, unsplash, cohere, perplexity, together, blackbox, pollinations, huggingface)")
    parser.add_argument("--add", nargs=3, metavar=("SERVICE", "KEY", "NAME"), help="Add new key: service key_value key_name")
    parser.add_argument("--remove", nargs=2, metavar=("SERVICE", "NAME"), help="Remove key: service key_name")
    parser.add_argument("--update", nargs=4, metavar=("SERVICE", "NAME", "NEW_KEY", "NEW_NAME"), help="Update key: service old_name new_key new_name")
    parser.add_argument("--reset", nargs="?", metavar="SERVICE", help="Reset stats for all keys or specific service")
    
    args = parser.parse_args()
    
    if args.status:
        key_manager.print_status()
    elif args.list:
        key_manager.list_keys(args.list)
    elif args.add:
        service, key, name = args.add
        key_manager.add_key(service, key, name)
    elif args.remove:
        service, name = args.remove
        key_manager.remove_key(service, name)
    elif args.update:
        service, old_name, new_key, new_name = args.update
        key_manager.update_key(service, old_name, new_key, new_name)
    elif args.reset:
        if args.reset:
            key_manager.reset_key_stats(args.reset)
        else:
            key_manager.reset_key_stats()
    else:
        # Default: show status
        key_manager.print_status() 