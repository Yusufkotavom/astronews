
# Component Usage Examples

## Basic Usage
```astro
---
import Layout from '@/layouts/Layout.astro';
import About1 from '@/components/content/about/About1.astro';
import Services1 from '@/components/content/services/Services1.astro';
import Pricing1 from '@/components/content/pricing/Pricing1.astro';
---

<Layout title="My Page">
  <About1 
    title="About Our Company"
    description="Learn more about our mission and values"
  />
  
  <Services1 
    title="Our Services"
    description="Discover what we can do for you"
  />
  
  <Pricing1 
    title="Pricing Plans"
    description="Choose the perfect plan for your needs"
  />
</Layout>
```

## With Custom Props
```astro
---
import Layout from '@/layouts/Layout.astro';
import DigitalProduct from '@/components/content/landing/DigitalProduct.astro';

// Your JSON data
const businessData = {
  business: {
    name: "Kotacom",
    phone: "+6281234567890",
    address: "Bekasi, Indonesia"
  },
  hero: {
    title: "Jasa Pembuatan Website Bekasi",
    subtitle: "Website profesional untuk bisnis Anda",
    badge_text: "Terpercaya & Berkualitas"
  }
  // ... more data
};
---

<Layout title="Digital Product Landing">
  <DigitalProduct {...businessData} />
</Layout>
```

## Available Components

### Landing Pages
- `Agency.astro` - Digital agency landing page
- `Crypto.astro` - Cryptocurrency landing page  
- `DigitalProduct.astro` - Digital product showcase
- `Event.astro` - Event promotion page
- `MobileApplication.astro` - Mobile app showcase
- `Ngo.astro` - Non-profit organization page
- `OpenSource.astro` - Open source project page
- `PhysicalProduct.astro` - Physical product showcase
- `PreLaunch.astro` - Pre-launch campaign page
- `Saas.astro` - Software as a service page

### Content Sections
- `About1.astro`, `About2.astro`, `About3.astro` - About us sections
- `Services1.astro`, `Services2.astro`, `Services3.astro`, `Services4.astro` - Service showcases
- `Pricing1.astro`, `Pricing2.astro`, `Pricing3.astro`, `Pricing4.astro` - Pricing tables
- `Team1.astro`, `Team2.astro`, `Team3.astro`, `Team4.astro` - Team showcases
- `Testimonials1.astro`, `Testimonials2.astro` - Customer testimonials

### Forms
- `Contact1.astro`, `Contact2.astro`, `Contact3.astro`, `Contact4.astro` - Contact forms
- `Login1.astro`, `Login2.astro`, `Login3.astro` - Login forms
- `Register1.astro`, `Register2.astro`, `Register3.astro` - Registration forms

### Other
- `Blog/Article.astro` - Blog post template
- `Blog/Homepage.astro` - Blog listing page
- `Portfolio/ProjectShowcase.astro` - Portfolio showcase
- `Status/4041.astro`, `4042.astro`, `4043.astro` - 404 error pages
- `Status/5001.astro`, `5002.astro` - 500 error pages
