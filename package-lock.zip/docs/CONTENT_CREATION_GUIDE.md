# Content Creation Guide

This comprehensive guide covers all the different ways to add content to your Astro site, including blog posts, pages, and WordPress imports.

## Table of Contents

1. [Blog Posts](#blog-posts)
   - [Markdown Posts](#markdown-posts)
   - [MDX Posts](#mdx-posts)
2. [Static Pages](#static-pages)
   - [Markdown Pages](#markdown-pages)
   - [MDX Pages](#mdx-pages)
3. [WordPress Imports](#wordpress-imports)
   - [Importing Posts](#importing-posts)
   - [Importing Pages](#importing-pages)
4. [Content Organization](#content-organization)
5. [SEO Best Practices](#seo-best-practices)
6. [Commands Reference](#commands-reference)

## Blog Posts

### Markdown Posts

**Use for**: Simple text content, standard blog posts, articles without interactive elements.

**File Location**: `src/content/post/`
**File Extension**: `.md`

#### Frontmatter Structure
```yaml
---
title: "Your Post Title"
description: "Brief description of your post"
publishDate: "2024-01-15T00:00:00.000Z"
updateDate: "2024-01-20T00:00:00.000Z"  # Optional
author: "Author Name"
category: "Category Name"
tags: ["tag1", "tag2", "tag3"]
featured: true  # Optional, for featured posts
draft: false    # Set to true to hide from public
image: "/path/to/image.jpg"  # Optional
imageAlt: "Image description"  # Optional
---
```

#### Example
```markdown
---
title: "Sample Markdown Blog Post"
description: "This is a sample blog post written in plain Markdown."
publishDate: "2024-01-15T00:00:00.000Z"
author: "Kotacom Team"
category: "Tutorial"
tags: ["markdown", "blog", "tutorial"]
featured: true
draft: false
---

# Sample Markdown Blog Post

This is a sample blog post written in **plain Markdown**.

## Why Use Markdown?

Markdown is perfect for:
- **Easy to learn** - Simple syntax
- **Fast to write** - No complex HTML
- **Portable** - Works everywhere
- **Version control friendly** - Easy to track changes

## Basic Formatting

- **Bold text** using `**bold**`
- *Italic text* using `*italic*`
- `Inline code` using backticks

### Lists

- First item
- Second item
  - Nested item
- Third item

### Code Blocks

```javascript
function greet(name) {
  return `Hello, ${name}!`;
}
```

### Links and Images

[Link to external site](https://example.com)

![Sample image](/images/sample.jpg)

## Conclusion

Markdown is excellent for simple blog posts.
```

#### URL Structure
- **Generated URL**: `/post-slug`
- **Example**: `/sample-markdown-blog-post`

### MDX Posts

**Use for**: Interactive content, custom components, advanced styling, dynamic content.

**File Location**: `src/content/post/`
**File Extension**: `.mdx`

#### Frontmatter Structure
```yaml
---
title: "Your MDX Post Title"
description: "Brief description"
publishDate: "2024-01-16T00:00:00.000Z"
updateDate: "2024-01-21T00:00:00.000Z"  # Optional
author: "Author Name"
category: "Category"
tags: ["tag1", "tag2"]
featured: true
draft: false
image: "/path/to/image.jpg"
imageAlt: "Image description"
layout: "../../layouts/Layout.astro"  # Custom layout
components:  # List of components to import
  - Alert
  - CodeBlock
  - Callout
  - ImageGallery
---
```

#### Component Imports
```mdx
import Alert from '../../components/mdx/Alert.astro';
import CodeBlock from '../../components/mdx/CodeBlock.astro';
import Callout from '../../components/mdx/Callout.astro';
import ImageGallery from '../../components/mdx/ImageGallery.astro';
```

#### Example
```mdx
---
title: "Sample MDX Blog Post"
description: "This is a sample blog post written in MDX."
publishDate: "2024-01-16T00:00:00.000Z"
author: "Kotacom Team"
category: "Advanced Tutorial"
tags: ["mdx", "components", "interactive"]
featured: true
draft: false
components:
  - Alert
  - CodeBlock
  - Callout
---

import Alert from '../../components/mdx/Alert.astro';
import CodeBlock from '../../components/mdx/CodeBlock.astro';
import Callout from '../../components/mdx/Callout.astro';

# Sample MDX Blog Post

This is a sample blog post written in **MDX** (Markdown + JSX).

<Alert type="info" title="MDX Benefits">
  - Use React components in your content
  - Create interactive elements
  - Custom styling and layouts
  - Dynamic content generation
</Alert>

## Interactive Components

<Alert type="success" title="Success Alert">
  This is a success message!
</Alert>

<Callout type="tip" title="Pro Tip">
  Use MDX for posts that need interactive elements.
</Callout>

## Code Examples

<CodeBlock language="javascript" title="React Component Example">
```javascript
import React from 'react';

function InteractiveButton({ children, onClick }) {
  return (
    <button onClick={onClick}>
      {children}
    </button>
  );
}
```
</CodeBlock>

## Conclusion

MDX is powerful for interactive content.
```

#### URL Structure
- **Generated URL**: `/post-slug`
- **Example**: `/sample-mdx-blog-post`

## Static Pages

### Markdown Pages

**Use for**: Simple static content, About pages, Privacy Policy, Terms of Service.

**File Location**: `src/content/page/`
**File Extension**: `.md`

#### Frontmatter Structure
```yaml
---
title: "Your Page Title"
description: "Brief description of your page"
publishDate: "2024-01-15T00:00:00.000Z"  # Optional
updateDate: "2024-01-20T00:00:00.000Z"   # Optional
author: "Author Name"                     # Optional
featured: false                          # Optional
draft: false                             # Set to true to hide
image: "/path/to/image.jpg"              # Optional
imageAlt: "Image description"            # Optional
---
```

#### Example
```markdown
---
title: "About Us"
description: "Learn about our company, mission, and team."
---

# About Us

## Our Story

[Company story and history]

## Our Mission

[Mission statement and values]

## Our Team

### John Doe - CEO
[Team member description]

### Jane Smith - CTO
[Team member description]

## Our Values

- **Innovation** - We embrace new ideas
- **Quality** - We deliver excellence
- **Integrity** - We act with honesty
```

#### URL Structure
- **Generated URL**: `/page-slug`
- **Example**: `/about-us`

### MDX Pages

**Use for**: Interactive pages, landing pages, contact forms, pricing calculators.

**File Location**: `src/content/page/`
**File Extension**: `.mdx`

#### Frontmatter Structure
```yaml
---
title: "Your MDX Page Title"
description: "Brief description of your page"
publishDate: "2024-01-16T00:00:00.000Z"  # Optional
updateDate: "2024-01-21T00:00:00.000Z"   # Optional
author: "Author Name"                     # Optional
featured: false                          # Optional
draft: false                             # Set to true to hide
image: "/path/to/image.jpg"              # Optional
imageAlt: "Image description"            # Optional
layout: "../../layouts/Layout.astro"     # Custom layout
components:                              # List of components to import
  - Alert
  - CodeBlock
  - Callout
  - ImageGallery
---
```

#### Example
```mdx
---
title: "Contact Us"
description: "Get in touch with our team."
components:
  - Alert
  - Callout
---

import Alert from '../../components/mdx/Alert.astro';
import Callout from '../../components/mdx/Callout.astro';

# Contact Us

<Alert type="info" title="Get in Touch">
  We'd love to hear from you! Use the form below or contact us directly.
</Alert>

## Contact Information

- **Email**: contact@example.com
- **Phone**: +1 (555) 123-4567
- **Address**: 123 Main St, City, State 12345

## Office Hours

- Monday - Friday: 9:00 AM - 6:00 PM
- Saturday: 10:00 AM - 4:00 PM
- Sunday: Closed

<Callout type="tip" title="Response Time">
  We typically respond to inquiries within 24 hours during business days.
</Callout>
```

#### URL Structure
- **Generated URL**: `/page-slug`
- **Example**: `/contact-us`

## WordPress Imports

### Importing Posts

**Use for**: Migrating existing WordPress blog content to Astro.

#### Prerequisites
1. WordPress site with REST API enabled
2. Access to WordPress admin (if needed)
3. Node.js and npm installed

#### Configuration
Edit `scripts/wordpress-config.js`:
```javascript
export const WORDPRESS_CONFIG = {
  WORDPRESS_URL: 'https://your-wordpress-site.com',
  POSTS_ENDPOINT: '/wp-json/wp/v2/posts',
  POSTS_PER_PAGE: 100,
  MAX_POSTS: 1000,
  CLEAN_HTML: true,
  DOWNLOAD_IMAGES: true,
  OPTIMIZE_IMAGES: true
};
```

#### Import Commands
```bash
# Test WordPress connection
npm run wordpress:test

# Import all WordPress content
npm run wordpress:import

# Fix WordPress CSS classes in existing content
npm run wordpress:fix-css
```

#### What Gets Imported
- **Title and content** from WordPress posts
- **Author information** (if available)
- **Categories and tags**
- **Featured images**
- **Publish and update dates**
- **SEO metadata**

#### Content Cleaning
The import process automatically:
- Removes WordPress-specific HTML
- Converts WordPress CSS classes to Tailwind
- Replaces WordPress icons with emojis
- Fixes malformed HTML
- Optimizes images

### Importing Pages

**Use for**: Migrating WordPress static pages to Astro.

#### Configuration
```javascript
export const WORDPRESS_CONFIG = {
  WORDPRESS_URL: 'https://your-wordpress-site.com',
  PAGES_ENDPOINT: '/wp-json/wp/v2/pages',
  MAX_PAGES: 100,
  CLEAN_HTML: true,
  DOWNLOAD_IMAGES: true
};
```

#### What Gets Imported
- **Title and content** from WordPress pages
- **Page hierarchy** (parent/child relationships)
- **Custom fields** (if configured)
- **SEO metadata**
- **Featured images**

## Content Organization

### File Structure
```
src/content/
├── post/                    # Blog posts
│   ├── sample-markdown-post.md
│   ├── sample-mdx-post.mdx
│   └── wordpress-import-guide.md
├── page/                    # Static pages
│   ├── sample-markdown-page.md
│   ├── sample-mdx-page.mdx
│   └── about.md
└── config.ts               # Content collection schema
```

### Naming Conventions
- **Use kebab-case** for filenames: `my-blog-post.md`
- **Use descriptive names** that reflect content
- **Include date prefix** for time-sensitive content: `2024-01-15-my-post.md`

### Content Categories
- **Tutorials**: How-to guides and educational content
- **News**: Company updates and announcements
- **Case Studies**: Project showcases and success stories
- **Resources**: Tools, templates, and downloads

## SEO Best Practices

### Frontmatter SEO
```yaml
---
title: "SEO-Optimized Title with Keywords"
description: "Compelling description under 160 characters with relevant keywords"
publishDate: "2024-01-15T00:00:00.000Z"
author: "Author Name"
category: "Relevant Category"
tags: ["keyword1", "keyword2", "keyword3"]
image: "/path/to/optimized-image.jpg"
imageAlt: "Descriptive alt text for accessibility and SEO"
---
```

### Content SEO
1. **Use proper heading hierarchy** (H1 → H2 → H3)
2. **Include relevant keywords** naturally in content
3. **Write compelling meta descriptions** (under 160 characters)
4. **Add alt text to all images**
5. **Use internal links** to related content
6. **Keep content scannable** with short paragraphs and lists

### Technical SEO
- **Automatic meta tags** from frontmatter
- **Open Graph tags** for social sharing
- **Twitter Cards** for Twitter sharing
- **Structured data** (JSON-LD)
- **Canonical URLs** to prevent duplicate content
- **Sitemap** inclusion

## Commands Reference

### Development
```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Content Management
```bash
# Import WordPress content
npm run wordpress:import

# Test WordPress connection
npm run wordpress:test

# Fix WordPress CSS classes
npm run wordpress:fix-css

# Clean build artifacts
npm run clean
```

### Optimization
```bash
# Optimize images
npm run images:optimize

# Build with image optimization
npm run build:optimized

# Production build
npm run build:production
```

### Analysis
```bash
# Analyze build output
npm run analyze

# Run Lighthouse audit
npm run lighthouse

# Preview with analysis
npm run preview:analyze
```

## When to Use Each Method

### Use Markdown for:
- ✅ Simple text content
- ✅ Standard blog posts
- ✅ Basic formatting needs
- ✅ Fast content creation
- ✅ No interactive elements

### Use MDX for:
- ✅ Interactive components
- ✅ Custom styling
- ✅ Dynamic content
- ✅ Complex layouts
- ✅ Reusable components

### Use WordPress Import for:
- ✅ Migrating existing WordPress sites
- ✅ Bulk content import
- ✅ Preserving SEO value
- ✅ Maintaining content structure
- ✅ Automatic content cleaning

## Best Practices

### Content Creation
1. **Choose the right format** for your content needs
2. **Write compelling titles** that include keywords
3. **Create engaging descriptions** that encourage clicks
4. **Use proper heading structure** for readability
5. **Include relevant images** with descriptive alt text
6. **Add internal links** to related content

### Content Management
1. **Organize content logically** in appropriate directories
2. **Use consistent naming conventions** for files
3. **Keep frontmatter clean** and well-structured
4. **Review and edit content** before publishing
5. **Test content rendering** in development
6. **Monitor performance** and SEO metrics

### WordPress Migration
1. **Backup WordPress site** before importing
2. **Test with small content subset** first
3. **Verify WordPress REST API** accessibility
4. **Monitor import process** for errors
5. **Review imported content** for accuracy
6. **Fix styling issues** with CSS fix script

## Troubleshooting

### Common Issues

#### Build Errors
```bash
# Check for syntax errors in frontmatter
npm run build

# Verify content collection schema
# Check for missing required fields
```

#### WordPress Import Issues
```bash
# Test WordPress connection
npm run wordpress:test

# Check WordPress REST API
# Verify content permissions
```

#### Styling Issues
```bash
# Fix WordPress CSS classes
npm run wordpress:fix-css

# Check component imports
# Verify Tailwind classes
```

### Debug Commands
```bash
# Verbose build output
DEBUG=* npm run build

# Check imported files
ls -la src/content/post/
ls -la src/content/page/

# Test specific content
npm run dev
# Navigate to content URLs in browser
```

## Conclusion

Your Astro site provides multiple powerful ways to create and manage content. Choose the method that best fits your content needs and technical requirements.

### Quick Reference

| Content Type | Format | Use Case | File Location |
|-------------|--------|----------|---------------|
| Simple Blog Post | Markdown | Text content | `src/content/post/` |
| Interactive Post | MDX | Components needed | `src/content/post/` |
| Static Page | Markdown | About, Contact | `src/content/page/` |
| Interactive Page | MDX | Forms, Calculators | `src/content/page/` |
| WordPress Content | Import | Migration | Auto-generated |

### Next Steps

- [Create your first blog post](/blog/sample-markdown-post)
- [Explore interactive content](/blog/sample-mdx-post)
- [Learn about WordPress imports](/blog/wordpress-import-guide)
- [Optimize your content for SEO](/seo-guide)

---

*This guide covers all content creation methods available in your Astro site. For specific questions or advanced configurations, refer to the individual guides or contact support.* 