#!/usr/bin/env python3
"""
Simple Unsplash Image Generator
Automatically reads from CSV, uses business_type from JSON, updates CSV
"""

import json
import os
import requests
import time
import random
import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional
import cloudinary
import cloudinary.uploader

# Import API Key Manager
from api_key_manager import key_manager

# Load environment variables from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    print("Warning: python-dotenv not installed. Install with: pip install python-dotenv")

class SimpleUnsplashGenerator:
    def __init__(self):
        # Get Unsplash API key from key manager
        unsplash_key = key_manager.get_available_key("unsplash")
        if not unsplash_key:
            print("❌ No available Unsplash API keys found!")
            print("Add Unsplash keys using: python api_key_manager.py --add unsplash YOUR_KEY 'Key Name'")
            exit(1)
        
        self.unsplash_api_key = unsplash_key.key
        self.current_key = unsplash_key
        self.unsplash_url = "https://api.unsplash.com"
        self.headers = {
            "Authorization": f"Client-ID {self.unsplash_api_key}",
            "Accept-Version": "v1"
        }
        
        print(f"✅ Using Unsplash key: {unsplash_key.name}")
        
        # Setup Cloudinary if credentials provided
        self.cloudinary_configured = False
        cloudinary_api_key = os.getenv("CLOUDINARY_API_KEY")
        cloudinary_api_secret = os.getenv("CLOUDINARY_API_SECRET")
        cloudinary_cloud_name = os.getenv("CLOUDINARY_CLOUD_NAME")
        
        if cloudinary_api_key and cloudinary_api_secret and cloudinary_cloud_name:
            cloudinary.config(
                cloud_name=cloudinary_cloud_name,
                api_key=cloudinary_api_key,
                api_secret=cloudinary_api_secret
            )
            self.cloudinary_configured = True
            print("☁️ Cloudinary configured")
        else:
            print("⚠️ Cloudinary not configured - images will be saved locally only")
        
        # Create directories
        self.assets_dir = Path("assets/images")
        self.assets_dir.mkdir(parents=True, exist_ok=True)
        
        # CSV file path
        self.csv_file = "data/keyword_new.csv"
    
    def search_unsplash_image(self, keyword: str, image_name: str) -> Optional[str]:
        """Search and download random image from Unsplash using keyword with key rotation"""
        
        def search_with_key(api_key, keyword, image_name):
            """Wrapper function for Unsplash search with specific key"""
            headers = {
                "Authorization": f"Client-ID {api_key}",
                "Accept-Version": "v1"
            }
            
            # Search for images with keyword
            search_url = f"{self.unsplash_url}/search/photos"
            params = {
                "query": keyword,
                "per_page": 30,  # Get more results for randomness
                "orientation": "landscape"
            }
            
            response = requests.get(search_url, headers=headers, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                results = data.get("results", [])
                
                if results:
                    # Get random image from results
                    random_image = random.choice(results)
                    image_url = random_image["urls"]["regular"]  # Medium size
                    image_id = random_image["id"]
                    
                    print(f"📸 Found image for keyword: {keyword}")
                    
                    # Download the image
                    img_response = requests.get(image_url, timeout=30)
                    if img_response.status_code == 200:
                        # Save image locally
                        image_path = self.assets_dir / f"{image_name}.jpg"
                        
                        with open(image_path, "wb") as f:
                            f.write(img_response.content)
                        
                        print(f"✅ Image saved: {image_path}")
                        
                        # Upload to Cloudinary if configured
                        if self.cloudinary_configured:
                            cloudinary_url = self.upload_to_cloudinary(image_path, image_name)
                            if cloudinary_url:
                                return cloudinary_url
                        
                        # Return relative path for local storage
                        return f"/assets/images/{image_name}.jpg"
                    else:
                        print(f"❌ Failed to download image: {img_response.status_code}")
                        return None
                else:
                    print(f"❌ No images found for keyword: {keyword}")
                    return None
            else:
                print(f"❌ Search failed: {response.status_code} - {response.text}")
                return None
        
        try:
            print(f"🔍 Searching Unsplash with keyword: '{keyword}' using key rotation...")
            result = key_manager.execute_with_rotation("unsplash", search_with_key, keyword, image_name)
            return result
        except Exception as e:
            print(f"❌ Error searching image with key rotation: {e}")
            return None
    
    def upload_to_cloudinary(self, image_path: Path, image_name: str) -> Optional[str]:
        """Upload image to Cloudinary"""
        try:
            result = cloudinary.uploader.upload(
                str(image_path),
                public_id=f"website-images/{image_name}",
                folder="kotacom"
            )
            base_url = result['secure_url']
            
            # Add optimization parameters for better performance
            optimized_url = base_url.replace('/upload/', '/upload/f_auto,q_auto,w_auto,dpr_auto/')
            
            print(f"☁️ Uploaded to Cloudinary: {optimized_url}")
            return optimized_url
        except Exception as e:
            print(f"❌ Cloudinary upload error: {e}")
            return None
    
    def process_json_file(self, json_file: str, keyword: str) -> bool:
        """Process a single JSON file with keyword"""
        try:
            print(f"\n🔄 Processing: {json_file}")
            print(f"🎯 Keyword: {keyword}")
            
            # Load JSON
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Add keyword to data
            data["keyword"] = keyword
            
            # Generate images for each section
            sections = ["hero", "features", "about_us", "services", "testimonials", "case_studies", "content"]
            image_results = {}
            
            for section in sections:
                image_name = f"{keyword.replace(' ', '_').replace('/', '_')}_{section}"
                image_url = self.search_unsplash_image(keyword, image_name)
                
                if image_url:
                    image_results[section] = image_url
                
                # Small delay
                time.sleep(1)
            
            if not image_results:
                print("❌ No images downloaded!")
                return False
            
            # Update JSON with image paths
            if "hero" in data and "hero" in image_results:
                data["hero"]["image_url"] = image_results["hero"]
            
            if "features" in data and "features" in image_results:
                data["features"]["image_url"] = image_results["features"]
            
            if "info" in data and "about_us" in image_results:
                data["info"]["image_url"] = image_results["about_us"]
            
            if "content" in data and "content" in image_results:
                data["content"]["image_url"] = image_results["content"]
            
            # Add metadata
            data["generated_images"] = {
                "generated_at": datetime.now().isoformat(),
                "total_images": len(image_results),
                "search_keyword": keyword,
                "source": "Unsplash API"
            }
            
            # Save updated JSON
            output_file = json_file.replace('.json', '_with_images.json')
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            print(f"✅ Updated JSON: {output_file}")
            return True
            
        except Exception as e:
            print(f"❌ Error processing {json_file}: {e}")
            return False
    
    def update_csv_status(self, keyword: str) -> None:
        """Update keyword status to 'prompt 3' in CSV"""
        try:
            if not os.path.exists(self.csv_file):
                print(f"❌ CSV file not found: {self.csv_file}")
                return
            
            df = pd.read_csv(self.csv_file)
            mask = df['keyword'].str.lower().str.strip() == keyword.lower().strip()
            
            if mask.any():
                df.loc[mask, 'status'] = 'prompt 3'
                df.to_csv(self.csv_file, index=False)
                print(f"✅ Updated CSV status for: {keyword}")
            else:
                print(f"❌ Keyword not found in CSV: {keyword}")
                
        except Exception as e:
            print(f"❌ Error updating CSV: {e}")
    
    def run_automatic(self):
        """Main automatic processing function"""
        print("🚀 Automatic Image Generator")
        print("=" * 40)
        
        # Check CSV file
        if not os.path.exists(self.csv_file):
            print(f"❌ CSV file not found: {self.csv_file}")
            return
        
        # Read CSV
        try:
            df = pd.read_csv(self.csv_file)
            print(f"📊 Loaded {len(df)} keywords from CSV")
        except Exception as e:
            print(f"❌ Error reading CSV: {e}")
            return
        
        # Find keywords ready for image generation (status = 'prompt 2' or 'promt 2')
        pending = df[df['status'].isin(['prompt 2', 'promt 2'])].copy()
        
        if pending.empty:
            print("✅ No keywords ready for image generation (status = 'prompt 2')")
            return
        
        print(f"🎯 Found {len(pending)} keywords ready for processing")
        
        # Process each keyword
        for idx, row in pending.iterrows():
            keyword = row['keyword']
            json_file = row.get('json_file_enriched', '')
            
            if not json_file:
                print(f"⚠️  Skipping '{keyword}' - no JSON file")
                continue
            
            # Construct JSON file path
            json_path = f"output/{json_file}"
            if not json_path.endswith('.json'):
                json_path += '.json'
            
            if not os.path.exists(json_path):
                print(f"⚠️  Skipping '{keyword}' - JSON not found: {json_path}")
                continue
            
            # Load JSON to get business_type
            try:
                with open(json_path, 'r', encoding='utf-8') as f:
                    json_data = json.load(f)
                
                # Extract business_type from JSON (try different structures)
                business_type = json_data.get("business_type", "")
                if not business_type:
                    # Try nested structure
                    business = json_data.get("business", {})
                    business_type = business.get("type", "")
                
                if not business_type:
                    print(f"⚠️  Skipping '{keyword}' - no business_type found in JSON")
                    continue
                
                print(f"🏢 Using business_type: {business_type}")
                
                # Process the file with business_type as keyword
                success = self.process_json_file(json_path, business_type)
                
                if success:
                    # Update CSV status
                    self.update_csv_status(keyword)
                    print(f"✅ Completed: {keyword}")
                else:
                    print(f"❌ Failed: {keyword}")
                
            except Exception as e:
                print(f"❌ Error processing {keyword}: {e}")
            
            # Delay between keywords
            time.sleep(2)
        
        print(f"\n🎉 Automatic processing completed!")
        print(f"📊 Processed {len(pending)} keywords")

def main():
    generator = SimpleUnsplashGenerator()
    generator.run_automatic()

if __name__ == "__main__":
    main() 