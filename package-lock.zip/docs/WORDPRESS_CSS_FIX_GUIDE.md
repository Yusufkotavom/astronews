# WordPress CSS Fix Guide

## Overview

This guide explains how we've fixed WordPress-specific CSS classes in imported content to ensure proper dark mode and light mode compatibility with our Astro project.

## Problem

WordPress content imported from the original site contained custom CSS classes that don't exist in our Astro project:

- `gemini-blue`, `gemini-yellow`, `gemini-green`, `gemini-purple` classes
- `dashicons` classes for icons
- `rh-icon` classes for custom icons
- WordPress-specific styling that doesn't work with our Tailwind CSS system

## Solution

We implemented a comprehensive solution with three components:

### 1. Updated Import Script (`scripts/import-wordpress-posts.js`)

The WordPress import script now automatically converts WordPress CSS classes to Tailwind equivalents:

```javascript
// Replace WordPress-specific CSS classes with Tailwind equivalents
html = html.replace(/class="([^"]*?)gemini-blue([^"]*?)"/g, 'class="$1text-blue-600$2"');
html = html.replace(/class="([^"]*?)gemini-yellow([^"]*?)"/g, 'class="$1text-yellow-500$2"');
html = html.replace(/class="([^"]*?)gemini-green([^"]*?)"/g, 'class="$1text-green-500$2"');
html = html.replace(/class="([^"]*?)gemini-purple([^"]*?)"/g, 'class="$1text-purple-500$2"');

// Replace background classes
html = html.replace(/class="([^"]*?)bg-gemini-blue([^"]*?)"/g, 'class="$1bg-blue-600$2"');
html = html.replace(/class="([^"]*?)bg-gemini-yellow([^"]*?)"/g, 'class="$1bg-yellow-500$2"');
html = html.replace(/class="([^"]*?)bg-gemini-green([^"]*?)"/g, 'class="$1bg-green-500$2"');
html = html.replace(/class="([^"]*?)bg-gemini-purple([^"]*?)"/g, 'class="$1bg-purple-500$2"');

// Replace dashicons with emojis
html = html.replace(/<span class="dashicons dashicons-book-alt[^"]*"><\/span>/g, '📚');
html = html.replace(/<span class="dashicons dashicons-money-alt[^"]*"><\/span>/g, '💰');
html = html.replace(/<span class="dashicons dashicons-media-text[^"]*"><\/span>/g, '📄');

// Replace rh-icon classes with emojis
html = html.replace(/<i class="rh-icon rh-25-lightbulb[^"]*"><\/i>/g, '💡');
html = html.replace(/<i class="rh-icon rh-98-money[^"]*"><\/i>/g, '💵');
html = html.replace(/<i class="rh-icon rh-33-truck[^"]*"><\/i>/g, '🚚');
```

### 2. CSS Fix Script (`scripts/fix-wordpress-css.js`)

A standalone script to fix existing imported content:

```bash
npm run wordpress:fix-css
```

This script:
- Processes all existing `.md` files in `src/content/post` and `src/content/page`
- Replaces WordPress CSS classes with Tailwind equivalents
- Converts WordPress icons to emojis
- Preserves frontmatter and content structure

### 3. Enhanced HtmlContent Component (`src/components/content/HtmlContent.astro`)

The component that renders WordPress HTML content now includes comprehensive CSS for:

- **Dark mode support**: All elements adapt to dark/light themes
- **Responsive design**: Mobile-friendly styling
- **Fallback styles**: Ensures content looks good even with missing classes
- **WordPress class compatibility**: Backward compatibility for any remaining WordPress classes

## Class Mappings

| WordPress Class | Tailwind Equivalent | Description |
|----------------|-------------------|-------------|
| `gemini-blue` | `text-blue-600` | Blue text color |
| `gemini-yellow` | `text-yellow-500` | Yellow text color |
| `gemini-green` | `text-green-500` | Green text color |
| `gemini-purple` | `text-purple-500` | Purple text color |
| `bg-gemini-blue` | `bg-blue-600` | Blue background |
| `bg-gemini-yellow` | `bg-yellow-500` | Yellow background |
| `bg-gemini-green` | `bg-green-500` | Green background |
| `bg-gemini-purple` | `bg-purple-500` | Purple background |
| `hover:text-gemini-blue` | `hover:text-blue-600` | Blue hover text |
| `hover:bg-gemini-blue` | `hover:bg-blue-700` | Blue hover background |

## Icon Replacements

| WordPress Icon | Emoji Replacement | Usage |
|---------------|------------------|-------|
| `dashicons-book-alt` | 📚 | Book-related content |
| `dashicons-money-alt` | 💰 | Pricing/financial content |
| `dashicons-media-text` | 📄 | Document content |
| `dashicons-book` | 📖 | Reading content |
| `dashicons-format-image` | 🖼️ | Image-related content |
| `dashicons-shield-alt` | 🛡️ | Security/protection content |
| `rh-25-lightbulb` | 💡 | Ideas/tips content |
| `rh-98-money` | 💵 | Money/financial content |
| `rh-33-truck` | 🚚 | Delivery/shipping content |

## Usage

### For New Imports

New WordPress content will automatically be cleaned during import:

```bash
npm run wordpress:import
```

### For Existing Content

Fix existing imported content:

```bash
npm run wordpress:fix-css
```

### Manual Fix

If you need to fix specific files manually, you can run:

```bash
node scripts/fix-wordpress-css.js
```

## Benefits

1. **Dark Mode Compatibility**: All content now works properly with dark/light themes
2. **Consistent Styling**: Uses our project's Tailwind CSS system
3. **Better Performance**: Removes unnecessary WordPress-specific CSS
4. **Maintainability**: Standardized styling across all content
5. **Accessibility**: Proper contrast ratios and readable text

## Testing

After running the fix, test your content:

1. **Build the project**: `npm run build`
2. **Check dark mode**: Toggle dark mode and verify content looks good
3. **Test responsiveness**: Check content on mobile devices
4. **Verify links**: Ensure all links and buttons work correctly

## Troubleshooting

### Content Still Shows WordPress Styling

1. Run the fix script again: `npm run wordpress:fix-css`
2. Check if the file was processed (look for console output)
3. Manually inspect the `.md` file for remaining WordPress classes

### Build Errors

1. Check for syntax errors in the `.md` files
2. Ensure all HTML is properly closed
3. Verify frontmatter is correctly formatted

### Missing Icons

If icons don't appear:
1. Check if the emoji is supported by your system
2. Consider replacing with FontAwesome icons
3. Use text alternatives for accessibility

## Future Improvements

- Add more icon mappings as needed
- Implement FontAwesome icon replacement option
- Add validation for cleaned content
- Create preview mode for content before saving

## Files Modified

- `scripts/import-wordpress-posts.js` - Updated cleaning function
- `scripts/fix-wordpress-css.js` - New fix script
- `src/components/content/HtmlContent.astro` - Enhanced styling
- `package.json` - Added fix script command

## Commands Summary

```bash
# Fix existing WordPress CSS
npm run wordpress:fix-css

# Import new WordPress content (with automatic CSS cleaning)
npm run wordpress:import

# Build project to test changes
npm run build

# Start development server
npm run dev
``` 