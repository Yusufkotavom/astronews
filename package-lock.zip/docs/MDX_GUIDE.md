# 🚀 MDX Guide for Astro

## 📋 Overview

MDX (Markdown + JSX) allows you to use React components and JSX syntax in your Markdown files. This enables you to create rich, interactive content with custom components while maintaining the simplicity of Markdown.

## 🎯 What You Can Do with MDX

- ✅ **Use custom components** in your content
- ✅ **Interactive elements** like buttons, forms, and charts
- ✅ **JavaScript expressions** and conditional rendering
- ✅ **Reusable components** across multiple files
- ✅ **Type safety** with TypeScript
- ✅ **Performance optimized** components

---

## 🔧 Setup

### 1. Installation
```bash
npm install @astrojs/mdx
```

### 2. Configuration
The MDX integration is already configured in `astro.config.mjs`:

```javascript
import mdx from '@astrojs/mdx';

export default defineConfig({
  integrations: [
    mdx({
      syntaxHighlight: 'prism',
      remarkPlugins: [],
      rehypePlugins: [],
      frontmatter: {
        required: ['title'],
        optional: {
          description: '',
          author: 'Kotacom Team',
          publishDate: new Date().toISOString(),
          category: 'General',
          tags: [],
          image: '',
          featured: false,
          draft: false
        }
      }
    }),
    // ... other integrations
  ],
});
```

---

## 📝 Creating MDX Files

### File Structure
Create `.mdx` files in your content directories:

```
src/content/
├── post/
│   ├── my-post.mdx          # MDX post
│   └── another-post.md      # Regular Markdown post
└── page/
    ├── about.mdx            # MDX page
    └── contact.md           # Regular Markdown page
```

### Basic MDX File
```mdx
---
title: "My MDX Post"
description: "This is an MDX post with interactive components"
publishDate: "2024-01-15"
author: "Kotacom Team"
category: "Tutorial"
tags: ["mdx", "astro", "components"]
---

# Welcome to MDX!

This is a regular Markdown heading.

<Alert type="info" title="Information">
  This is a custom component!
</Alert>

You can use **Markdown** and <Component /> together.
```

---

## 🧩 Available Components

### 1. Alert Component
Display different types of alerts with icons.

```mdx
<Alert type="info" title="Information">
  This is an informational alert.
</Alert>

<Alert type="warning" title="Warning">
  This is a warning alert.
</Alert>

<Alert type="error" title="Error">
  This is an error alert.
</Alert>

<Alert type="success" title="Success">
  This is a success alert.
</Alert>
```

**Props:**
- `type`: `'info' | 'warning' | 'error' | 'success'` (default: `'info'`)
- `title`: Optional title for the alert

### 2. Callout Component
Highlight important information with styled callouts.

```mdx
<Callout type="tip" title="Pro Tip">
  Use callouts to highlight important information.
</Callout>

<Callout type="important">
  This is an important callout without a custom title.
</Callout>
```

**Props:**
- `type`: `'note' | 'tip' | 'warning' | 'important'` (default: `'note'`)
- `title`: Optional title (uses default if not provided)

### 3. CodeBlock Component
Display code with syntax highlighting and copy functionality.

```mdx
<CodeBlock 
  code={`function greet(name) {
  return \`Hello, \${name}!\`;
}`} 
  lang="javascript" 
  title="Example Function" 
  showLineNumbers={true} 
/>
```

**Props:**
- `code`: The code string to display
- `lang`: Language for syntax highlighting (default: `'text'`)
- `title`: Optional title for the code block
- `showLineNumbers`: Show line numbers (default: `false`)

### 4. ImageGallery Component
Display multiple images in a responsive grid.

```mdx
<ImageGallery 
  images={[
    {
      src: "/images/image1.jpg",
      alt: "Description 1",
      caption: "Caption 1"
    },
    {
      src: "/images/image2.jpg",
      alt: "Description 2",
      caption: "Caption 2"
    }
  ]}
  columns={2}
  gap="md"
/>
```

**Props:**
- `images`: Array of image objects with `src`, `alt`, and optional `caption`
- `columns`: Number of columns (1-4, default: 2)
- `gap`: Gap size between images (`'sm' | 'md' | 'lg'`, default: `'md'`)

---

## 💡 Advanced Features

### JavaScript Expressions
You can use JavaScript expressions in your MDX:

```mdx
The current year is: {new Date().getFullYear()}

{/* Conditional rendering */}
{Math.random() > 0.5 ? (
  <Alert type="success">Random success!</Alert>
) : (
  <Alert type="info">Random info!</Alert>
)}

{/* Array mapping */}
{['apple', 'banana', 'orange'].map(fruit => (
  <div key={fruit}>I like {fruit}</div>
))}
```

### Component Imports
You can import and use any Astro component:

```mdx
---
import MyCustomComponent from '../components/MyCustomComponent.astro';
---

<MyCustomComponent prop="value" />
```

### Frontmatter Validation
The MDX integration includes frontmatter validation:

**Required fields:**
- `title`: The title of your content

**Optional fields with defaults:**
- `description`: Empty string
- `author`: 'Kotacom Team'
- `publishDate`: Current date
- `category`: 'General'
- `tags`: Empty array
- `image`: Empty string
- `featured`: false
- `draft`: false

---

## 🎨 Styling

### Dark Mode Support
All components support dark mode automatically using Tailwind CSS classes.

### Custom Styling
You can customize component styles by modifying the component files in `src/components/mdx/`.

### Responsive Design
Components are responsive and work well on all screen sizes.

---

## 📚 Best Practices

### 1. Component Organization
- Keep components in `src/components/mdx/`
- Use descriptive component names
- Export components from `src/components/mdx/index.ts`

### 2. Content Structure
- Use semantic HTML elements
- Provide alt text for images
- Use descriptive titles and captions

### 3. Performance
- Components are optimized and tree-shaken
- Images are lazy-loaded by default
- Use appropriate image formats and sizes

### 4. Accessibility
- All components include proper ARIA attributes
- Keyboard navigation support
- Screen reader friendly

---

## 🔍 Example Usage

See `src/content/post/mdx-example.mdx` for a complete example of using all components and features.

### Key Features Demonstrated:
- ✅ All component types (Alert, Callout, CodeBlock, ImageGallery)
- ✅ JavaScript expressions
- ✅ Conditional rendering
- ✅ Regular Markdown features
- ✅ Component props and customization

---

## 🚀 Getting Started

1. **Create your first MDX file:**
   ```bash
   touch src/content/post/my-first-mdx.mdx
   ```

2. **Add frontmatter and content:**
   ```mdx
   ---
   title: "My First MDX Post"
   description: "Learning to use MDX"
   ---
   
   # My First MDX Post
   
   <Alert type="success">
     Welcome to MDX!
   </Alert>
   ```

3. **Build and test:**
   ```bash
   npm run build
   npm run dev
   ```

4. **Visit your MDX page** at the generated URL

---

## 🛠️ Troubleshooting

### Common Issues

**Issue: Components not rendering**
- Check that components are properly imported
- Verify component syntax and props
- Check browser console for errors

**Issue: Build errors**
- Verify MDX integration is configured correctly
- Check frontmatter validation
- Ensure all required fields are provided

**Issue: Styling problems**
- Check Tailwind CSS is properly configured
- Verify dark mode classes are applied
- Check component CSS classes

### Debug Commands
```bash
# Check MDX integration
npm run build

# Development server with verbose output
npm run dev -- --verbose

# Check for TypeScript errors
npx tsc --noEmit
```

---

## 📖 Additional Resources

- [Astro MDX Documentation](https://docs.astro.build/en/guides/mdx/)
- [MDX Official Documentation](https://mdxjs.com/)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)

---

## 🎉 Congratulations!

You now have MDX support in your Astro project! You can create rich, interactive content with custom components while maintaining the simplicity of Markdown.

**Start creating amazing content with MDX today!** 🚀 