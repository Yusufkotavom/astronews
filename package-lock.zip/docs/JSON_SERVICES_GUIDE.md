# JSON Services Guide

This guide explains how to create and manage service pages using JSON files that are automatically generated into `/services` pages.

## 📋 Overview

The system automatically creates service pages from JSON files in `src/data/json_usaha/`. Each JSON file becomes a service page at `/services/[slug]`.

## 🗂️ File Structure

```
src/
├── data/
│   └── json_usaha/                    # JSON service files
│       ├── Biro_jasa_perizinan.json   # → /services/biro-jasa-perizinan
│       └── Jasa_pengukuhan_PKP.json   # → /services/jasa-pengukuhan--p-k-p
├── pages/
│   └── services/
│       ├── index.astro               # Services listing page
│       └── [slug].astro              # Dynamic service page generator
└── components/
    └── partials/                     # Page sections
        ├── HeroSection.astro
        ├── FeaturesSection.astro
        ├── AboutSection.astro
        ├── ServicesSection.astro
        ├── WhyUsSection.astro
        ├── WhatYouGetSection.astro
        ├── WhyNeedSection.astro
        ├── PricingSection.astro
        ├── PortfolioSection.astro
        ├── TestimonialsSection.astro
        ├── ContentSection.astro
        ├── CTASection.astro
        └── FAQSection.astro
```

## 📝 Creating a New Service Page

### Step 1: Create JSON File

Create a new JSON file in `src/data/json_usaha/` with the following structure:

```json
{
  "business": {
    "type": "Service Type",
    "address": "Business Address",
    "phone": "Phone Number",
    "description": "Business description"
  },
  "hero": {
    "badge_text": "Hero Badge",
    "title": "Main Title",
    "subtitle": "Subtitle",
    "feature": [
      {
        "point": "500+",
        "description": "Feature description"
      }
    ],
    "image_url": "https://example.com/image.jpg"
  },
  "features": {
    "badge_text": "Features Badge",
    "title": "Features Title",
    "subtitle": "Features subtitle",
    "point": [
      {
        "title": "Feature Title",
        "description": "Feature description"
      }
    ]
  },
  "info": {
    "img_alt": "Image alt text",
    "badge_text": "Info Badge",
    "title": "Info Title",
    "subtitle": "Info subtitle",
    "description": "Info description",
    "point": [
      {
        "title": "Info point"
      }
    ]
  },
  "services": {
    "badge_text": "Services Badge",
    "title": "Services Title",
    "subtitle": "Services subtitle",
    "point": [
      {
        "title": "Service Title",
        "description": "Service description",
        "link": "/service-url",
        "feature": [
          "Feature 1",
          "Feature 2"
        ]
      }
    ]
  },
  "why_us": {
    "badge_text": "Why Us Badge",
    "title": "Why Us Title",
    "subtitle": "Why Us subtitle",
    "description": "Why Us description",
    "point": [
      {
        "title": "Reason Title",
        "description": "Reason description"
      }
    ]
  },
  "what_you_get": {
    "title": "What You Get Title",
    "subtitle": "What You Get subtitle",
    "points": [
      {
        "title": "Benefit Title",
        "description": "Benefit description"
      }
    ]
  },
  "why_need": {
    "badge_text": "Why Need Badge",
    "title": "Why Need Title",
    "subtitle": "Why Need subtitle",
    "description": "Why Need description",
    "point": [
      {
        "title": "Need Title",
        "description": "Need description"
      }
    ]
  },
  "pricing": {
    "badge_text": "Pricing Badge",
    "title": "Pricing Title",
    "description": "Pricing description",
    "plan": [
      {
        "badge": "Popular",
        "title": "Plan Title",
        "price": "Rp 1.000.000",
        "description": "Plan description",
        "feature": [
          "Feature 1",
          "Feature 2"
        ]
      }
    ]
  },
  "portfolio": {
    "title": "Portfolio Title",
    "description": "Portfolio description",
    "list": [
      {
        "type": "Project Type",
        "title": "Project Title",
        "description": "Project description"
      }
    ]
  },
  "testimonials": {
    "badge_text": "Testimonials Badge",
    "title": "Testimonials Title",
    "subtitle": "Testimonials subtitle",
    "card": [
      {
        "headline": "Testimonial Headline",
        "quote": "Customer quote",
        "name": "Customer Name",
        "position": "Customer Position"
      }
    ]
  },
  "faq": {
    "badge_text": "FAQ Badge",
    "title": "FAQ Title",
    "subtitle": "FAQ subtitle",
    "points": [
      {
        "question": "FAQ Question",
        "answer": "FAQ Answer"
      }
    ]
  },
  "final_cta": {
    "badge_text": "CTA Badge",
    "title": "CTA Title",
    "subtitle": "CTA subtitle"
  },
  "content": {
    "title": "Content Title",
    "subtitle": "Content subtitle",
    "description": "Content description"
  },
  "local": {
    "title": "Local Title",
    "subtitle": "Local subtitle",
    "description": "Local description",
    "city": [
      {
        "title": "City Name",
        "description": "City description"
      }
    ]
  },
  "kabupaten_kota": [
    {
      "nama": "Kabupaten/Kota Name",
      "description": "Description",
      "kecamatan": [
        {
          "nama": "Kecamatan Name",
          "link": "/kecamatan-url"
        }
      ]
    }
  ],
  "seo_meta": {
    "seo_data": {
      "metadata": {
        "meta_title": "SEO Title",
        "meta_description": "SEO Description",
        "canonical_url": "https://www.kotacom.id/services/slug"
      },
      "schema_markup": {
        "json_ld_script": "Schema markup JSON"
      }
    }
  }
}
```

### Step 2: File Naming Convention

- **Filename**: Use descriptive names with underscores
- **Example**: `Biro_jasa_perizinan.json`
- **Generated URL**: `/services/biro-jasa-perizinan`

### Step 3: Build the Site

```bash
npm run build
```

The system will automatically:
1. Detect the new JSON file
2. Generate the slug from the filename
3. Create the service page at `/services/[slug]`

## 🔄 URL Generation Rules

The system converts JSON filenames to URL slugs:

| JSON Filename | Generated URL |
|---------------|---------------|
| `Biro_jasa_perizinan.json` | `/services/biro-jasa-perizinan` |
| `Jasa_pengukuhan_PKP.json` | `/services/jasa-pengukuhan--p-k-p` |
| `Web_Development.json` | `/services/web-development` |

### Slug Generation Process:
1. Remove `.json` extension
2. Replace underscores with hyphens
3. Convert to lowercase
4. Handle special characters

## 📋 Current Service Pages

Based on your JSON files:

### 1. Biro Jasa Perizinan
- **URL**: `/services/biro-jasa-perizinan`
- **File**: `Biro_jasa_perizinan.json`
- **Service**: Business permit services in East Java

### 2. Jasa Pengukuhan PKP
- **URL**: `/services/jasa-pengukuhan--p-k-p`
- **File**: `Jasa_pengukuhan_PKP.json`
- **Service**: PKP registration services

## 🎨 Page Sections

Each service page includes these sections:

### Hero Section
- Badge text
- Main title and subtitle
- Feature highlights
- Hero image

### Features Section
- Service features
- Benefits list
- Visual elements

### About Section
- Company information
- Team details
- Expertise areas

### Services Section
- Service offerings
- Detailed descriptions
- Feature lists

### Why Us Section
- Competitive advantages
- Unique selling points
- Trust factors

### What You Get Section
- Deliverables
- Benefits
- Value propositions

### Why Need Section
- Problem explanation
- Solution benefits
- Market context

### Pricing Section
- Service packages
- Pricing tiers
- Feature comparisons

### Portfolio Section
- Case studies
- Success stories
- Project examples

### Testimonials Section
- Customer reviews
- Client feedback
- Social proof

### FAQ Section
- Common questions
- Detailed answers
- Helpful information

### Content Section
- Detailed content
- SEO-optimized text
- Rich information

### Local Section
- Geographic coverage
- City information
- Local presence

### Final CTA Section
- Call-to-action
- Contact information
- Next steps

## 🔧 SEO Integration

Each JSON file can include SEO metadata:

```json
{
  "seo_meta": {
    "seo_data": {
      "metadata": {
        "meta_title": "SEO Title",
        "meta_description": "SEO Description",
        "canonical_url": "https://www.kotacom.id/services/slug"
      },
      "schema_markup": {
        "json_ld_script": "Schema markup JSON"
      }
    }
  }
}
```

## 🚀 Commands

### Development
```bash
# Start development server
npm run dev

# Access service pages
# http://localhost:4321/services/biro-jasa-perizinan
# http://localhost:4321/services/jasa-pengukuhan--p-k-p
```

### Production
```bash
# Build site
npm run build

# Preview build
npm run preview
```

## 📝 Best Practices

### 1. File Organization
- Use descriptive filenames
- Keep JSON files in `src/data/json_usaha/`
- Use consistent naming conventions

### 2. Content Structure
- Include all required sections
- Use proper data types
- Maintain consistent formatting

### 3. SEO Optimization
- Include SEO metadata
- Use descriptive titles
- Add schema markup

### 4. Image Management
- Use optimized images
- Include alt text
- Use proper image URLs

### 5. Content Quality
- Write compelling copy
- Include relevant information
- Use proper formatting

## 🔍 Troubleshooting

### Page Not Generated
1. **Check file location**: Ensure JSON file is in `src/data/json_usaha/`
2. **Verify file format**: Ensure valid JSON syntax
3. **Check filename**: Use proper naming convention
4. **Rebuild site**: Run `npm run build`

### URL Issues
1. **Check slug generation**: Verify filename to URL conversion
2. **Special characters**: Handle special characters properly
3. **Duplicate slugs**: Ensure unique filenames

### Content Issues
1. **Missing sections**: Include all required sections
2. **Data format**: Use correct data types
3. **Image URLs**: Ensure valid image URLs

### SEO Issues
1. **Metadata**: Include SEO metadata
2. **Schema markup**: Add proper schema
3. **Canonical URLs**: Set correct canonical URLs

## 📞 Support

If you encounter issues:
1. **Check the console** for error messages
2. **Validate JSON** using a JSON validator
3. **Test the build** with `npm run build`
4. **Review examples** from existing JSON files

---

*This guide covers all aspects of JSON-based service pages. For additional help, refer to the examples or contact support.* 