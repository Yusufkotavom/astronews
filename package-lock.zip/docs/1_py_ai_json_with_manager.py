import os
import json
import pandas as pd
import requests
from datetime import datetime
import re
from dotenv import load_dotenv
import time
import argparse
import sys
from api_key_manager import key_manager

# Muat environment variable dari file .env
load_dotenv()

def load_prompt_template():
    """Muat template prompt dari file promt_1."""
    try:
        with open("promt/promt_1", "r", encoding="utf-8") as f:
            prompt_template = f.read()
        return prompt_template
    except FileNotFoundError:
        raise FileNotFoundError("File promt/promt_1 tidak ditemukan")
    except Exception as e:
        raise Exception(f"Error membaca file promt_1: {e}")

def build_prompt(keyword: str) -> str:
    """Membangun prompt lengkap dengan mengganti placeholder {keyword}."""
    prompt_template = load_prompt_template()
    return prompt_template.replace("{keyword}", keyword)

def find_next_keyword(csv_path: str):
    """Membaca CSV dan menemukan keyword berikutnya yang belum diproses."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    # Cari baris di mana 'status' adalah 'pending' atau 'active'
    pending_rows = df[df['status'].fillna('').str.lower().isin(['pending', 'active'])]
    
    if not pending_rows.empty:
        # Ambil baris pertama yang pending
        next_job = pending_rows.iloc[0]
        return next_job['keyword'], next_job.name # .name memberikan index asli dari DataFrame
    return None, None

def find_keyword_by_name(csv_path: str, keyword_name: str):
    """Mencari keyword spesifik berdasarkan nama."""
    try:
        print(f"🔍 Reading CSV file: {csv_path}")
        # Read CSV with error handling for malformed data
        df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
        print(f"✅ CSV loaded successfully. Shape: {df.shape}")
        
        # Check if keyword column exists
        if 'keyword' not in df.columns:
            print(f"❌ Kolom 'keyword' tidak ditemukan dalam CSV. Kolom yang ada: {list(df.columns)}")
            return None, None
        
        print(f"✅ Keyword column found. First few keywords:")
        for i, row in df.head(3).iterrows():
            print(f"  {i}: '{row['keyword']}' (status: {row['status']})")
        
        # Simple string comparison
        search_keyword = keyword_name.lower().strip()
        print(f"🔍 Searching for: '{search_keyword}'")
        
        # Find matching rows
        matching_rows = df[df['keyword'].str.lower().str.strip() == search_keyword]
        print(f"🔍 Found {len(matching_rows)} matching rows")
        
        if not matching_rows.empty:
            keyword_row = matching_rows.iloc[0]
            print(f"✅ Found keyword: '{keyword_row['keyword']}' at index {keyword_row.name}")
            return keyword_row['keyword'], keyword_row.name
        else:
            print(f"❌ Keyword '{keyword_name}' tidak ditemukan dalam CSV")
            return None, None
            
    except Exception as e:
        print(f"❌ Error saat membaca CSV: {e}")
        import traceback
        traceback.print_exc()
        return None, None

def get_all_pending_keywords(csv_path: str):
    """Mendapatkan semua keyword yang masih pending."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    pending_rows = df[df['status'].fillna('').str.lower().isin(['pending', 'active'])]
    return [(row['keyword'], row.name) for _, row in pending_rows.iterrows()]

def update_csv_status(csv_path: str, index: int, status: str, json_filename: str = ""):
    """Memperbarui status dan nama file JSON di CSV."""
    df = pd.read_csv(csv_path, encoding='utf-8', on_bad_lines='skip')
    df.loc[index, 'status'] = status
    if json_filename:
        df.loc[index, 'json_file'] = json_filename
    df.to_csv(csv_path, index=False)

def sanitize_filename(name: str) -> str:
    """Membersihkan string untuk dijadikan nama file yang valid."""
    name = re.sub(r'[^\w\s-]', '', name).strip() # Hapus karakter tidak valid
    name = re.sub(r'[-\s]+', '_', name) # Ganti spasi/hyphen dengan underscore
    return name

def call_ai_api_with_rotation(prompt: str, preferred_service: str = None):
    """Panggil AI API dengan rotasi otomatis antar service."""
    
    # Daftar service yang tersedia (urut berdasarkan preferensi)
    services = [
        "pollinations",  # Fallback otomatis
        "ollama",        # 100% gratis
        "blackbox",      # Kualitas terbaik
        "cohere",        # Model Command
        "perplexity",    # Model Sonar
        "together",      # Model Llama-2
        "huggingface",   # Model terbuka
        "openai",        # Paling stabil
        "anthropic",     # Kualitas tinggi
        "gemini"         # Original
    ]
    
    # Jika ada preferred service, pindahkan ke depan
    if preferred_service and preferred_service in services:
        services.remove(preferred_service)
        services.insert(0, preferred_service)
    
    last_error = None
    
    for service in services:
        try:
            print(f"🔄 Mencoba {service.upper()}...")
            
            if service == "ollama":
                # Ollama tidak memerlukan API key
                return call_ollama_api(prompt)
            elif service == "pollinations":
                # Pollinations bisa tanpa API key
                return call_pollinations_api(prompt)
            else:
                # Service lain memerlukan API key
                return key_manager.execute_with_rotation(service, call_api_by_service, service, prompt)
                
        except Exception as e:
            last_error = e
            print(f"❌ {service.upper()} gagal: {e}")
            continue
    
    # Semua service gagal
    if last_error:
        raise last_error
    raise Exception("Semua AI service gagal")

def call_api_by_service(api_key: str, service: str, prompt: str):
    """Panggil API berdasarkan service yang dipilih."""
    if service == "openai":
        return call_openai_api(prompt, api_key)
    elif service == "anthropic":
        return call_anthropic_api(prompt, api_key)
    elif service == "gemini":
        return call_gemini_api(prompt, api_key)
    elif service == "cohere":
        return call_cohere_api(prompt, api_key)
    elif service == "perplexity":
        return call_perplexity_api(prompt, api_key)
    elif service == "together":
        return call_together_api(prompt, api_key)
    elif service == "blackbox":
        return call_blackbox_api(prompt, api_key)
    elif service == "huggingface":
        return call_huggingface_api(prompt, api_key)
    else:
        raise Exception(f"Service {service} tidak didukung")

def call_ollama_api(prompt: str):
    """Panggil Ollama API (local)."""
    try:
        url = "http://localhost:11434/api/generate"
        data = {
            "model": "llama2",
            "prompt": f"Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta.\n\n{prompt}",
            "stream": False
        }
        
        response = requests.post(url, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Ollama API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Ollama: {e}")

def call_pollinations_api(prompt: str):
    """Panggil Pollinations AI API."""
    try:
        # Coba dengan API key dulu
        api_key = os.getenv("POLLINATIONS_API_KEY")
        if api_key:
            url = "https://api.pollinations.ai/v1/chat/completions"
            headers = {"Authorization": f"Bearer {api_key}"}
            data = {
                "model": "pollinations-1",
                "messages": [
                    {
                        "role": "system",
                        "content": "Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "max_tokens": 4000,
                "temperature": 0.7
            }
            
            response = requests.post(url, headers=headers, json=data, timeout=120)
            if response.status_code == 200:
                return response.json()
        
        # Fallback ke simulasi response
        print("⚠️  Pollinations API gagal, menggunakan simulasi response...")
        return simulate_ai_response(prompt)
        
    except Exception as e:
        # Fallback ke simulasi response
        print("⚠️  Pollinations API error, menggunakan simulasi response...")
        return simulate_ai_response(prompt)

def call_openai_api(prompt: str, api_key: str):
    """Panggil OpenAI API."""
    try:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "gpt-3.5-turbo",
            "messages": [
                {
                    "role": "system",
                    "content": "Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": 4000,
            "temperature": 0.7
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"OpenAI API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling OpenAI: {e}")

def call_anthropic_api(prompt: str, api_key: str):
    """Panggil Anthropic API."""
    try:
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": api_key,
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01"
        }
        
        data = {
            "model": "claude-3-haiku-20240307",
            "max_tokens": 4000,
            "messages": [
                {
                    "role": "user",
                    "content": f"Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta.\n\n{prompt}"
                }
            ]
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Anthropic API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Anthropic: {e}")

def call_gemini_api(prompt: str, api_key: str):
    """Panggil Gemini API."""
    try:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
        data = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": f"Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta.\n\n{prompt}"
                        }
                    ]
                }
            ],
            "generationConfig": {
                "maxOutputTokens": 4000,
                "temperature": 0.7
            }
        }
        
        response = requests.post(url, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Gemini API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Gemini: {e}")

def call_cohere_api(prompt: str, api_key: str):
    """Panggil Cohere AI API."""
    try:
        url = "https://api.cohere.ai/v1/generate"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "command",
            "prompt": f"Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta.\n\n{prompt}",
            "max_tokens": 4000,
            "temperature": 0.7,
            "k": 0,
            "stop_sequences": [],
            "return_likelihoods": "NONE"
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Cohere API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Cohere: {e}")

def call_perplexity_api(prompt: str, api_key: str):
    """Panggil Perplexity AI API."""
    try:
        url = "https://api.perplexity.ai/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "llama-3.1-sonar-small-128k-online",
            "messages": [
                {
                    "role": "system",
                    "content": "Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": 4000,
            "temperature": 0.7
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Perplexity API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Perplexity: {e}")

def call_together_api(prompt: str, api_key: str):
    """Panggil Together AI API."""
    try:
        url = "https://api.together.xyz/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "meta-llama/Llama-2-70b-chat-hf",
            "messages": [
                {
                    "role": "system",
                    "content": "Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": 4000,
            "temperature": 0.7,
            "top_p": 0.9
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Together AI API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Together AI: {e}")

def call_blackbox_api(prompt: str, api_key: str):
    """Panggil Blackbox AI API."""
    try:
        url = "https://api.blackbox.ai/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "blackbox-1",
            "messages": [
                {
                    "role": "system",
                    "content": "Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": 4000,
            "temperature": 0.7
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Blackbox AI API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Blackbox AI: {e}")

def call_huggingface_api(prompt: str, api_key: str):
    """Panggil Hugging Face API."""
    try:
        url = "https://api-inference.huggingface.co/models/meta-llama/Llama-2-70b-chat-hf"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "inputs": f"Anda adalah copywriter dan marketing strategist yang ahli dalam membuat konten landing page yang persuasif dan SEO-friendly. Berikan respons dalam format JSON yang valid sesuai dengan struktur yang diminta.\n\n{prompt}",
            "parameters": {
                "max_new_tokens": 4000,
                "temperature": 0.7
            }
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=120)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Hugging Face API error: {response.status_code} - {response.text}")
    except Exception as e:
        raise Exception(f"Error calling Hugging Face: {e}")

def simulate_ai_response(prompt: str):
    """Simulasi response AI jika semua API gagal."""
    print("🎭 Menggunakan simulasi response...")
    
    # Extract keyword from prompt
    keyword = "jasa pembuatan website"  # default
    if "{keyword}" in prompt:
        # Try to extract from prompt
        lines = prompt.split('\n')
        for line in lines:
            if "keyword" in line.lower():
                keyword = line.split(':')[-1].strip()
                break
    
    # Generate simulated response
    simulated_response = {
        "title": f"Jasa Pembuatan {keyword.title()} Terbaik & Terpercaya",
        "meta_description": f"Jasa pembuatan {keyword} profesional dengan harga terjangkau. Konsultasi gratis, garansi 100%, dan hasil terbaik untuk bisnis Anda.",
        "hero_title": f"Jasa Pembuatan {keyword.title()} Terbaik di Indonesia",
        "hero_subtitle": f"Solusi lengkap pembuatan {keyword} profesional dengan teknologi terkini dan harga terjangkau untuk mengembangkan bisnis Anda",
        "hero_cta": "Konsultasi Gratis Sekarang",
        "benefits": [
            f"Tim ahli {keyword} berpengalaman",
            "Teknologi terkini dan modern",
            "Harga terjangkau dan transparan",
            "Garansi 100% kepuasan",
            "Support 24/7"
        ],
        "features": [
            f"Desain {keyword} responsif",
            "SEO friendly dan fast loading",
            "Integrasi payment gateway",
            "Panel admin yang mudah",
            "Backup dan maintenance"
        ],
        "testimonials": [
            {
                "name": "Budi Santoso",
                "company": "PT Maju Bersama",
                "text": f"Hasil {keyword} yang dibuat sangat memuaskan. Tim sangat profesional dan responsif."
            },
            {
                "name": "Sari Indah",
                "company": "Toko Online Sari",
                "text": f"Proses pembuatan {keyword} cepat dan hasilnya sesuai ekspektasi. Sangat direkomendasikan!"
            }
        ],
        "pricing": [
            {
                "name": "Starter",
                "price": "Rp 2.500.000",
                "features": [f"Desain {keyword} sederhana", "5 halaman", "Responsive design", "Basic SEO"]
            },
            {
                "name": "Professional",
                "price": "Rp 5.000.000",
                "features": [f"Desain {keyword} premium", "10 halaman", "Advanced SEO", "Payment gateway"]
            },
            {
                "name": "Enterprise",
                "price": "Rp 10.000.000",
                "features": [f"Desain {keyword} custom", "Unlimited halaman", "Full SEO", "Maintenance 1 tahun"]
            }
        ],
        "faq": [
            {
                "question": f"Berapa lama proses pembuatan {keyword}?",
                "answer": f"Proses pembuatan {keyword} memakan waktu 7-14 hari tergantung kompleksitas dan paket yang dipilih."
            },
            {
                "question": f"Apakah ada garansi untuk {keyword}?",
                "answer": f"Ya, kami memberikan garansi 100% kepuasan untuk semua {keyword} yang kami buat."
            }
        ],
        "cta_section": {
            "title": f"Siap Membuat {keyword.title()} Profesional?",
            "subtitle": "Hubungi kami sekarang untuk konsultasi gratis dan dapatkan penawaran terbaik",
            "button_text": "Hubungi Kami Sekarang"
        }
    }
    
    return {"simulated_response": simulated_response}

def process_single_keyword(keyword: str, csv_path: str, output_dir: str, preferred_service: str = None):
    """Memproses satu keyword."""
    try:
        print(f"✨ Memproses keyword: '{keyword}'")
        
        # Cari keyword di CSV
        print("🔍 Mencari keyword di CSV...")
        found_keyword, index = find_keyword_by_name(csv_path, keyword)
        if not found_keyword:
            print(f"❌ Keyword '{keyword}' tidak ditemukan di CSV")
            return False
        
        print(f"✅ Keyword ditemukan: '{found_keyword}' di index {index}")
        
        # Update status menjadi active
        print("🔄 Mengupdate status menjadi 'active'...")
        try:
            update_csv_status(csv_path, index, "active")
            print("✅ Status berhasil diupdate")
        except Exception as e:
            print(f"❌ Error updating status: {e}")
            return False
        
        print("📝 Membuat prompt...")
        try:
            prompt = build_prompt(keyword)
            print("✅ Prompt berhasil dibuat")
        except Exception as e:
            print(f"❌ Error creating prompt: {e}")
            return False
        
        try:
            print("🧠 Memanggil AI API dengan rotasi...")
            response = call_ai_api_with_rotation(prompt, preferred_service)
            print("✅ API call berhasil")
        except Exception as e:
            print(f"❌ Error calling API: {e}")
            return False

        print("📄 Memproses respons JSON...")
        try:
            # Extract content based on service response format
            if 'simulated_response' in response:
                content_data = response['simulated_response']
            elif 'choices' in response and len(response['choices']) > 0:
                json_content_text = response['choices'][0]['message']['content'].strip()
            elif 'generations' in response and len(response['generations']) > 0:
                json_content_text = response['generations'][0]['text'].strip()
            elif 'candidates' in response and len(response['candidates']) > 0:
                json_content_text = response['candidates'][0]['content']['parts'][0]['text'].strip()
            elif 'content' in response and len(response['content']) > 0:
                json_content_text = response['content'][0]['parts'][0]['text'].strip()
            else:
                json_content_text = str(response).strip()
            
            # Clean up response if it's text
            if isinstance(json_content_text, str):
                json_content_text = json_content_text.replace("```json", "").replace("```", "").strip()
                
                # Try to extract JSON from response
                start_idx = json_content_text.find('{')
                end_idx = json_content_text.rfind('}') + 1
                if start_idx != -1 and end_idx != 0:
                    json_content_text = json_content_text[start_idx:end_idx]
                
                content_data = json.loads(json_content_text)
            else:
                content_data = json_content_text
            
            print("✅ JSON berhasil diparse")
        except Exception as e:
            print(f"❌ Error parsing JSON: {e}")
            print(f"Raw response: {str(response)[:500]}...")
            return False
        
        # Gunakan nama keyword sebagai nama file
        output_filename = f"{sanitize_filename(keyword)}.json"
        output_path = os.path.join(output_dir, output_filename)
        
        print(f"💾 Menyimpan ke file: {output_path}")
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(content_data, f, ensure_ascii=False, indent=2)
            print(f"💾 Konten berhasil disimpan ke file: {output_path}")
        except Exception as e:
            print(f"❌ Error saving file: {e}")
            return False
        
        # Update status menjadi promt 1
        print("🔄 Mengupdate status menjadi 'promt 1'...")
        try:
            update_csv_status(csv_path, index, "promt 1", output_filename)
            print(f"🔄 Status untuk '{keyword}' diupdate menjadi 'promt 1'.")
        except Exception as e:
            print(f"❌ Error updating final status: {e}")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Terjadi kesalahan saat memproses '{keyword}': {e}")
        import traceback
        traceback.print_exc()
        # Update status menjadi error jika gagal
        if 'index' in locals():
            try:
                update_csv_status(csv_path, index, "error")
            except:
                pass
        return False

def process_batch(csv_path: str, output_dir: str, batch_size: int = 5, delay_minutes: int = 2, preferred_service: str = None):
    """Memproses semua keyword pending dalam batch."""
    try:
        print("🚀 Memulai proses batch...")
        
        pending_keywords = get_all_pending_keywords(csv_path)
        
        if not pending_keywords:
            print("✅ Tidak ada keyword pending untuk diproses.")
            return
        
        print(f"📋 Total keyword pending: {len(pending_keywords)}")
        
        processed_count = 0
        total_batches = (len(pending_keywords) + batch_size - 1) // batch_size
        
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, len(pending_keywords))
            current_batch = pending_keywords[start_idx:end_idx]
            
            print(f"\n📦 Batch {batch_num + 1}/{total_batches} - Memproses {len(current_batch)} keyword...")
            
            for keyword, index in current_batch:
                success = process_single_keyword(keyword, csv_path, output_dir, preferred_service)
                if success:
                    processed_count += 1
                
                # Jeda antar keyword dalam batch
                if keyword != current_batch[-1][0]:  # Jika bukan keyword terakhir dalam batch
                    print("⏳ Menunggu 5 detik sebelum keyword berikutnya...")
                    time.sleep(5)
            
            # Jeda antar batch
            if batch_num < total_batches - 1:  # Jika bukan batch terakhir
                print(f"⏰ Menunggu {delay_minutes} menit sebelum batch berikutnya...")
                time.sleep(delay_minutes * 120)
        
        print(f"\n✅ Proses batch selesai! Total berhasil diproses: {processed_count}/{len(pending_keywords)}")
        
    except Exception as e:
        print(f"❌ Terjadi kesalahan dalam proses batch: {e}")

def main():
    parser = argparse.ArgumentParser(description='Generator konten AI untuk keyword dengan rotasi otomatis antar service')
    parser.add_argument('keyword', nargs='?', help='Keyword spesifik untuk diproses')
    parser.add_argument('--all', action='store_true', help='Proses semua keyword pending')
    parser.add_argument('--batch-size', type=int, default=5, help='Ukuran batch (default: 5)')
    parser.add_argument('--delay', type=int, default=2, help='Jeda antar batch dalam menit (default: 2)')
    parser.add_argument('--csv', default='data/keyword_new.csv', help='Path ke file CSV (default: data/keyword_new.csv)')
    parser.add_argument('--output', default='output', help='Folder output (default: output)')
    parser.add_argument('--service', help='Service yang diprioritaskan (pollinations, ollama, blackbox, cohere, perplexity, together, huggingface, openai, anthropic, gemini)')
    parser.add_argument('--status', action='store_true', help='Tampilkan status API keys')
    
    args = parser.parse_args()
    
    try:
        # Tampilkan status jika diminta
        if args.status:
            key_manager.print_status()
            return
        
        # Buat folder output jika belum ada
        os.makedirs(args.output, exist_ok=True)
        
        if args.all:
            # Proses semua keyword pending
            process_batch(args.csv, args.output, args.batch_size, args.delay, args.service)
        elif args.keyword:
            # Proses keyword spesifik
            success = process_single_keyword(args.keyword, args.csv, args.output, args.service)
            if success:
                print("✅ Proses selesai!")
            else:
                print("❌ Proses gagal!")
                sys.exit(1)
        else:
            # Mode default - proses keyword berikutnya
            keyword, index = find_next_keyword(args.csv)
            
            if not keyword:
                print("✅ Semua keyword sudah selesai diproses.")
                return
                
            success = process_single_keyword(keyword, args.csv, args.output, args.service)
            if success:
                print("✅ Proses selesai!")
            else:
                print("❌ Proses gagal!")
                sys.exit(1)
                
    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main() 