# 🖼️ Image Download Configuration Guide

## Overview

This guide explains how to configure image downloading from WordPress to control which images are downloaded and optimize your import process.

## 🎯 Image Download Options

### Option 1: Keep Short WordPress URLs (Recommended)
```env
# Keep short WordPress URLs - no local downloads
DOWNLOAD_IMAGES=false
KEEP_ORIGINAL_URLS=true
DOWNLOAD_FEATURED_IMAGES_ONLY=false
DOWNLOAD_CONTENT_IMAGES=false
```

### Option 2: Download Only Featured Images
```env
# Download only featured images (1 image per post)
DOWNLOAD_IMAGES=true
DOWNLOAD_FEATURED_IMAGES_ONLY=true
DOWNLOAD_CONTENT_IMAGES=false
KEEP_ORIGINAL_URLS=false
IMAGE_QUALITY=85
IMAGE_FORMAT=webp
```

### Option 3: Download All Images
```env
DOWNLOAD_IMAGES=true
DOWNLOAD_FEATURED_IMAGES_ONLY=true
DOWNLOAD_CONTENT_IMAGES=true
KEEP_ORIGINAL_URLS=false
```

### Option 4: No Images
```env
DOWNLOAD_IMAGES=false
KEEP_ORIGINAL_URLS=false
DOWNLOAD_FEATURED_IMAGES_ONLY=false
DOWNLOAD_CONTENT_IMAGES=false
```

## 📊 Image Count Comparison

| Configuration | Images per Post | Total for 1000 Posts | Storage |
|---------------|----------------|---------------------|---------|
| Original URLs | 0 | 0 | 0 MB |
| Featured Only | 1 | 1,000 | ~500 MB |
| All Images | 5-20+ | 5,000-20,000+ | ~5-20 GB |
| No Images | 0 | 0 | 0 MB |

## 🚀 How to Apply Configuration

### Step 1: Create .env file
```bash
# Create .env file in project root
touch .env
```

### Step 2: Add configuration
```env
# WordPress Configuration
WORDPRESS_SITE_URL=https://kotacom.id

# Image Settings - Keep short WordPress URLs (recommended)
DOWNLOAD_IMAGES=false
KEEP_ORIGINAL_URLS=true
DOWNLOAD_FEATURED_IMAGES_ONLY=false
DOWNLOAD_CONTENT_IMAGES=false
```

### Step 3: Clean and re-import
```bash
# Remove old images (if any)
rm -rf public/images/wordpress/*

# Re-import with new settings
npm run wordpress:import
```

## 🔧 Configuration Details

### KEEP_ORIGINAL_URLS (NEW)
- `true`: Keep short WordPress URLs (recommended)
- `false`: Download images locally

### DOWNLOAD_IMAGES
- `true`: Enable image downloading
- `false`: Disable all image downloading

### DOWNLOAD_FEATURED_IMAGES_ONLY
- `true`: Download only featured images
- `false`: Skip featured images

### DOWNLOAD_CONTENT_IMAGES
- `true`: Download all images in post content
- `false`: Skip content images

### IMAGE_QUALITY
- Range: 1-100
- Default: 85
- Higher = better quality, larger files

### IMAGE_FORMAT
- `webp`: Modern format, smaller files
- `jpg`: Universal compatibility
- `png`: Lossless quality

## 💡 Benefits of Keeping Short WordPress URLs

1. **Zero Storage**: No local image files needed
2. **Fastest Import**: No download time
3. **Always Updated**: Images stay current with WordPress
4. **CDN Benefits**: WordPress CDN handles optimization
5. **No Maintenance**: No local image management needed
6. **Cleaner URLs**: Shorter, more readable image paths

## 🎯 Recommended Settings

For most use cases, use these settings:

```env
DOWNLOAD_IMAGES=false
KEEP_ORIGINAL_URLS=true
DOWNLOAD_FEATURED_IMAGES_ONLY=false
DOWNLOAD_CONTENT_IMAGES=false
```

This will:
- ✅ Keep short WordPress URLs (e.g., `/wp-content/uploads/...`)
- ✅ No local image downloads
- ✅ Fastest import process
- ✅ Zero storage requirements
- ✅ Images always stay current
- ✅ Cleaner, shorter image paths 