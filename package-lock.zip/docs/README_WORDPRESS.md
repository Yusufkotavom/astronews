# 🚀 WordPress Integration for Astro

## 📋 Quick Start

### 🎯 One-Command Setup
```bash
# Run the interactive setup wizard
npm run wordpress:wizard
```

### ⚡ Manual Setup
```bash
# 1. Configure WordPress credentials
cp .env.example .env
# Edit .env with your WordPress details

# 2. Test connection
npm run wordpress:setup

# 3. Import content
npm run wordpress:import

# 4. Build and test
npm run build
npm run dev
```

---

## 🎯 What This Integration Does

### ✅ **Static WordPress Content**
- Downloads all WordPress posts and pages
- Converts them to static Markdown files
- No WordPress dependencies at runtime

### ✅ **Image Optimization**
- Downloads all images from WordPress
- Converts to WebP format for better performance
- Optimizes for different screen sizes

### ✅ **SEO Optimization**
- Maintains all SEO benefits
- Generates structured data markup
- Creates optimized meta tags

### ✅ **Performance**
- Lightning-fast loading
- CDN-ready assets
- Optimized for Core Web Vitals

---

## 📁 Project Structure

```
src/
├── content/
│   ├── post/          # WordPress posts (Markdown)
│   ├── page/          # WordPress pages (Markdown)
│   └── config.ts      # Content schemas
├── pages/
│   ├── blog/
│   │   ├── index.astro    # Blog listing
│   │   ├── [slug].astro   # Individual posts
│   │   └── category/[category].astro
│   └── [slug].astro       # WordPress pages
├── scripts/
│   ├── import-wordpress-posts.js      # Main import script
│   ├── wordpress-config.js            # Configuration
│   ├── setup-wordpress.js             # Connection test
│   └── wordpress-setup-wizard.js      # Interactive setup
└── utils/
    └── seo-helper.ts                   # SEO utilities
```

---

## 🔧 Configuration

### Environment Variables (.env)
```env
# WordPress Configuration
WORDPRESS_URL=https://your-wordpress-site.com
WORDPRESS_USERNAME=your_username
WORDPRESS_PASSWORD=your_application_password

# Content Settings
POSTS_PER_PAGE=100
PAGES_PER_PAGE=50
INCLUDE_DRAFTS=false
INCLUDE_PRIVATE=false

# Image Settings
DOWNLOAD_IMAGES=true
IMAGE_QUALITY=85
IMAGE_FORMAT=webp
```

### WordPress Requirements
- ✅ WordPress 4.7+ (REST API enabled)
- ✅ Application password for authentication
- ✅ Public posts/pages for content access
- ✅ Proper permalinks configured

---

## 🚀 Available Commands

### Setup & Configuration
```bash
# Interactive setup wizard
npm run wordpress:wizard

# Test WordPress connection
npm run wordpress:setup

# Import WordPress content
npm run wordpress:import

# Test connection (alias)
npm run wordpress:test
```

### Development & Build
```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 📥 Content Import Process

### What Gets Imported
1. **Posts**: All published WordPress posts
2. **Pages**: All published WordPress pages
3. **Images**: Featured images and content images
4. **Metadata**: SEO data, categories, tags, authors
5. **Content**: HTML converted to Markdown

### Import Output
```
src/content/
├── post/
│   ├── jasa-cetak-buku-jakarta.md
│   ├── jasa-digital-marketing-bandung.md
│   └── ...
├── page/
│   ├── about-us.md
│   ├── services.md
│   └── ...

public/images/wordpress/
├── image1.webp
├── image2.webp
└── ...
```

---

## 🎨 Customization

### Content Processing
Edit `scripts/wordpress-config.js`:
```javascript
const config = {
  content: {
    stripHtml: true,           // Remove HTML tags
    maxExcerptLength: 200,     // Limit excerpt length
    includeFeaturedImage: true, // Include featured images
  },
  
  images: {
    downloadPath: 'public/images/wordpress/',
    quality: 85,
    format: 'webp',
    sizes: ['thumbnail', 'medium', 'large']
  }
};
```

### SEO Optimization
The integration automatically generates:
- ✅ Meta descriptions from content
- ✅ Open Graph tags for social sharing
- ✅ Schema markup for search engines
- ✅ Canonical URLs for SEO
- ✅ Image alt text for accessibility

---

## 🔄 Content Updates

### Manual Updates
When you add new content to WordPress:

1. **Add new post/page** in WordPress
2. **Run import script**:
   ```bash
   npm run wordpress:import
   ```
3. **Rebuild and deploy**:
   ```bash
   npm run build
   npm run deploy
   ```

### Automated Updates (Optional)
Set up webhooks for automatic updates:
1. Install webhook plugin in WordPress
2. Configure webhook to trigger on post/page publish
3. Set up CI/CD pipeline to rebuild on webhook

---

## 🛠️ Troubleshooting

### Common Issues

#### Connection Failed
```bash
# Check WordPress URL
echo $WORDPRESS_URL

# Test connection manually
curl -u "username:password" \
  "https://your-wordpress-site.com/wp-json/wp/v2/posts"
```

#### No Posts Found
- Check WordPress permissions
- Verify REST API is enabled
- Check post status (published vs draft)

#### Images Not Downloading
- Check image URLs in WordPress
- Verify file permissions in `public/images/`
- Check network connectivity

### Debug Commands
```bash
# Test WordPress connection
npm run wordpress:setup

# Check content collections
npm run build

# Validate content structure
ls -la src/content/post/
ls -la src/content/page/
```

---

## 📊 Performance Benefits

### Before Integration
- ❌ WordPress database queries
- ❌ PHP processing overhead
- ❌ Dynamic content generation
- ❌ Slower page loading

### After Integration
- ✅ Static HTML files
- ✅ No database dependencies
- ✅ Pre-built content
- ✅ Lightning-fast loading
- ✅ CDN-ready assets

---

## 🎯 Success Metrics

### Performance Improvements
- **Page Speed**: 90+ Lighthouse score
- **Core Web Vitals**: All metrics in green
- **Loading Time**: < 2 seconds
- **SEO Score**: 100/100

### Content Management
- **Posts**: All WordPress posts imported
- **Pages**: All WordPress pages imported
- **Images**: All images optimized and downloaded
- **SEO**: All meta tags and structured data preserved

---

## 📚 Documentation

### Complete Guides
- 📖 `WORDPRESS_INTEGRATION_GUIDE.md` - Complete step-by-step guide
- 📋 `WORDPRESS_QUICK_REFERENCE.md` - Quick reference card

### Key Files
- 🔧 `scripts/wordpress-config.js` - Configuration options
- 📥 `scripts/import-wordpress-posts.js` - Main import script
- 🧪 `scripts/setup-wordpress.js` - Connection testing
- 🎯 `scripts/wordpress-setup-wizard.js` - Interactive setup

---

## 🚀 Deployment

### Vercel
```bash
npm run build
vercel --prod
```

### Netlify
```bash
npm run build
# Drag dist/ folder to Netlify
```

### Other Platforms
- **GitHub Pages**: Push to `gh-pages` branch
- **AWS S3**: Upload `dist/` contents
- **Cloudflare Pages**: Connect repository

---

## 🎉 Results

After successful integration, you'll have:

### ✅ **Static WordPress Site**
- All content converted to static files
- No WordPress dependencies at runtime
- Lightning-fast performance

### ✅ **SEO Optimized**
- All meta tags preserved
- Structured data markup
- Search engine friendly

### ✅ **CDN Ready**
- All assets optimized
- Images converted to WebP
- Ready for global distribution

### ✅ **Modern Development**
- Astro's modern tooling
- TypeScript support
- Component-based architecture

---

## 📞 Support

### Getting Help
1. **Check troubleshooting section** above
2. **Review WordPress logs** for API errors
3. **Verify Astro build logs** for content issues
4. **Test with a simple post** first
5. **Check network connectivity** and permissions

### Resources
- 📖 [Astro Documentation](https://docs.astro.build/)
- 🌐 [WordPress REST API](https://developer.wordpress.org/rest-api/)
- 🚀 [Vercel Deployment](https://vercel.com/docs)

---

**🎯 Your WordPress site is now a high-performance static site!** 🚀 