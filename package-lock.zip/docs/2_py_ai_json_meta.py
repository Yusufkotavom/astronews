import os
import json
import pandas as pd
import google.generativeai as genai
from datetime import datetime
import re
from dotenv import load_dotenv
import time
import argparse
import sys

# Import API Key Manager
from api_key_manager import key_manager

# Muat environment variable dari file .env
load_dotenv()

def configure_gemini():
    """Mengonfigurasi Gemini API dengan API Key Manager."""
    try:
        # Get API key from key manager
        api_key = key_manager.get_available_key("gemini")
        if not api_key:
            raise ValueError("No available Gemini API keys found")
        
        genai.configure(api_key=api_key.key)
        print(f"✅ Configured Gemini with key: {api_key.name}")
        return api_key
    except Exception as e:
        raise ValueError(f"Error configuring Gemini: {e}")

def load_prompt_template():
    """Muat template prompt dari file promt_2."""
    try:
        with open("promt/promt_2", "r", encoding="utf-8") as f:
            prompt_template = f.read()
        return prompt_template
    except FileNotFoundError:
        raise FileNotFoundError("File promt/promt_2 tidak ditemukan")
    except Exception as e:
        raise Exception(f"Error membaca file promt_2: {e}")

def load_prompt1_json(keyword: str, output_dir: str):
    """Muat JSON dari prompt 1 berdasarkan keyword."""
    try:
        json_filename = f"{sanitize_filename(keyword)}.json"
        json_path = os.path.join(output_dir, json_filename)
        
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"File JSON prompt 1 tidak ditemukan: {json_path}")
        
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        raise Exception(f"Error membaca JSON prompt 1: {e}")

def extract_company_info(prompt1_data):
    """Ekstrak informasi perusahaan dari data prompt 1."""
    try:
        # Coba ekstrak dari berbagai field yang mungkin berisi nama perusahaan
        company_name = "KotaCom Digital Agency"
        
        # Cari di field info jika ada
        if 'info' in prompt1_data and 'title' in prompt1_data['info']:
            title = prompt1_data['info']['title']
            if 'tim' in title.lower() or 'perusahaan' in title.lower():
                company_name = title
        
        # Cari di field hero jika ada
        elif 'hero' in prompt1_data and 'title' in prompt1_data['hero']:
            title = prompt1_data['hero']['title']
            if 'jasa' in title.lower() and 'website' in title.lower():
                # Ekstrak nama perusahaan dari judul
                company_name = "KotaCom Digital Agency"
        
        return company_name
    except Exception as e:
        print(f"⚠️  Warning: Tidak bisa mengekstrak info perusahaan: {e}")
        return "KotaCom Digital Agency"

def build_prompt(keyword: str, company_name: str, website_url: str = "https://www.kotacom.id") -> str:
    """Membangun prompt lengkap dengan mengganti placeholder."""
    prompt_template = load_prompt_template()
    
    # Replace placeholders
    prompt = prompt_template.replace("{keyword dari prompt pertama}", keyword)
    prompt = prompt.replace("{nama perusahaan fiktif yang dihasilkan}", company_name)
    prompt = prompt.replace("{https://www.kotacom.id}", website_url)
    
    return prompt

def find_keywords_with_status(csv_path: str, status: str):
    """Mencari keyword dengan status tertentu."""
    df = pd.read_csv(csv_path)
    matching_rows = df[df['status'].fillna('').str.lower() == status.lower()]
    return [(row['keyword'], row.name) for _, row in matching_rows.iterrows()]

def find_keyword_by_name(csv_path: str, keyword_name: str):
    """Mencari keyword spesifik berdasarkan nama."""
    df = pd.read_csv(csv_path)
    matching_rows = df[df['keyword'].str.lower() == keyword_name.lower()]
    
    if not matching_rows.empty:
        keyword_row = matching_rows.iloc[0]
        return keyword_row['keyword'], keyword_row.name
    return None, None

def update_csv_status(csv_path: str, index: int, status: str, json_filename: str = ""):
    """Memperbarui status dan nama file JSON di CSV."""
    df = pd.read_csv(csv_path)
    df.loc[index, 'status'] = status
    if json_filename:
        df.loc[index, 'json_file_enriched'] = json_filename
    df.to_csv(csv_path, index=False)

def sanitize_filename(name: str) -> str:
    """Membersihkan string untuk dijadikan nama file yang valid."""
    name = re.sub(r'[^\w\s-]', '', name).strip() # Hapus karakter tidak valid
    name = re.sub(r'[-\s]+', '_', name) # Ganti spasi/hyphen dengan underscore
    return name

def process_single_keyword(keyword: str, csv_path: str, output_dir: str, prompt1_dir: str):
    """Memproses satu keyword untuk meta data."""
    try:
        print(f"✨ Memproses meta data untuk keyword: '{keyword}'")
        
        # Cari keyword di CSV dengan status "promt 1"
        found_keyword, index = find_keyword_by_name(csv_path, keyword)
        if not found_keyword:
            print(f"❌ Keyword '{keyword}' tidak ditemukan di CSV")
            return False
        
        # Cek status harus "promt 1"
        df = pd.read_csv(csv_path)
        current_status = df.loc[index, 'status']
        if current_status.lower() != 'promt 1':
            print(f"❌ Keyword '{keyword}' status bukan 'promt 1' (current: {current_status})")
            return False
        
        # Load JSON dari prompt 1
        try:
            prompt1_data = load_prompt1_json(keyword, prompt1_dir)
            print(f"📄 Berhasil memuat JSON prompt 1 untuk '{keyword}'")
        except Exception as e:
            print(f"❌ Gagal memuat JSON prompt 1: {e}")
            return False
        
        # Ekstrak informasi perusahaan
        company_name = extract_company_info(prompt1_data)
        print(f"🏢 Menggunakan nama perusahaan: {company_name}")
        
        # Update status menjadi active
        update_csv_status(csv_path, index, "active_meta")
        
        # Build prompt dengan informasi dari prompt 1
        prompt = build_prompt(keyword, company_name)
        
        # Use API Key Manager for automatic rotation and timeout handling
        def call_gemini_api(api_key, prompt):
            """Wrapper function for Gemini API call"""
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel('gemini-1.5-flash')
            return model.generate_content(prompt)
        
        try:
            print("🧠 Memanggil API Gemini untuk meta data dengan key rotation...")
            response = key_manager.execute_with_rotation("gemini", call_gemini_api, prompt)
            print("✅ API call berhasil dengan key rotation")
        except Exception as e:
            print(f"❌ Error calling API with key rotation: {e}")
            return False

        json_content_text = response.text.strip().replace("```json", "").replace("```", "").strip()
        meta_data = json.loads(json_content_text)
        
        # Combine prompt 1 data dengan meta data (no wrapping)
        combined_data = {**prompt1_data, "seo_meta": meta_data}
        
        # Gunakan nama keyword dengan suffix _meta
        output_filename = f"{sanitize_filename(keyword)}_meta.json"
        output_path = os.path.join(output_dir, output_filename)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(combined_data, f, ensure_ascii=False, indent=2)
        print(f"💾 Meta data berhasil disimpan ke file: {output_path}")
        
        # Update status menjadi promt 2
        update_csv_status(csv_path, index, "promt 2", output_filename)
        print(f"🔄 Status untuk '{keyword}' diupdate menjadi 'promt 2'.")
        
        return True
        
    except Exception as e:
        print(f"❌ Terjadi kesalahan saat memproses meta data '{keyword}': {e}")
        # Update status menjadi error jika gagal
        if 'index' in locals():
            update_csv_status(csv_path, index, "error_meta")
        return False

def process_batch(csv_path: str, output_dir: str, prompt1_dir: str, batch_size: int = 5, delay_minutes: int = 2):
    """Memproses semua keyword dengan status 'promt 1' dalam batch."""
    try:
        print("🚀 Memulai proses batch meta data...")
        configure_gemini()
        
        # Cari keyword dengan status "promt 1"
        prompt1_keywords = find_keywords_with_status(csv_path, "promt 1")
        
        if not prompt1_keywords:
            print("✅ Tidak ada keyword dengan status 'promt 1' untuk diproses.")
            return
        
        print(f"📋 Total keyword dengan status 'promt 1': {len(prompt1_keywords)}")
        
        processed_count = 0
        total_batches = (len(prompt1_keywords) + batch_size - 1) // batch_size
        
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, len(prompt1_keywords))
            current_batch = prompt1_keywords[start_idx:end_idx]
            
            print(f"\n📦 Batch {batch_num + 1}/{total_batches} - Memproses {len(current_batch)} keyword...")
            
            for keyword, index in current_batch:
                success = process_single_keyword(keyword, csv_path, output_dir, prompt1_dir)
                if success:
                    processed_count += 1
                
                # Jeda antar keyword dalam batch
                if keyword != current_batch[-1][0]:  # Jika bukan keyword terakhir dalam batch
                    print("⏳ Menunggu 5 detik sebelum keyword berikutnya...")
                    time.sleep(5)
            
            # Jeda antar batch
            if batch_num < total_batches - 1:  # Jika bukan batch terakhir
                print(f"⏰ Menunggu {delay_minutes} menit sebelum batch berikutnya...")
                time.sleep(delay_minutes * 60)
        
        print(f"\n✅ Proses batch meta data selesai! Total berhasil diproses: {processed_count}/{len(prompt1_keywords)}")
        
    except Exception as e:
        print(f"❌ Terjadi kesalahan dalam proses batch meta data: {e}")

def main():
    parser = argparse.ArgumentParser(description='Generator meta data SEO untuk keyword')
    parser.add_argument('keyword', nargs='?', help='Keyword spesifik untuk diproses')
    parser.add_argument('--all', action='store_true', help='Proses semua keyword dengan status promt 1')
    parser.add_argument('--batch-size', type=int, default=5, help='Ukuran batch (default: 5)')
    parser.add_argument('--delay', type=int, default=2, help='Jeda antar batch dalam menit (default: 2)')
    parser.add_argument('--csv', default='data/keyword_new.csv', help='Path ke file CSV (default: data/keyword_new.csv)')
    parser.add_argument('--output', default='output', help='Folder output (default: output)')
    parser.add_argument('--prompt1-dir', default='output', help='Folder output prompt 1 (default: output)')
    
    args = parser.parse_args()
    
    # Buat folder output jika belum ada
    os.makedirs(args.output, exist_ok=True)
    
    if args.all:
        # Proses semua keyword dengan status promt 1
        process_batch(args.csv, args.output, args.prompt1_dir, args.batch_size, args.delay)
    elif args.keyword:
        # Proses keyword spesifik
        try:
            configure_gemini()
            success = process_single_keyword(args.keyword, args.csv, args.output, args.prompt1_dir)
            if success:
                print("✅ Proses meta data selesai!")
            else:
                print("❌ Proses meta data gagal!")
                sys.exit(1)
        except Exception as e:
            print(f"❌ Terjadi kesalahan: {e}")
            sys.exit(1)
    else:
        # Mode default - proses keyword berikutnya dengan status promt 1
        try:
            configure_gemini()
            prompt1_keywords = find_keywords_with_status(args.csv, "promt 1")
            
            if not prompt1_keywords:
                print("✅ Tidak ada keyword dengan status 'promt 1' untuk diproses.")
                return
            
            # Ambil keyword pertama
            keyword, index = prompt1_keywords[0]
            
            success = process_single_keyword(keyword, args.csv, args.output, args.prompt1_dir)
            if success:
                print("✅ Proses meta data selesai!")
            else:
                print("❌ Proses meta data gagal!")
                sys.exit(1)
                
        except Exception as e:
            print(f"❌ Terjadi kesalahan: {e}")
            sys.exit(1)

if __name__ == "__main__":
    main()