# 🚀 WordPress Integration Guide for Astro

## 📋 Overview

This guide will help you integrate WordPress with your Astro project to create a static site with WordPress as the content management system. The integration downloads all WordPress content (posts, pages, images) and converts them to static files for optimal performance.

## 🎯 What You'll Achieve

- ✅ **Static WordPress Content**: All posts and pages become static files
- ✅ **Image Optimization**: Download and optimize all images locally
- ✅ **SEO Optimization**: Maintain all SEO benefits with static generation
- ✅ **Performance**: Lightning-fast loading with no WordPress dependencies
- ✅ **CDN Ready**: All assets ready for CDN deployment
- ✅ **Unlimited Content**: Import thousands of posts with pagination support

---

## 📁 Step 1: Project Structure Setup

### 1.1 Verify Current Structure
```bash
# Your project should have this structure:
src/
├── content/
│   ├── post/          # WordPress posts will be imported here
│   ├── page/          # WordPress pages will be imported here
│   └── config.ts      # Content collection schemas
├── pages/
│   ├── blog/
│   │   ├── index.astro
│   │   ├── [slug].astro
│   │   └── category/[category].astro
│   └── [slug].astro   # For WordPress pages
├── scripts/
│   ├── import-wordpress-posts.js
│   ├── wordpress-config.js
│   └── setup-wordpress.js
└── utils/
    └── seo-helper.ts
```

### 1.2 Check Required Files
Ensure these files exist in your project:
- ✅ `src/content/config.ts` - Content collection schemas
- ✅ `scripts/import-wordpress-posts.js` - Import script with pagination
- ✅ `scripts/wordpress-config.js` - Configuration
- ✅ `scripts/setup-wordpress.js` - Setup script

---

## 🔧 Step 2: WordPress Configuration

### 2.1 Create Environment File
```bash
# Create .env file in project root
touch .env
```

### 2.2 Configure WordPress Settings
Edit `.env` file:
```env
# WordPress Configuration
WORDPRESS_URL=https://your-wordpress-site.com
WORDPRESS_USERNAME=your_username
WORDPRESS_PASSWORD=your_application_password

# Content Settings - IMPORTANT: Pagination Settings
WORDPRESS_POSTS_PER_PAGE=100
WORDPRESS_MAX_POSTS=10000
POSTS_PER_PAGE=100
PAGES_PER_PAGE=50
INCLUDE_DRAFTS=false
INCLUDE_PRIVATE=false

# Image Settings
DOWNLOAD_IMAGES=true
IMAGE_QUALITY=85
IMAGE_FORMAT=webp

# Performance Settings
REQUEST_DELAY=500
TIMEOUT=30000
```

### 2.3 WordPress Site Requirements
Your WordPress site must have:
- ✅ **REST API enabled** (default in WordPress 4.7+)
- ✅ **Application password** for authentication
- ✅ **Public posts/pages** for content access
- ✅ **Proper permalinks** configured

---

## 🔐 Step 3: WordPress Authentication Setup

### 3.1 Create Application Password
1. **Login to WordPress Admin**
2. **Go to Users → Profile**
3. **Scroll to "Application Passwords"**
4. **Create new application password:**
   - Name: `Astro Integration`
   - Click "Add New Application Password"
   - Copy the generated password

### 3.2 Test Connection
```bash
# Test WordPress connection
npm run wordpress:setup
```

**Expected Output:**
```
✅ WordPress connection successful!
📊 Site Info:
   - Site URL: https://your-wordpress-site.com
   - Site Title: Your Site Title
   - Posts Count: 250
   - Pages Count: 15
```

---

## 📥 Step 4: Import WordPress Content (Now with Pagination!)

### 4.1 Run Import Script
```bash
# Import all WordPress content (now supports unlimited posts)
npm run wordpress:import
```

### 4.2 Monitor Import Process with Pagination
The script will now:
1. **Fetch posts page by page** from WordPress API
2. **Fetch pages page by page** from WordPress API
3. **Download images** to `public/images/wordpress/`
4. **Convert HTML to Markdown**
5. **Generate frontmatter** with SEO data
6. **Save files** to `src/content/post/` and `src/content/page/`

### 4.3 Expected Output with Pagination
```
🚀 Starting WordPress content import...
📋 Configuration:
   - WordPress URL: https://your-wordpress-site.com
   - Posts per page: 100
   - Output directory: /src/content/post

🔗 Connecting to WordPress: https://your-wordpress-site.com
📡 Fetching posts page 1...
✅ Fetched 100 posts from page 1
📡 Fetching posts page 2...
✅ Fetched 100 posts from page 2
📡 Fetching posts page 3...
✅ Fetched 50 posts from page 3
📄 Last page reached (50 posts)

📄 Fetching WordPress pages...
📡 Fetching pages page 1...
✅ Fetched 15 pages from page 1
📄 Last page reached (15 pages)

📝 Processing posts...
📝 Processing post 1/250: "Sample Post Title"
✅ Successfully processed: Sample Post Title
📝 Processing post 2/250: "Another Post"
✅ Successfully processed: Another Post
...

📊 Import Summary:
✅ Successfully imported: 250 posts, 15 pages
❌ Failed to import: 0 items
📸 Downloaded: 45 images
📝 Total posts: 250
📄 Total pages: 15
```

---

## 🏗️ Step 5: Build and Test

### 5.1 Build the Project
```bash
# Build static site
npm run build
```

### 5.2 Verify Build Output
Check that these pages are generated:
```
✅ /blog/index.html - Blog listing page
✅ /blog/[post-slug]/index.html - Individual blog posts (250+ files)
✅ /[page-slug]/index.html - WordPress pages
✅ /sitemap/index.html - Sitemap with all content
```

### 5.3 Test Local Development
```bash
# Start development server
npm run dev
```

**Test these URLs:**
- `http://localhost:4321/blog` - Blog listing
- `http://localhost:4321/blog/[post-slug]` - Individual posts
- `http://localhost:4321/[page-slug]` - WordPress pages

---

## 🎨 Step 6: Customize and Optimize

### 6.1 Customize Import Script
Edit `scripts/wordpress-config.js`:
```javascript
// Customize content processing
const config = {
  // Content settings
  content: {
    stripHtml: true,           // Remove HTML tags
    maxExcerptLength: 200,     // Limit excerpt length
    includeFeaturedImage: true, // Include featured images
  },
  
  // Pagination settings
  pagination: {
    postsPerPage: 100,         // Posts per API request
    maxPosts: 10000,           // Maximum posts to import
    requestDelay: 500,         // Delay between requests
    timeout: 30000             // Request timeout
  },
  
  // Image settings
  images: {
    downloadPath: 'public/images/wordpress/',
    quality: 85,
    format: 'webp',
    sizes: ['thumbnail', 'medium', 'large']
  }
};
```

### 6.2 SEO Optimization
The import script automatically generates:
- ✅ **Meta descriptions** from content
- ✅ **Open Graph tags** for social sharing
- ✅ **Schema markup** for search engines
- ✅ **Canonical URLs** for SEO
- ✅ **Image alt text** for accessibility

### 6.3 Performance Optimization
- ✅ **Images converted to WebP** format
- ✅ **Lazy loading** implemented
- ✅ **Responsive images** with multiple sizes
- ✅ **Static generation** for fast loading

---

## 🚀 Step 7: Deployment

### 7.1 Prepare for Deployment
```bash
# Build production version
npm run build

# Check build output
ls -la dist/
```

### 7.2 Deploy to Vercel
```bash
# Deploy to Vercel (if using Vercel)
vercel --prod
```

### 7.3 Deploy to Other Platforms
- **Netlify**: Drag `dist/` folder to Netlify
- **GitHub Pages**: Push to `gh-pages` branch
- **AWS S3**: Upload `dist/` contents to S3 bucket

---

## 🔄 Step 8: Content Updates

### 8.1 Manual Updates
When you add new content to WordPress:

1. **Add new post/page** in WordPress
2. **Run import script** again:
   ```bash
   npm run wordpress:import
   ```
3. **Rebuild and deploy**:
   ```bash
   npm run build
   npm run deploy
   ```

### 8.2 Automated Updates (Optional)
Set up webhooks for automatic updates:

1. **Install webhook plugin** in WordPress
2. **Configure webhook** to trigger on post/page publish
3. **Set up CI/CD** pipeline to rebuild on webhook

---

## 🛠️ Step 9: Troubleshooting

### 9.1 Common Issues

#### Issue: "Only 100 posts imported"
**Solution:** The script now supports pagination! It will automatically fetch all posts:
```bash
# The script will show pagination progress:
📡 Fetching posts page 1...
📡 Fetching posts page 2...
📡 Fetching posts page 3...
```

#### Issue: "Connection failed"
**Solution:**
```bash
# Check WordPress URL
echo $WORDPRESS_URL

# Test connection manually
curl -u "username:password" \
  "https://your-wordpress-site.com/wp-json/wp/v2/posts"
```

#### Issue: "No posts found"
**Solution:**
1. **Check WordPress permissions**
2. **Verify REST API is enabled**
3. **Check post status** (published vs draft)

#### Issue: "Images not downloading"
**Solution:**
1. **Check image URLs** in WordPress
2. **Verify file permissions** in `public/images/`
3. **Check network connectivity**

### 9.2 Debug Commands
```bash
# Test WordPress connection
npm run wordpress:setup

# Check content collections
npm run build

# Validate content structure
ls -la src/content/post/
ls -la src/content/page/
```

---

## 📊 Step 10: Monitoring and Maintenance

### 10.1 Regular Tasks
- **Weekly**: Run import script for new content
- **Monthly**: Check for WordPress updates
- **Quarterly**: Review and optimize images
- **Annually**: Update dependencies and configurations

### 10.2 Performance Monitoring
- **Page Speed**: Use Lighthouse for performance testing
- **SEO**: Monitor search console for issues
- **Uptime**: Check site availability regularly

---

## 🎯 Success Checklist

### ✅ Pre-Integration
- [ ] WordPress site is accessible
- [ ] REST API is enabled
- [ ] Application password is created
- [ ] Environment variables are configured

### ✅ Integration
- [ ] Import script runs successfully with pagination
- [ ] All posts are imported (not just 100)
- [ ] All pages are imported
- [ ] Images are downloaded
- [ ] Build completes without errors

### ✅ Post-Integration
- [ ] Blog page displays correctly
- [ ] Individual posts are accessible
- [ ] Pages are accessible
- [ ] Images load properly
- [ ] SEO meta tags are present
- [ ] Site is deployed and live

---

## 🚀 Advanced Features

### Unlimited Content Import
The updated script now supports:
- ✅ **Pagination**: Automatically fetches all pages of content
- ✅ **Large datasets**: Can import thousands of posts
- ✅ **Progress tracking**: Shows import progress for each post
- ✅ **Error handling**: Continues import even if some posts fail
- ✅ **Rate limiting**: Respectful API requests with delays

### Custom Content Types
To import custom post types:
```javascript
// Add to wordpress-config.js
const customTypes = ['portfolio', 'testimonials', 'products'];
```

### Image Optimization
```javascript
// Advanced image settings
const imageConfig = {
  formats: ['webp', 'avif'],
  sizes: [400, 800, 1200, 1600],
  quality: 80,
  placeholder: true
};
```

### SEO Enhancements
```javascript
// Custom SEO settings
const seoConfig = {
  generateSchema: true,
  includeBreadcrumbs: true,
  socialImages: true,
  structuredData: true
};
```

---

## 📞 Support

If you encounter issues:

1. **Check the troubleshooting section** above
2. **Review WordPress logs** for API errors
3. **Verify Astro build logs** for content issues
4. **Test with a simple post** first
5. **Check network connectivity** and permissions

---

## 🎉 Congratulations!

You've successfully integrated WordPress with Astro! Your site now has:
- ✅ **Static WordPress content** with blazing-fast performance
- ✅ **SEO-optimized** pages and posts
- ✅ **Image optimization** for better loading
- ✅ **Modern development workflow** with Astro
- ✅ **CDN-ready** deployment
- ✅ **Unlimited content import** with pagination support

**Your WordPress site is now a high-performance static site with unlimited content!** 🚀 