# ☁️ Cloudinary Image Migration Guide

This guide will help you migrate your WordPress images to Cloudinary for better performance, automatic optimization, and advanced image transformations.

## 🎯 Why Cloudinary?

- **🚀 Automatic Optimization**: WebP, AVIF, and other modern formats
- **📱 Responsive Images**: Automatic resizing for different devices
- **🎨 Advanced Transformations**: Cropping, filters, overlays, and more
- **🌍 Global CDN**: Fast delivery worldwide
- **💰 Cost Effective**: Pay only for what you use
- **🔧 Easy Integration**: Simple URL-based transformations

## 🎯 Migration Strategies

### 1. **URL Transformation (Recommended - Easiest)**
- **What it does**: Changes image URLs to use Cloudinary format
- **Pros**: Fastest to implement, no data migration, instant benefits
- **Cons**: Still depends on WordPress server for original images
- **Best for**: Quick performance boost, testing Cloudinary

### 2. **Full Upload Migration (Advanced)**
- **What it does**: Downloads images from WordPress and uploads to Cloudinary
- **Pros**: Complete independence from WordPress, best performance
- **Cons**: Requires API setup, data migration, storage costs
- **Best for**: Complete migration, maximum performance

## 🚀 Quick Start: URL Transformation (Recommended)

### Step 1: Set up Cloudinary Account

1. **Create Cloudinary Account**:
   - Go to [Cloudinary Console](https://cloudinary.com/console)
   - Sign up for a free account
   - Get your Cloud Name from the dashboard

2. **Note your credentials**:
   - Cloud Name (e.g., `your-cloud-name`)
   - API Key (for uploads)
   - API Secret (for uploads)

### Step 2: Configure Environment

Create `.env` file in your project root:

```env
# Cloudinary Configuration
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
CLOUDINARY_FOLDER=kotacom
CLOUDINARY_TRANSFORMATION=f_auto,q_auto
CLOUDINARY_STRATEGY=url-only
TRANSFORM_URLS=true
BACKUP_ORIGINAL=true
```

### Step 3: Run Migration

```bash
# Test the migration (dry run)
npm run cloudinary:test

# Run the actual migration
npm run cloudinary:migrate
```

### Step 4: Test and Optimize

1. **Test image loading** in your browser
2. **Monitor Cloudinary dashboard** for usage
3. **Optimize transformations** as needed

## 🔧 Advanced: Full Upload Migration

### Step 1: Get API Credentials

1. **Get Cloudinary credentials**:
   - Go to Cloudinary Console → Settings → Access Keys
   - Copy Cloud Name, API Key, and API Secret

2. **Set up environment**:
   ```env
   CLOUDINARY_CLOUD_NAME=your-cloud-name
   CLOUDINARY_API_KEY=your-api-key
   CLOUDINARY_API_SECRET=your-api-secret
   CLOUDINARY_FOLDER=kotacom
   CLOUDINARY_STRATEGY=upload
   ```

### Step 2: Run Full Migration

```bash
npm run cloudinary:migrate
```

## 📊 URL Transformation Examples

### Before (WordPress URLs):
```
https://www.kotacom.id/wp-content/uploads/2025/06/image.jpg
/wp-content/uploads/2025/06/image.jpg
http://192.168.1.18:4321/wp-content/uploads/2025/06/image.png
```

### After (Cloudinary URLs):
```
https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto/kotacom/2025/06/image.jpg
https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto/kotacom/2025/06/image.png
```

## 🎨 Cloudinary Transformations

### Basic Transformations:
- `f_auto` - Automatic format selection (WebP, AVIF, etc.)
- `q_auto` - Automatic quality optimization
- `w_800` - Resize to 800px width
- `h_600` - Resize to 600px height
- `c_fill` - Crop and fill
- `c_scale` - Scale proportionally

### Advanced Transformations:
- `f_auto,q_auto,w_800,h_600,c_fill` - Responsive image
- `f_auto,q_auto,w_800,h_600,c_fill,g_auto` - Auto-gravity
- `f_auto,q_auto,w_800,h_600,c_fill,fl_progressive` - Progressive JPEG

### Example URLs:
```
# Basic optimization
https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto/kotacom/image.jpg

# Responsive thumbnail
https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto,w_300,h_200,c_fill/kotacom/image.jpg

# High-quality version
https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_80,w_1200/kotacom/image.jpg
```

## 📱 Responsive Images

### Using Cloudinary's Responsive Features:

```html
<!-- Responsive image with multiple sizes -->
<img src="https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto,w_800/kotacom/image.jpg"
     srcset="https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto,w_400/kotacom/image.jpg 400w,
             https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto,w_800/kotacom/image.jpg 800w,
             https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto,w_1200/kotacom/image.jpg 1200w"
     sizes="(max-width: 600px) 400px, (max-width: 1200px) 800px, 1200px"
     alt="Responsive Image">
```

## 💰 Cost Optimization

### Free Tier Limits:
- **25 GB storage**
- **25 GB bandwidth/month**
- **25,000 transformations/month**

### Cost-Saving Tips:
1. **Use `f_auto`** for automatic format selection
2. **Use `q_auto`** for automatic quality optimization
3. **Set appropriate sizes** (don't request 2000px for thumbnails)
4. **Cache transformations** in your application
5. **Monitor usage** in Cloudinary dashboard

## 🔍 Monitoring & Testing

### Test Image Loading

```bash
# Test current image URLs
npm run cloudinary:test-urls

# Check image performance
npm run cloudinary:performance
```

### Monitor in Cloudinary Dashboard

1. **Analytics**: View usage, bandwidth, and transformations
2. **Media Library**: Browse uploaded images
3. **Settings**: Configure optimization and delivery

## 🛠️ Troubleshooting

### Common Issues

1. **Images not loading**:
   - Check Cloudinary cloud name
   - Verify image paths are correct
   - Check Cloudinary dashboard for errors

2. **Slow performance**:
   - Use appropriate transformations
   - Enable `f_auto` and `q_auto`
   - Check network connectivity

3. **High costs**:
   - Monitor transformation usage
   - Optimize image sizes
   - Use caching strategies

### Debug Commands

```bash
# Check current configuration
npm run cloudinary:config

# Test specific URLs
npm run cloudinary:test-url https://example.com/image.jpg

# Backup before migration
npm run cloudinary:backup
```

## 📈 Best Practices

1. **Start with URL transformation**: Test performance before full migration
2. **Use appropriate transformations**: Don't over-optimize
3. **Monitor costs**: Track usage and optimize
4. **Cache transformations**: Store frequently used URLs
5. **Plan for scale**: Consider costs as traffic grows

## 🔄 Rollback Plan

If you need to revert the migration:

```bash
# Restore original URLs
npm run cloudinary:rollback

# Or manually restore from backup
npm run cloudinary:restore
```

## 📞 Support

- **Cloudinary Support**: [support.cloudinary.com](https://support.cloudinary.com)
- **Documentation**: [cloudinary.com/documentation](https://cloudinary.com/documentation)
- **Community**: [community.cloudinary.com](https://community.cloudinary.com)

## 🎯 Next Steps

1. **Choose your strategy** (URL transformation recommended)
2. **Set up Cloudinary account** and get credentials
3. **Create `.env` file** with your configuration
4. **Run the migration**
5. **Test image loading** and performance
6. **Optimize transformations** as needed

---

**Ready to start?** Follow the Quick Start guide above for the fastest way to get Cloudinary working with your images! 