# 🚀 WordPress Integration - Quick Reference

## ⚡ Essential Commands

### Setup & Configuration
```bash
# 1. Create environment file
touch .env

# 2. Edit .env with your WordPress credentials
nano .env

# 3. Test WordPress connection
npm run wordpress:setup

# 4. Import all WordPress content (now with pagination!)
npm run wordpress:import

# 5. Build the project
npm run build

# 6. Start development server
npm run dev
```

## 🔧 Environment Configuration (.env)

```env
# Required WordPress Settings
WORDPRESS_URL=https://your-wordpress-site.com
WORDPRESS_USERNAME=your_username
WORDPRESS_PASSWORD=your_application_password

# Pagination Settings (IMPORTANT!)
WORDPRESS_POSTS_PER_PAGE=100
WORDPRESS_MAX_POSTS=10000
POSTS_PER_PAGE=100
PAGES_PER_PAGE=50

# Optional Settings
DOWNLOAD_IMAGES=true
IMAGE_QUALITY=85
REQUEST_DELAY=500
TIMEOUT=30000
```

## 📁 File Structure After Import

```
src/content/
├── post/                    # WordPress posts (unlimited!)
│   ├── jasa-cetak-buku-jakarta.md
│   ├── jasa-digital-marketing-bandung.md
│   └── ... (hundreds/thousands of posts)
├── page/                    # WordPress pages
│   ├── about-us.md
│   ├── services.md
│   └── ...
└── config.ts               # Content schemas

public/images/wordpress/     # Downloaded images
├── image1.webp
├── image2.webp
└── ...
```

## 🔍 Troubleshooting Commands

```bash
# Test WordPress connection
npm run wordpress:setup

# Check if content was imported (should show many files)
ls -la src/content/post/
ls -la src/content/page/

# Verify build works
npm run build

# Check for errors
npm run build 2>&1 | grep -i error
```

## 🚀 Deployment Commands

```bash
# Build for production
npm run build

# Deploy to Vercel
vercel --prod

# Deploy to Netlify
netlify deploy --prod --dir=dist
```

## 📊 Expected Output Examples

### Successful Import with Pagination
```
🚀 Starting WordPress content import...
📋 Configuration:
   - WordPress URL: https://your-wordpress-site.com
   - Posts per page: 100
   - Output directory: /src/content/post

🔗 Connecting to WordPress: https://your-wordpress-site.com
📡 Fetching posts page 1...
✅ Fetched 100 posts from page 1
📡 Fetching posts page 2...
✅ Fetched 100 posts from page 2
📡 Fetching posts page 3...
✅ Fetched 50 posts from page 3
📄 Last page reached (50 posts)

📝 Processing posts...
📝 Processing post 1/250: "Sample Post Title"
✅ Successfully processed: Sample Post Title
...

📊 Import Summary:
✅ Successfully imported: 250 posts, 15 pages
❌ Failed to import: 0 items
📸 Downloaded: 45 images
📝 Total posts: 250
📄 Total pages: 15
```

### Successful Build
```
✅ /blog/index.html - Blog listing page
✅ /blog/[post-slug]/index.html - Individual posts (250+ files)
✅ /[page-slug]/index.html - WordPress pages
✅ /sitemap/index.html - Sitemap
```

## 🎯 Quick Checklist

- [ ] WordPress site accessible
- [ ] Application password created
- [ ] .env file configured with pagination settings
- [ ] Connection test successful
- [ ] Content imported (check for many files, not just 100)
- [ ] Build successful
- [ ] Pages accessible locally
- [ ] Deployed to production

## 🆘 Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| Only 100 posts imported | ✅ **FIXED**: Script now supports pagination automatically |
| Connection failed | Check WordPress URL and credentials |
| No posts found | Verify REST API is enabled |
| Images not downloading | Check file permissions |
| Build errors | Check content collection schemas |

## 📞 Quick Help

1. **Test connection**: `npm run wordpress:setup`
2. **Import content**: `npm run wordpress:import` (now with pagination!)
3. **Build project**: `npm run build`
4. **Check logs**: Look for pagination progress in output

## 🔥 New Features

### ✅ **Pagination Support**
- Automatically fetches ALL posts, not just 100
- Shows progress for each page
- Respectful API requests with delays
- Handles thousands of posts

### ✅ **Progress Tracking**
- Shows which post is being processed
- Displays total count and current progress
- Better error reporting

### ✅ **Performance Optimized**
- Rate limiting to avoid overwhelming WordPress
- Timeout handling for large imports
- Memory efficient processing

---

**Need more details?** See the full `WORDPRESS_INTEGRATION_GUIDE.md` for complete instructions.

**🎉 Your WordPress import now supports unlimited posts!** 🚀 