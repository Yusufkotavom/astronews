# ☁️ Cloudflare Image Migration Guide

This guide will help you migrate your WordPress images to Cloudflare for better performance, reliability, and cost savings.

## 🎯 Migration Strategies

### 1. **CDN Proxy (Recommended - Easiest)**
- **What it does**: Changes image URLs to use your Cloudflare domain
- **Pros**: Fastest to implement, no data migration, instant benefits
- **Cons**: Still depends on WordPress server for original images
- **Best for**: Quick performance boost, testing Cloudflare

### 2. **Cloudflare Images (Advanced)**
- **What it does**: Uploads images to Cloudflare Images service
- **Pros**: Best performance, automatic optimization, global CDN
- **Cons**: Requires API setup, data migration, potential costs
- **Best for**: High-traffic sites, maximum performance

### 3. **Cloudflare R2 (Storage)**
- **What it does**: Uploads images to Cloudflare R2 storage
- **Pros**: S3-compatible, cost-effective, global CDN
- **Cons**: Requires API setup, data migration
- **Best for**: Cost optimization, S3 replacement

## 🚀 Quick Start: CDN Proxy (Recommended)

### Step 1: Set up Cloudflare DNS

1. **Add your domain to Cloudflare**:
   - Go to [Cloudflare Dashboard](https://dash.cloudflare.com)
   - Add your domain (e.g., `kotacom.id`)
   - Update your domain's nameservers

2. **Create a subdomain for images** (optional):
   - Add DNS record: `images.kotacom.id` → `CNAME` → `kotacom.id`
   - Or use your main domain directly

### Step 2: Configure Environment

Create `.env` file in your project root:

```env
# Cloudflare Configuration
CLOUDFLARE_DOMAIN=images.kotacom.id
CLOUDFLARE_STRATEGY=cdn
TRANSFORM_URLS=true
BACKUP_ORIGINAL=true
```

### Step 3: Run Migration

```bash
# Test the migration (dry run)
npm run cloudflare:test

# Run the actual migration
npm run cloudflare:migrate
```

### Step 4: Configure Cloudflare Settings

1. **Enable Proxy (Orange Cloud)**:
   - In Cloudflare DNS, click the orange cloud icon for your domain
   - This enables Cloudflare's CDN and security features

2. **Optimize Images**:
   - Go to Speed → Optimization
   - Enable "Auto Minify" for images
   - Enable "Polish" for image optimization

3. **Configure Caching**:
   - Go to Caching → Configuration
   - Set "Browser Cache TTL" to "4 hours" or higher
   - Enable "Always Online"

## 🔧 Advanced: Cloudflare Images

### Step 1: Get API Credentials

1. **Get Account ID**:
   - Go to Cloudflare Dashboard → Right sidebar → Account ID

2. **Create API Token**:
   - Go to My Profile → API Tokens
   - Create Custom Token with "Cloudflare Images" permissions

### Step 2: Configure Environment

```env
# Cloudflare Images Configuration
CLOUDFLARE_STRATEGY=images
CLOUDFLARE_ACCOUNT_ID=your_account_id
CLOUDFLARE_IMAGES_API_TOKEN=your_api_token
CLOUDFLARE_DOMAIN=imagedelivery.net
```

### Step 3: Run Migration

```bash
npm run cloudflare:migrate
```

## 💾 Advanced: Cloudflare R2

### Step 1: Set up R2 Storage

1. **Create R2 Bucket**:
   - Go to Cloudflare Dashboard → R2 Object Storage
   - Create new bucket: `kotacom-images`

2. **Create API Token**:
   - Go to R2 → Manage R2 API tokens
   - Create new token with read/write permissions

### Step 2: Configure Environment

```env
# Cloudflare R2 Configuration
CLOUDFLARE_STRATEGY=r2
CLOUDFLARE_R2_ACCESS_KEY_ID=your_access_key
CLOUDFLARE_R2_SECRET_ACCESS_KEY=your_secret_key
CLOUDFLARE_R2_BUCKET=kotacom-images
CLOUDFLARE_R2_ENDPOINT=https://your-account-id.r2.cloudflarestorage.com
```

### Step 3: Run Migration

```bash
npm run cloudflare:migrate
```

## 📊 Performance Comparison

| Strategy | Setup Time | Performance | Cost | Complexity |
|----------|------------|-------------|------|------------|
| CDN Proxy | 5 minutes | ⭐⭐⭐⭐ | Free | Easy |
| Cloudflare Images | 30 minutes | ⭐⭐⭐⭐⭐ | $5/month | Medium |
| R2 Storage | 45 minutes | ⭐⭐⭐⭐ | $0.015/GB | Hard |

## 🔍 Monitoring & Testing

### Test Image Loading

```bash
# Test current image URLs
npm run cloudflare:test-urls

# Check image performance
npm run cloudflare:performance
```

### Monitor in Cloudflare Dashboard

1. **Analytics**: View traffic, bandwidth, and performance
2. **Caching**: Monitor cache hit rates
3. **Security**: Check for threats and attacks

## 🛠️ Troubleshooting

### Common Issues

1. **Images not loading**:
   - Check DNS propagation (can take 24-48 hours)
   - Verify Cloudflare proxy is enabled (orange cloud)
   - Check browser cache

2. **Slow performance**:
   - Enable Cloudflare's image optimization
   - Check cache settings
   - Monitor bandwidth usage

3. **API errors**:
   - Verify API tokens and permissions
   - Check account limits
   - Review error logs

### Debug Commands

```bash
# Check current configuration
npm run cloudflare:config

# Test specific URLs
npm run cloudflare:test-url https://example.com/image.jpg

# Backup before migration
npm run cloudflare:backup
```

## 📈 Best Practices

1. **Start with CDN Proxy**: Test performance before full migration
2. **Monitor costs**: Track bandwidth and storage usage
3. **Optimize images**: Use WebP format when possible
4. **Set up monitoring**: Use Cloudflare Analytics
5. **Plan for scale**: Consider costs as traffic grows

## 🔄 Rollback Plan

If you need to revert the migration:

```bash
# Restore original URLs
npm run cloudflare:rollback

# Or manually restore from backup
npm run cloudflare:restore
```

## 📞 Support

- **Cloudflare Support**: [support.cloudflare.com](https://support.cloudflare.com)
- **Documentation**: [developers.cloudflare.com](https://developers.cloudflare.com)
- **Community**: [community.cloudflare.com](https://community.cloudflare.com)

---

**Next Steps**: Choose your strategy and follow the step-by-step guide above. We recommend starting with the CDN Proxy approach for immediate benefits with minimal setup. 