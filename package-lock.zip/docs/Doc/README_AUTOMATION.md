# 🚀 Automation Workflow System

Sistem otomatisasi lengkap untuk generate content dari keyword hingga HTML siap WordPress.

## 📋 Workflow Overview

```
Keyword → JSON → Enriched → HTML → WordPress Ready
   ↓        ↓        ↓        ↓         ↓
 pending → json_created → enriched → html_generated → done
```

## 🛠️ Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Setup Environment
1. Copy `env_sample.txt` ke `.env`
2. Dapatkan Google API Key dari [Google AI Studio](https://makersuite.google.com/app/apikey)
3. Update `.env` dengan API key Anda:
```
GOOGLE_API_KEY=your_actual_api_key_here
```

### 3. File Structure
```
jinja/
├── keyword.csv              # Keywords dan status workflow
├── templates/
│   └── base.jinja          # Template Jinja2
├── prompt_enrichment.txt   # Prompt untuk AI enrichment
├── .env                    # Environment variables
├── automation_master.py    # Master automation script
├── py_ai_json.py          # Generate JSON dari keyword
├── py_ai_enrichment.py    # Enrich content dengan AI
├── py_json_jinja_html.py  # Render HTML dari JSON
└── py_jinja_wp.py         # WordPress preparation
```

## 🎯 Usage

### Full Automation (Recommended)
```bash
python automation_master.py
```

### Individual Scripts
```bash
# Step 1: Generate JSON content
python py_ai_json.py

# Step 2: Enrich content with AI
python py_ai_enrichment.py

# Step 3: Render HTML
python py_json_jinja_html.py

# Step 4: WordPress preparation
python py_jinja_wp.py
```

## 📊 Status Management

### CSV Structure
| Column | Description |
|--------|-------------|
| `keyword` | Target keyword untuk content |
| `status` | Current workflow status |
| `json_file` | Path ke file JSON generated |
| `json_file_enriched` | Path ke file JSON enriched |
| `html_file` | Path ke file HTML rendered |

### Status Flow
- `pending` → `json_created` → `enriched` → `html_generated` → `done`

### Adding New Keywords
1. Edit `keyword.csv`
2. Add new row with `status = "pending"`
3. Run automation script

## 🔧 Script Details

### 1. py_ai_json.py
- **Input**: Keywords dengan status `pending` atau `active`
- **Output**: JSON files di folder `output/`
- **Status Update**: `pending` → `json_created`

### 2. py_ai_enrichment.py
- **Input**: JSON files dengan status `json_created`
- **Output**: Enriched JSON files di folder `output_enriched/`
- **Status Update**: `json_created` → `enriched`

### 3. py_json_jinja_html.py
- **Input**: Enriched JSON files dengan status `enriched`
- **Output**: HTML files di folder `output/`
- **Status Update**: `enriched` → `html_generated`

### 4. py_jinja_wp.py
- **Input**: HTML files dengan status `html_generated`
- **Output**: WordPress-ready content
- **Status Update**: `html_generated` → `done`

## 📁 Output Folders

- `output/` - JSON files dan HTML files
- `output_enriched/` - Enriched JSON files

## ⚠️ Error Handling

- **Rate Limiting**: Automatic retry dengan delay
- **API Errors**: Graceful error handling dengan logging
- **File Not Found**: Skip dan continue ke item berikutnya
- **Invalid JSON**: Log error dan skip

## 🔄 Monitoring

### Check Workflow Status
```bash
python automation_master.py
```
Shows current progress and status counts.

### Manual Status Check
```python
import pandas as pd
df = pd.read_csv('keyword.csv')
print(df['status'].value_counts())
```

## 🚨 Troubleshooting

### Common Issues

1. **"GOOGLE_API_KEY tidak ditemukan"**
   - Pastikan file `.env` ada dan berisi API key yang valid

2. **"File CSV tidak ditemukan"**
   - Pastikan `keyword.csv` ada di root directory

3. **"Template tidak ditemukan"**
   - Pastikan `templates/base.jinja` ada

4. **Rate Limit Errors**
   - Script akan retry otomatis dengan delay
   - Jika masih error, tunggu beberapa menit

### Debug Mode
Untuk debugging, jalankan script individual dengan verbose output:
```bash
python -u py_ai_json.py
```

## 📈 Performance Tips

1. **Batch Processing**: Script memproses multiple items sekaligus
2. **Rate Limiting**: Built-in delays untuk menghindari API limits
3. **Error Recovery**: Continue processing meskipun ada error
4. **Status Tracking**: CSV-based status management

## 🔮 Future Enhancements

- [ ] WordPress REST API integration
- [ ] Multi-language support
- [ ] Custom template support
- [ ] Email notifications
- [ ] Web dashboard
- [ ] Database integration

## 📞 Support

Untuk masalah atau pertanyaan:
1. Check error logs di console output
2. Verify file structure dan dependencies
3. Test dengan single keyword terlebih dahulu 