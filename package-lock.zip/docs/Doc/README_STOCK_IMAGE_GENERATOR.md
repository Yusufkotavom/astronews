# Stock Image Generator for Website Content

This script generates relevant stock images for website content using Unsplash API and updates JSON files with image paths.

## Features

- 🖼️ **Stock Image Search**: Uses Unsplash API for high-quality stock photos
- 📝 **Smart Search Queries**: Creates contextual search terms based on content sections
- 💾 **Local Storage**: Saves images to `assets/images/` directory
- ☁️ **Cloudinary Upload**: Optional cloud hosting for images
- 📊 **JSON Updates**: Automatically updates JSON with image paths
- 🔄 **Status Tracking**: Updates keyword status to "prompt 3"

## Why Unsplash API?

- ✅ **Free**: 50 requests per hour (more than enough for your needs)
- ✅ **High Quality**: Professional stock photos
- ✅ **Reliable**: Stable API with good documentation
- ✅ **Legal**: Proper licensing for commercial use
- ✅ **Fast**: Quick image downloads

## Installation

1. **Install Dependencies**:
```bash
pip install -r requirements_image.txt
```

2. **Get Unsplash API Key** (FREE):
   - Go to [Unsplash Developers](https://unsplash.com/developers)
   - Sign up for free account
   - Create a new application
   - Copy your Access Key

3. **Optional: Setup Cloudinary** (for cloud hosting):
   - Sign up at [Cloudinary](https://cloudinary.com/)
   - Get your API key, secret, and cloud name

## Usage

### Method 1: Simple Wrapper Script
```bash
python run_stock_image_generator.py
```

### Method 2: Direct Command
```bash
python 4_py_stock_image_generator.py "output/jasa_pembuatan_website_medan_meta.json" "jasa pembuatan website medan" --unsplash-key "your_api_key_here"
```

### Method 3: With Cloudinary
```bash
python 4_py_stock_image_generator.py "output/jasa_pembuatan_website_medan_meta.json" "jasa pembuatan website medan" --unsplash-key "your_api_key" --cloudinary-key "your_cloudinary_key" --cloudinary-secret "your_cloudinary_secret" --cloudinary-cloud "your_cloud_name"
```

## Environment Variables (Optional)

You can set these environment variables to avoid typing API keys:

```bash
export UNSPLASH_API_KEY="your_unsplash_api_key"
export CLOUDINARY_API_KEY="your_cloudinary_api_key"
export CLOUDINARY_API_SECRET="your_cloudinary_api_secret"
export CLOUDINARY_CLOUD_NAME="your_cloudinary_cloud_name"
```

Or add to your `.env` file:
```
UNSPLASH_API_KEY=your_unsplash_api_key
CLOUDINARY_API_KEY=your_cloudinary_api_key
CLOUDINARY_API_SECRET=your_cloudinary_api_secret
CLOUDINARY_CLOUD_NAME=your_cloudinary_cloud_name
```

## What the Script Does

1. **Reads JSON Content**: Loads your website content JSON file
2. **Creates Search Queries**: Generates contextual search terms for each section:
   - Hero section → "website development team"
   - Features section → "responsive design"
   - About us section → "indonesian team"
   - Services section → "web services"
   - Testimonials → "business person"
   - Case studies → "business success"
   - Content section → "website professional"

3. **Searches Unsplash**: Finds relevant high-quality stock photos
4. **Downloads Images**: Saves images locally in `assets/images/`
5. **Uploads to Cloudinary**: If configured, uploads to cloud hosting
6. **Updates JSON**: Adds image paths to your JSON file
7. **Updates Status**: Changes keyword status to "prompt 3"

## Output

- **Images**: Saved to `assets/images/` with names like:
  - `jasa_pembuatan_website_medan_hero.jpg`
  - `jasa_pembuatan_website_medan_features.jpg`
  - `jasa_pembuatan_website_medan_about_us.jpg`
  - etc.

- **Updated JSON**: New file with `_with_images.json` suffix
- **Image Paths**: Updated in JSON with relative paths (`/assets/images/...`) or Cloudinary URLs

## Image Sections Generated

| Section | Search Query | Image Name |
|---------|--------------|------------|
| Hero | "website development team" | `{keyword}_hero.jpg` |
| Features | "responsive design" | `{keyword}_features.jpg` |
| About Us | "indonesian team" | `{keyword}_about_us.jpg` |
| Services | "web services" | `{keyword}_services.jpg` |
| Testimonials | "business person" | `{keyword}_testimonials.jpg` |
| Case Studies | "business success" | `{keyword}_case_studies.jpg` |
| Content | "website professional" | `{keyword}_content.jpg` |

## Search Query Customization

The script uses search terms from `promt/promt_3`. You can modify this file to change:
- Search terms
- Image styles
- Content focus
- Target audience

## Error Handling

- **API Rate Limits**: Built-in delays between requests
- **Failed Downloads**: Continues with other images
- **Missing Files**: Graceful error handling
- **Network Issues**: Retry logic for API calls

## Troubleshooting

### Common Issues

1. **"API Error 401"**: Invalid Unsplash API key
2. **"No content found"**: JSON file structure issue
3. **"Failed to download image"**: Network or API issue
4. **"No images found"**: Search query too specific

### Solutions

1. **Check API Keys**: Verify your Unsplash API key is correct
2. **Check JSON Structure**: Ensure JSON has `original_content` section
3. **Check Network**: Ensure stable internet connection
4. **Broaden Search**: Modify search queries in `promt_3` file

## Example Output

After running the script, your JSON will be updated with:

```json
{
  "original_content": {
    "hero": {
      "image_url": "/assets/images/jasa_pembuatan_website_medan_hero.jpg",
      "image_alt": "Jasa Pembuatan Website Medan Profesional & Terpercaya"
    }
  },
  "generated_images": {
    "generated_at": "2024-01-15T10:30:00",
    "total_images": 7,
    "image_details": {
      "hero": "/assets/images/jasa_pembuatan_website_medan_hero.jpg",
      "features": "/assets/images/jasa_pembuatan_website_medan_features.jpg"
    },
    "source": "Unsplash API"
  }
}
```

## Cost Considerations

- **Unsplash**: Free tier with 50 requests/hour
- **Cloudinary**: Free tier with storage limits
- **Local Storage**: No additional cost

## Next Steps

1. **Get Unsplash API Key** from [unsplash.com/developers](https://unsplash.com/developers)
2. **Run the script** with your API key
3. **Check generated images** in `assets/images/`
4. **Review updated JSON** file
5. **Use images** in your website templates
6. **Optionally set up Cloudinary** for cloud hosting

## Comparison: AI vs Stock Images

| Feature | AI Generated | Stock Images |
|---------|-------------|--------------|
| **Cost** | Free (Hugging Face) | Free (Unsplash) |
| **Quality** | Variable | High & Consistent |
| **Relevance** | Custom prompts | Search-based |
| **Speed** | Slower (generation) | Faster (download) |
| **Reliability** | API issues | More stable |
| **Legal** | Check terms | Commercial license |

**Recommendation**: Use stock images for production websites, AI generation for creative experiments. 