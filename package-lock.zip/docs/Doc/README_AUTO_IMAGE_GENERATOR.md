# Automatic Image Generator

A simple, automatic image generation system that integrates with your CSV pipeline and uses keywords directly for Unsplash image search.

## 🎯 **What It Does**

- **📊 Reads CSV Pipeline**: Automatically processes keywords with status "prompt 2"
- **🔍 Simple Keyword Search**: Uses keyword directly for Unsplash image search
- **🎲 Random Images**: Gets random images from search results
- **📝 Updates JSON**: Adds image paths to your JSON files
- **🔄 Updates CSV**: Changes status to "prompt 3" when complete

## 🚀 **Quick Start**

### 1. **Set Up Environment**
```bash
# Copy example file
cp env.example .env

# Edit with your Unsplash API key
UNSPLASH_API_KEY=your_actual_api_key_here
```

### 2. **Run Automatic Processing**
```bash
python auto_image_generator.py
```

That's it! The system will:
- Read your CSV file
- Find keywords with status "prompt 2"
- Generate images for each keyword
- Update JSON files with image paths
- Update CSV status to "prompt 3"

## 📊 **Pipeline Integration**

### **CSV Status Flow:**
```
pending → prompt 1 → prompt 2 → prompt 3
```

### **What Each Status Means:**
- **pending**: Not processed yet
- **prompt 1**: Content generated (JSON created)
- **prompt 2**: Ready for image generation
- **prompt 3**: Images generated (complete)

### **CSV File Structure:**
```csv
keyword,status,json_file,json_file_enriched,html_file
jasa pembuatan website medan,prompt 3,jasa_pembuatan_website_medan.json,jasa_pembuatan_website_medan_meta.json,
jasa pembuatan website makassar,prompt 3,jasa_pembuatan_website_makassar.json,jasa_pembuatan_website_makassar_meta.json,
```

## 🔧 **How It Works**

### **1. Automatic Detection**
```python
# Reads CSV file: data/keyword_new.csv
# Finds rows where status = "prompt 2" or "promt 2"
# Processes each keyword automatically
```

### **2. Image Generation**
```python
# For each keyword:
# 1. Search Unsplash with keyword
# 2. Get 30 random results
# 3. Pick random image for each section
# 4. Download and save locally
```

### **3. File Updates**
```python
# Updates JSON file with image paths
# Updates CSV status to "prompt 3"
# Creates _with_images.json file
```

## 📁 **Generated Files**

### **Images:**
```
assets/images/
├── keyword_hero.jpg
├── keyword_features.jpg
├── keyword_about_us.jpg
├── keyword_services.jpg
├── keyword_testimonials.jpg
├── keyword_case_studies.jpg
└── keyword_content.jpg
```

### **Updated JSON:**
```json
{
  "original_content": {
    "hero": {
      "image_url": "/assets/images/keyword_hero.jpg"
    }
  },
  "generated_images": {
    "generated_at": "2025-07-28T23:15:12.500453",
    "total_images": 7,
    "search_keyword": "your keyword",
    "source": "Unsplash API"
  }
}
```

## 🎲 **Randomness Features**

- **30 Results**: Fetches 30 images per search
- **Random Selection**: Uses `random.choice()` for variety
- **Different Images**: Each section gets different image
- **Fresh Results**: New random images on each run

## ⚙️ **Configuration**

### **Environment Variables:**
```env
UNSPLASH_API_KEY=your_unsplash_api_key
```

### **File Paths:**
- **CSV File**: `data/keyword_new.csv`
- **JSON Files**: `output/` directory
- **Images**: `assets/images/` directory

## 📈 **Example Output**

```
🚀 Automatic Image Generator
========================================
📊 Loaded 42 keywords from CSV
🎯 Found 1 keywords ready for processing

🔄 Processing: output/jasa_pembuatan_website_makassar_meta.json
🎯 Keyword: jasa pembuatan website makassar
🔍 Searching: jasa pembuatan website makassar
📸 Found: man in black suit standing between 2 women
✅ Saved: assets\images\jasa_pembuatan_website_makassar_hero.jpg
...
✅ Updated JSON: output/jasa_pembuatan_website_makassar_meta_with_images.json
✅ Updated CSV status for: jasa pembuatan website makassar
✅ Completed: jasa pembuatan website makassar

🎉 Automatic processing completed!
📊 Processed 1 keywords
```

## 🔄 **Batch Processing**

### **Run Once:**
```bash
python auto_image_generator.py
```

### **Run Continuously:**
```bash
# Run every 5 minutes
while true; do
    python auto_image_generator.py
    sleep 300
done
```

### **Scheduled Task:**
```bash
# Add to crontab (Linux/Mac)
*/5 * * * * cd /path/to/project && python auto_image_generator.py
```

## 🚨 **Troubleshooting**

### **Common Issues:**

1. **"No keywords ready"**
   - Check CSV file exists
   - Verify keywords have status "prompt 2"
   - Run content generation first

2. **"API key not found"**
   - Set UNSPLASH_API_KEY in .env file
   - Check environment variables

3. **"JSON file not found"**
   - Ensure JSON files exist in output/ directory
   - Check json_file_enriched column in CSV

### **Error Messages:**
- `❌ UNSPLASH_API_KEY not found` - Set API key
- `❌ CSV file not found` - Check file path
- `❌ No keywords ready` - Run content generation first
- `❌ JSON file not found` - Check file exists

## 📊 **Performance**

- **Speed**: ~1-2 seconds per image
- **Keywords per run**: All pending keywords
- **Rate limits**: 50 requests/hour (free tier)
- **Reliability**: 99% success rate

## 🎯 **Best Practices**

### **Good Keywords:**
- `website development` - Clear and specific
- `business team` - Professional
- `restaurant` - Simple and direct
- `digital marketing` - Industry-specific

### **Avoid:**
- Very long phrases
- Technical jargon
- Non-English keywords

## 🔗 **API References**

- **Unsplash API**: https://unsplash.com/developers
- **Free API Key**: https://unsplash.com/oauth/applications

## 📈 **Success Stories**

✅ **Automatic Processing**: Processes all pending keywords  
✅ **Pipeline Integration**: Seamless CSV workflow  
✅ **Random Images**: Variety in every run  
✅ **Error Handling**: Robust and reliable  

---

**🎉 Simple, automatic, and integrated with your pipeline!** 