# AI Image Generator for Website Content

This script generates images for website content using Hugging Face API and updates JSON files with image paths.

## Features

- 🎨 **AI Image Generation**: Uses Hugging Face Stable Diffusion API
- 📝 **Smart Prompts**: Creates contextual prompts based on content sections
- 💾 **Local Storage**: Saves images to `assets/images/` directory
- ☁️ **Cloudinary Upload**: Optional cloud hosting for images
- 📊 **JSON Updates**: Automatically updates JSON with image paths
- 🔄 **Status Tracking**: Updates keyword status to "prompt 3"

## Installation

1. **Install Dependencies**:
```bash
pip install -r requirements_image.txt
```

2. **Get Hugging Face API Key**:
   - Go to [Hugging Face](https://huggingface.co/settings/tokens)
   - Create a new token
   - Copy the token

3. **Optional: Setup Cloudinary** (for cloud hosting):
   - Sign up at [Cloudinary](https://cloudinary.com/)
   - Get your API key, secret, and cloud name

## Usage

### Method 1: Simple Wrapper Script
```bash
python run_image_generator.py
```

### Method 2: Direct Command
```bash
python 3_py_ai_image_generator.py "output/jasa_pembuatan_website_medan_meta.json" "jasa pembuatan website medan" --huggingface-key "your_api_key_here"
```

### Method 3: With Cloudinary
```bash
python 3_py_ai_image_generator.py "output/jasa_pembuatan_website_medan_meta.json" "jasa pembuatan website medan" --huggingface-key "your_api_key" --cloudinary-key "your_cloudinary_key" --cloudinary-secret "your_cloudinary_secret" --cloudinary-cloud "your_cloud_name"
```

## Environment Variables (Optional)

You can set these environment variables to avoid typing API keys:

```bash
export HUGGINGFACE_API_KEY="your_huggingface_api_key"
export CLOUDINARY_API_KEY="your_cloudinary_api_key"
export CLOUDINARY_API_SECRET="your_cloudinary_api_secret"
export CLOUDINARY_CLOUD_NAME="your_cloudinary_cloud_name"
```

## What the Script Does

1. **Reads JSON Content**: Loads your website content JSON file
2. **Creates Image Prompts**: Generates contextual prompts for each section:
   - Hero section
   - Features section
   - About us section
   - Services section
   - Testimonials
   - Case studies
   - Content section

3. **Generates Images**: Uses Hugging Face API to create images
4. **Saves Images**: Stores images locally in `assets/images/`
5. **Uploads to Cloudinary**: If configured, uploads to cloud hosting
6. **Updates JSON**: Adds image paths to your JSON file
7. **Updates Status**: Changes keyword status to "prompt 3"

## Output

- **Images**: Saved to `assets/images/` with names like:
  - `jasa_pembuatan_website_medan_hero.jpg`
  - `jasa_pembuatan_website_medan_features.jpg`
  - `jasa_pembuatan_website_medan_about_us.jpg`
  - etc.

- **Updated JSON**: New file with `_with_images.json` suffix
- **Image Paths**: Updated in JSON with relative paths (`/assets/images/...`) or Cloudinary URLs

## Image Sections Generated

| Section | Description | Image Name |
|---------|-------------|------------|
| Hero | Main landing page image | `{keyword}_hero.jpg` |
| Features | Website features visualization | `{keyword}_features.jpg` |
| About Us | Team photo | `{keyword}_about_us.jpg` |
| Services | Service offerings | `{keyword}_services.jpg` |
| Testimonials | Client portraits | `{keyword}_testimonials.jpg` |
| Case Studies | Success stories | `{keyword}_case_studies.jpg` |
| Content | Main content image | `{keyword}_content.jpg` |

## Prompt Customization

The script uses prompts from `promt/promt_3`. You can modify this file to change:
- Image styles
- Color schemes
- Visual themes
- Aspect ratios

## Error Handling

- **API Rate Limits**: Built-in delays between requests
- **Failed Generations**: Continues with other images
- **Missing Files**: Graceful error handling
- **Network Issues**: Retry logic for API calls

## Troubleshooting

### Common Issues

1. **"API Error 401"**: Invalid Hugging Face API key
2. **"No content found"**: JSON file structure issue
3. **"Failed to generate image"**: Network or API issue
4. **"Cloudinary upload error"**: Invalid Cloudinary credentials

### Solutions

1. **Check API Keys**: Verify your Hugging Face API key is correct
2. **Check JSON Structure**: Ensure JSON has `original_content` section
3. **Check Network**: Ensure stable internet connection
4. **Check Cloudinary**: Verify Cloudinary credentials if using

## Example Output

After running the script, your JSON will be updated with:

```json
{
  "original_content": {
    "hero": {
      "image_url": "/assets/images/jasa_pembuatan_website_medan_hero.jpg",
      "image_alt": "Jasa Pembuatan Website Medan Profesional & Terpercaya"
    }
  },
  "generated_images": {
    "generated_at": "2024-01-15T10:30:00",
    "total_images": 7,
    "image_details": {
      "hero": "/assets/images/jasa_pembuatan_website_medan_hero.jpg",
      "features": "/assets/images/jasa_pembuatan_website_medan_features.jpg"
    }
  }
}
```

## Cost Considerations

- **Hugging Face**: Free tier available with rate limits
- **Cloudinary**: Free tier with storage limits
- **Local Storage**: No additional cost

## Next Steps

1. Run the script with your Hugging Face API key
2. Check generated images in `assets/images/`
3. Review updated JSON file
4. Use images in your website templates
5. Optionally set up Cloudinary for cloud hosting 