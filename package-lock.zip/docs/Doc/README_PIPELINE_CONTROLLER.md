# 🎯 Pipeline Controller

Master orchestrator that runs all three modules in parallel without modifying them.

## 🚀 Features

- **Parallel Execution**: All modules run simultaneously
- **Automatic Coordination**: Modules automatically pick up work from CSV
- **Real-time Monitoring**: Live status updates and progress tracking
- **Graceful Shutdown**: Clean shutdown with Ctrl+C
- **Error Handling**: Robust error handling and recovery
- **No Code Changes**: Works with existing modules without modifications

## 📁 Files

- `pipeline_controller.py` - Main controller script
- `run_pipeline.py` - Simple runner script
- `README_PIPELINE_CONTROLLER.md` - This documentation

## 🎯 How It Works

### Pipeline Flow:
```
📋 CSV (pending) → 🚀 Module 1 → 📝 CSV (promt 1) → 🚀 Module 2 → 🎯 CSV (promt 2) → 🚀 Module 3 → ✅ CSV (prompt 3)
```

### Parallel Execution:
- **Module 1**: Processes "pending" keywords → generates content
- **Module 2**: Processes "promt 1" keywords → generates meta data  
- **Module 3**: Processes "promt 2" keywords → generates images

## 🚀 Usage

### Quick Start:
```bash
# Run the complete pipeline
python run_pipeline.py

# Or run controller directly
python pipeline_controller.py
```

### Check Status:
```bash
# Show current pipeline status
python pipeline_controller.py --status
```

### Stop Pipeline:
```bash
# Press Ctrl+C to stop gracefully
```

## 📊 Status Display

The controller shows real-time status:
```
📊 [14:30:25] Pipeline Status:
   📋 Total Keywords: 39
   ⏳ Pending: 34
   📝 Prompt 1: 0
   🎯 Prompt 2: 0
   ✅ Prompt 3: 4
   🔄 Progress: 12.8%
```

## 🔧 Configuration

### CSV File:
- Default: `data/keyword_new.csv`
- Custom: `python pipeline_controller.py --csv your_file.csv`

### Timeouts:
- Module 1 & 2: 5 minutes
- Module 3: 10 minutes
- Status updates: Every 60 seconds

## 🎯 Benefits

1. **⚡ Maximum Efficiency**: All modules work simultaneously
2. **🔄 Automatic Flow**: No manual intervention needed
3. **📊 Real-time Monitoring**: See progress live
4. **🛡️ Robust**: Handles errors and timeouts
5. **🎯 Scalable**: Can handle large keyword lists
6. **🔧 No Changes**: Works with existing modules

## 🚀 Example Output

```
🎯 Pipeline Controller
==================================================
✅ Started Module1
✅ Started Module2  
✅ Started Module3
✅ Started StatusMonitor

🎉 All modules started successfully!
📊 Pipeline is now running in parallel...
💡 Press Ctrl+C to stop the pipeline

✅ [14:30:25] MODULE1 SUCCESS: jasa pembuatan website bekasi
✅ [14:30:35] MODULE2 SUCCESS: jasa pembuatan website bekasi
✅ [14:30:45] MODULE3 SUCCESS: jasa pembuatan website bekasi

📊 [14:31:00] Pipeline Status:
   📋 Total Keywords: 39
   ⏳ Pending: 33
   📝 Prompt 1: 0
   🎯 Prompt 2: 0
   ✅ Prompt 3: 5
   🔄 Progress: 15.4%
```

## 🎯 Perfect for Production

This controller is perfect for:
- **High-volume processing**: Handle hundreds of keywords
- **24/7 operation**: Run continuously
- **Team collaboration**: Multiple people can monitor
- **Error recovery**: Automatic retry and recovery
- **Progress tracking**: Real-time status updates

## 🚀 Ready to Use!

Your pipeline is now enterprise-grade with:
- ✅ Parallel execution
- ✅ Automatic coordination  
- ✅ Real-time monitoring
- ✅ Error handling
- ✅ Graceful shutdown
- ✅ No code changes needed

Just run `python run_pipeline.py` and watch your keywords flow through the pipeline automatically! 🎉 