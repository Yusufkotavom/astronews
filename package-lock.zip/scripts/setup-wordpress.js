#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { WORDPRESS_CONFIG, getApiUrl } from './wordpress-config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function setupWordPress() {
  console.log('🔧 WordPress Integration Setup');
  console.log('==============================\n');

  // Check if .env file exists
  const envPath = path.join(__dirname, '../.env');
  let envExists = false;
  
  try {
    await fs.access(envPath);
    envExists = true;
    console.log('✅ .env file found');
  } catch {
    console.log('⚠️ .env file not found');
  }

  // Show current configuration
  console.log('\n📋 Current Configuration:');
  console.log(`   WordPress URL: ${WORDPRESS_CONFIG.SITE_URL}`);
  console.log(`   Posts per page: ${WORDPRESS_CONFIG.POSTS_PER_PAGE}`);
  console.log(`   API Base: ${WORDPRESS_CONFIG.API_BASE}`);

  // Test WordPress connection
  console.log('\n🔍 Testing WordPress Connection...');
  try {
    const response = await fetch(WORDPRESS_CONFIG.SITE_URL, {
      method: 'HEAD',
      timeout: 10000
    });
    
    if (response.ok) {
      console.log('✅ WordPress site is accessible');
      
      // Test REST API
      const apiUrl = getApiUrl('/posts', { per_page: 1 });
      console.log(`🔍 Testing REST API: ${apiUrl}`);
      
      const apiResponse = await fetch(apiUrl, {
        headers: {
          'Accept': 'application/json'
        },
        timeout: 10000
      });
      
      if (apiResponse.ok) {
        const posts = await apiResponse.json();
        console.log(`✅ REST API working - Found ${posts.length} test post(s)`);
      } else {
        console.log(`❌ REST API error: ${apiResponse.status} - ${apiResponse.statusText}`);
        console.log('💡 Make sure WordPress REST API is enabled');
      }
    } else {
      console.log(`❌ WordPress site error: ${response.status} - ${response.statusText}`);
    }
  } catch (error) {
    console.log(`❌ Connection failed: ${error.message}`);
    console.log('\n💡 Troubleshooting tips:');
    console.log('   1. Check if WordPress site is running');
    console.log('   2. Verify the URL is correct');
    console.log('   3. Check if site is accessible from this network');
    console.log('   4. Try accessing the site in a browser');
  }

  // Show available commands
  console.log('\n📚 Available Commands:');
  console.log('   npm run wordpress:import    - Import posts from WordPress');
  console.log('   npm run wordpress:test      - Test WordPress connection');
  console.log('   npm run build              - Build site with imported posts');
  console.log('   npm run dev                - Start development server');

  // Show configuration options
  console.log('\n⚙️ Configuration Options:');
  console.log('   1. Create .env file with your WordPress URL');
  console.log('   2. Update wordpress-config.js for custom settings');
  console.log('   3. Modify category and tag mappings');

  if (!envExists) {
    console.log('\n📝 To create .env file:');
    console.log('   cp .env.example .env');
    console.log('   # Then edit .env with your WordPress URL');
  }

  console.log('\n🎯 Next Steps:');
  console.log('   1. Ensure WordPress site is accessible');
  console.log('   2. Run: npm run wordpress:import');
  console.log('   3. Run: npm run build');
  console.log('   4. Deploy to Vercel');
}

// Run setup
setupWordPress().catch(console.error);