import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Function to read JSON file
function readJsonFile(filePath) {
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading file ${filePath}:`, error);
    return null;
  }
}

// Function to generate menu data string
function generateMenuDataString(menuData) {
  const menuItems = menuData.menu_items || [];
  
  const menuItemsString = menuItems.map(item => {
    let itemString = `    {
      title: "${item.title}",
      url: "${item.url}",
      icon: "${item.icon}"`;
    
    if (item.submenu && item.submenu.length > 0) {
      const submenuString = item.submenu.map(subItem => {
        let subItemString = `        {
          title: "${subItem.title}",
          url: "${subItem.url}",
          icon: "${subItem.icon}"`;
        
        if (subItem.submenu && subItem.submenu.length > 0) {
          const subSubmenuString = subItem.submenu.map(subSubItem => 
            `            {
              title: "${subSubItem.title}",
              url: "${subSubItem.url}",
              icon: "${subSubItem.icon}"
            }`
          ).join(',\n');
          
          subItemString += `,
          submenu: [
${subSubmenuString}
          ]`;
        }
        
        subItemString += `
        }`;
        return subItemString;
      }).join(',\n');
      
      itemString += `,
      submenu: [
${submenuString}
      ]`;
    }
    
    itemString += `
    }`;
    return itemString;
  }).join(',\n');
  
  return `// Read menu data from main_menu.json at runtime
const menuData: MenuData = {
  menu_items: [
${menuItemsString}
  ],
  whatsapp: {
    number: "${menuData.whatsapp?.number || '085799520350'}",
    message: "${menuData.whatsapp?.message || 'Halo! Saya tertarik dengan jasa pembuatan website Anda.'}"
  },
  brand: {
    name: "${menuData.brand?.name || 'Kotacom'}",
    logo_light: "${menuData.brand?.logo_light || '/logo-full.svg'}",
    logo_dark: "${menuData.brand?.logo_dark || '/logo-full-dark.svg'}"
  }
};`;
}

// Function to update Navbar component
function updateNavbarComponent(menuDataString) {
  const navbarPath = path.join(__dirname, '../src/components/partials/Navbar.astro');
  
  try {
    let content = fs.readFileSync(navbarPath, 'utf8');
    
    // Find the menu data section and replace it
    const startMarker = '// Read menu data from main_menu.json at runtime';
    const endMarker = 'const {';
    
    const startIndex = content.indexOf(startMarker);
    const endIndex = content.indexOf(endMarker, startIndex);
    
    if (startIndex !== -1 && endIndex !== -1) {
      const beforeMenu = content.substring(0, startIndex);
      const afterMenu = content.substring(endIndex);
      
      const newContent = beforeMenu + menuDataString + '\n\n' + afterMenu;
      
      fs.writeFileSync(navbarPath, newContent, 'utf8');
      console.log('✅ Navbar component updated successfully!');
    } else {
      console.error('❌ Could not find menu data markers in Navbar component');
    }
  } catch (error) {
    console.error('Error updating Navbar component:', error);
  }
}

// Main function
async function updateMenu() {
  console.log('🔄 Updating menu from main_menu.json...\n');
  
  const menuJsonPath = path.join(__dirname, '../src/data/main_menu.json');
  const menuData = readJsonFile(menuJsonPath);
  
  if (!menuData) {
    console.error('❌ Failed to read main_menu.json');
    return;
  }
  
  console.log('📋 Menu items found:');
  menuData.menu_items?.forEach((item, index) => {
    console.log(`  ${index + 1}. ${item.title} (${item.url})`);
    if (item.submenu) {
      item.submenu.forEach(subItem => {
        console.log(`     - ${subItem.title} (${subItem.url})`);
      });
    }
  });
  
  const menuDataString = generateMenuDataString(menuData);
  updateNavbarComponent(menuDataString);
  
  console.log('\n✨ Menu update completed!');
  console.log('💡 To apply changes, run: npm run build');
}

// Run the update
updateMenu().catch(console.error); 