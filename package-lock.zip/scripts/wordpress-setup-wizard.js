#!/usr/bin/env node

/**
 * WordPress Integration Setup Wizard
 * Interactive guide to set up WordPress integration with Astro
 */

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import readline from 'readline';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function question(prompt) {
  return new Promise((resolve) => {
    rl.question(prompt, resolve);
  });
}

async function checkFileExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function createEnvFile() {
  log('\n🔧 Step 1: WordPress Configuration', 'cyan');
  log('=====================================\n', 'cyan');

  const wordpressUrl = await question('🌐 Enter your WordPress site URL (e.g., https://example.com): ');
  const username = await question('👤 Enter your WordPress username: ');
  const password = await question('🔑 Enter your WordPress application password: ');

  const envContent = `# WordPress Configuration
WORDPRESS_URL=${wordpressUrl}
WORDPRESS_USERNAME=${username}
WORDPRESS_PASSWORD=${password}

# Content Settings
POSTS_PER_PAGE=100
PAGES_PER_PAGE=50
INCLUDE_DRAFTS=false
INCLUDE_PRIVATE=false

# Image Settings
DOWNLOAD_IMAGES=true
IMAGE_QUALITY=85
IMAGE_FORMAT=webp
`;

  await fs.writeFile('.env', envContent);
  log('✅ .env file created successfully!', 'green');
}

async function checkPrerequisites() {
  log('\n🔍 Step 2: Checking Prerequisites', 'cyan');
  log('==================================\n', 'cyan');

  const requiredFiles = [
    'src/content/config.ts',
    'scripts/import-wordpress-posts.js',
    'scripts/wordpress-config.js',
    'scripts/setup-wordpress.js'
  ];

  let allFilesExist = true;

  for (const file of requiredFiles) {
    const exists = await checkFileExists(file);
    if (exists) {
      log(`✅ ${file}`, 'green');
    } else {
      log(`❌ ${file} - MISSING`, 'red');
      allFilesExist = false;
    }
  }

  if (!allFilesExist) {
    log('\n❌ Some required files are missing!', 'red');
    log('Please ensure all WordPress integration files are present.', 'yellow');
    return false;
  }

  log('\n✅ All prerequisites are met!', 'green');
  return true;
}

async function testWordPressConnection() {
  log('\n🔐 Step 3: Testing WordPress Connection', 'cyan');
  log('==========================================\n', 'cyan');

  log('Testing connection to WordPress...', 'yellow');
  
  try {
    // Import and run the setup script
    const { execSync } = await import('child_process');
    const output = execSync('npm run wordpress:setup', { encoding: 'utf8' });
    log(output, 'green');
    return true;
  } catch (error) {
    log('❌ WordPress connection failed!', 'red');
    log('Please check your credentials and try again.', 'yellow');
    log('\nCommon issues:', 'yellow');
    log('1. WordPress URL is incorrect', 'yellow');
    log('2. Username or password is wrong', 'yellow');
    log('3. REST API is disabled', 'yellow');
    log('4. Application password not created', 'yellow');
    return false;
  }
}

async function importContent() {
  log('\n📥 Step 4: Importing WordPress Content', 'cyan');
  log('=========================================\n', 'cyan');

  const proceed = await question('Do you want to import WordPress content now? (y/n): ');
  
  if (proceed.toLowerCase() !== 'y') {
    log('⏭️ Skipping content import. You can run it later with: npm run wordpress:import', 'yellow');
    return true;
  }

  log('Importing WordPress content...', 'yellow');
  
  try {
    const { execSync } = await import('child_process');
    const output = execSync('npm run wordpress:import', { encoding: 'utf8' });
    log(output, 'green');
    return true;
  } catch (error) {
    log('❌ Content import failed!', 'red');
    log('Please check the error messages above.', 'yellow');
    return false;
  }
}

async function buildProject() {
  log('\n🏗️ Step 5: Building the Project', 'cyan');
  log('===============================\n', 'cyan');

  const proceed = await question('Do you want to build the project now? (y/n): ');
  
  if (proceed.toLowerCase() !== 'y') {
    log('⏭️ Skipping build. You can run it later with: npm run build', 'yellow');
    return true;
  }

  log('Building the project...', 'yellow');
  
  try {
    const { execSync } = await import('child_process');
    const output = execSync('npm run build', { encoding: 'utf8' });
    log('✅ Build completed successfully!', 'green');
    return true;
  } catch (error) {
    log('❌ Build failed!', 'red');
    log('Please check the error messages above.', 'yellow');
    return false;
  }
}

async function showNextSteps() {
  log('\n🎯 Next Steps', 'cyan');
  log('=============\n', 'cyan');

  log('✅ WordPress integration setup completed!', 'green');
  log('\n📋 What to do next:', 'yellow');
  log('1. Start development server: npm run dev', 'yellow');
  log('2. Test your blog at: http://localhost:4321/blog', 'yellow');
  log('3. Test individual posts and pages', 'yellow');
  log('4. Deploy to production when ready', 'yellow');
  
  log('\n📚 Useful commands:', 'yellow');
  log('• npm run wordpress:setup - Test connection', 'yellow');
  log('• npm run wordpress:import - Import new content', 'yellow');
  log('• npm run build - Build for production', 'yellow');
  log('• npm run dev - Start development server', 'yellow');
  
  log('\n📖 Documentation:', 'yellow');
  log('• WORDPRESS_INTEGRATION_GUIDE.md - Complete guide', 'yellow');
  log('• WORDPRESS_QUICK_REFERENCE.md - Quick reference', 'yellow');
}

async function main() {
  log('🚀 WordPress Integration Setup Wizard', 'bright');
  log('=====================================\n', 'bright');
  
  log('This wizard will help you set up WordPress integration with your Astro project.', 'yellow');
  log('Make sure you have:', 'yellow');
  log('• A WordPress site with REST API enabled', 'yellow');
  log('• An application password created in WordPress', 'yellow');
  log('• All required files in your project\n', 'yellow');

  try {
    // Step 1: Create .env file
    await createEnvFile();

    // Step 2: Check prerequisites
    const prerequisitesOk = await checkPrerequisites();
    if (!prerequisitesOk) {
      rl.close();
      return;
    }

    // Step 3: Test WordPress connection
    const connectionOk = await testWordPressConnection();
    if (!connectionOk) {
      rl.close();
      return;
    }

    // Step 4: Import content
    const importOk = await importContent();
    if (!importOk) {
      rl.close();
      return;
    }

    // Step 5: Build project
    const buildOk = await buildProject();
    if (!buildOk) {
      rl.close();
      return;
    }

    // Show next steps
    await showNextSteps();

  } catch (error) {
    log(`❌ Setup failed: ${error.message}`, 'red');
  } finally {
    rl.close();
  }
}

// Run the wizard
main().catch(console.error); 