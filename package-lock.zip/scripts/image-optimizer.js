#!/usr/bin/env node

/**
 * Image Optimizer Script
 * Downloads WordPress images and optimizes them for Astro
 */

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class ImageOptimizer {
  constructor() {
    this.stats = {
      downloaded: 0,
      optimized: 0,
      errors: 0,
      totalSize: 0
    };
  }

  /**
   * Create optimized directory structure
   */
  async createDirectories() {
    const dirs = [
      'public/images',
      'public/images/blog',
      'public/images/optimized'
    ];

    for (const dir of dirs) {
      await fs.mkdir(dir, { recursive: true });
      console.log(`✅ Created directory: ${dir}`);
    }
  }

  /**
   * Download image from WordPress
   */
  async downloadImage(url, filename) {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const buffer = await response.arrayBuffer();
      const filePath = path.join(process.cwd(), 'public/images/blog', filename);
      
      await fs.writeFile(filePath, Buffer.from(buffer));
      
      this.stats.downloaded++;
      this.stats.totalSize += buffer.byteLength;
      
      console.log(`✅ Downloaded: ${filename} (${(buffer.byteLength / 1024).toFixed(2)}KB)`);
      return true;
    } catch (error) {
      console.error(`❌ Failed to download ${url}:`, error.message);
      this.stats.errors++;
      return false;
    }
  }

  /**
   * Optimize image (placeholder for actual optimization)
   */
  async optimizeImage(inputPath, outputPath, options = {}) {
    try {
      // For now, just copy the file
      // In production, you'd use Sharp or similar
      await fs.copyFile(inputPath, outputPath);
      
      this.stats.optimized++;
      console.log(`✅ Optimized: ${path.basename(outputPath)}`);
      return true;
    } catch (error) {
      console.error(`❌ Failed to optimize ${inputPath}:`, error.message);
      this.stats.errors++;
      return false;
    }
  }

  /**
   * Generate optimized filename
   */
  generateFilename(originalUrl, postSlug) {
    const url = new URL(originalUrl);
    const ext = path.extname(url.pathname) || '.jpg';
    const timestamp = Date.now();
    return `${postSlug}-${timestamp}${ext}`;
  }

  /**
   * Process WordPress images
   */
  async processWordPressImages() {
    console.log('🔄 Starting WordPress image optimization...');
    
    try {
      // Import WordPress utility
      const { fetchPosts } = await import('../src/utils/wordpress.ts');
      
      // Fetch posts
      const posts = await fetchPosts({ perPage: 50 });
      
      if (posts.length === 0) {
        console.log('⚠️  No posts found to process');
        return;
      }

      console.log(`📝 Found ${posts.length} posts to process`);

      // Process each post
      for (const post of posts) {
        const featuredMedia = post._embedded?.['wp:featuredmedia']?.[0];
        
        if (featuredMedia?.source_url) {
          const filename = this.generateFilename(featuredMedia.source_url, post.slug);
          await this.downloadImage(featuredMedia.source_url, filename);
        }
      }

      console.log('\n📊 Optimization Summary:');
      console.log(`   Downloaded: ${this.stats.downloaded} images`);
      console.log(`   Optimized: ${this.stats.optimized} images`);
      console.log(`   Errors: ${this.stats.errors}`);
      console.log(`   Total size: ${(this.stats.totalSize / 1024 / 1024).toFixed(2)}MB`);

    } catch (error) {
      console.error('❌ Error processing WordPress images:', error);
    }
  }

  /**
   * Clean up old images
   */
  async cleanupOldImages() {
    try {
      const blogDir = path.join(process.cwd(), 'public/images/blog');
      const files = await fs.readdir(blogDir);
      
      const oldFiles = files.filter(file => {
        const stats = fs.statSync(path.join(blogDir, file));
        const daysOld = (Date.now() - stats.mtime.getTime()) / (1000 * 60 * 60 * 24);
        return daysOld > 30; // Remove files older than 30 days
      });

      for (const file of oldFiles) {
        await fs.unlink(path.join(blogDir, file));
        console.log(`🗑️  Removed old file: ${file}`);
      }

      console.log(`🧹 Cleaned up ${oldFiles.length} old images`);
    } catch (error) {
      console.error('❌ Error cleaning up old images:', error);
    }
  }
}

// Main execution
async function main() {
  const optimizer = new ImageOptimizer();
  
  console.log('🚀 Starting Image Optimization Process...\n');
  
  try {
    // Create directories
    await optimizer.createDirectories();
    
    // Process WordPress images
    await optimizer.processWordPressImages();
    
    // Clean up old images
    await optimizer.cleanupOldImages();
    
    console.log('\n✅ Image optimization completed successfully!');
    
  } catch (error) {
    console.error('❌ Image optimization failed:', error);
    process.exit(1);
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
} 