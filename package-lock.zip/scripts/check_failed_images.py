#!/usr/bin/env python3
"""
Script to check for failed image downloads and identify images that need replacement
Usage: python scripts/check_failed_images.py
"""

import os
import re
import sys
from pathlib import Path

def check_failed_images():
    """Check for failed image downloads in content files"""
    
    # Paths
    content_dir = Path("src/content/post")
    pages_dir = Path("src/content/page")
    images_dir = Path("public/images/asset")
    
    print("🔍 Checking for failed image downloads...")
    print("=" * 60)
    
    # Collect all content files
    content_files = []
    if content_dir.exists():
        content_files.extend(content_dir.glob("*.mdx"))
        content_files.extend(content_dir.glob("*.md"))
    if pages_dir.exists():
        content_files.extend(pages_dir.glob("*.mdx"))
        content_files.extend(pages_dir.glob("*.md"))
    
    print(f"📁 Found {len(content_files)} content files to check")
    print()
    
    # Track failed images
    failed_images = {}
    total_images = 0
    failed_count = 0
    
    # Get list of existing images
    existing_images = set()
    if images_dir.exists():
        for img_file in images_dir.iterdir():
            if img_file.is_file() and img_file.suffix.lower() in {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'}:
                existing_images.add(img_file.name)
    
    print(f"📷 Found {len(existing_images)} existing images in {images_dir}")
    print()
    
    # Check each content file
    for content_file in content_files:
        print(f"📄 Checking: {content_file.name}")
        
        try:
            with open(content_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Find all image references
            image_patterns = [
                r'/images/asset/([^"\s]+)',  # Local image references
                r'https?://[^"\s]+\.(?:jpg|jpeg|png|gif|webp|svg)',  # External URLs
                r'/wp-content/uploads/([^"\s]+)'  # WordPress uploads
            ]
            
            file_failed = []
            file_total = 0
            
            for pattern in image_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches:
                    file_total += 1
                    total_images += 1
                    
                    if pattern == r'/images/asset/([^"\s]+)':
                        # Local image reference
                        image_name = match
                        if image_name not in existing_images:
                            file_failed.append(f"Missing local image: {image_name}")
                            failed_count += 1
                    
                    elif pattern == r'https?://[^"\s]+\.(?:jpg|jpeg|png|gif|webp|svg)':
                        # External URL
                        file_failed.append(f"External URL (not downloaded): {match}")
                        failed_count += 1
                    
                    elif pattern == r'/wp-content/uploads/([^"\s]+)':
                        # WordPress upload reference
                        file_failed.append(f"WordPress upload reference: {match}")
                        failed_count += 1
            
            if file_failed:
                failed_images[content_file.name] = file_failed
                print(f"   ❌ {len(file_failed)} failed images")
            else:
                print(f"   ✅ All images OK")
                
        except Exception as e:
            print(f"   ❌ Error reading file: {e}")
    
    print()
    print("📊 SUMMARY")
    print("=" * 60)
    print(f"📁 Content files checked: {len(content_files)}")
    print(f"📷 Total image references: {total_images}")
    print(f"❌ Failed images: {failed_count}")
    print(f"✅ Existing images: {len(existing_images)}")
    print()
    
    if failed_images:
        print("❌ FAILED IMAGES BY FILE:")
        print("-" * 60)
        
        for filename, failures in failed_images.items():
            print(f"\n📄 {filename}:")
            for failure in failures:
                print(f"   • {failure}")
        
        print()
        print("💡 RECOMMENDATIONS:")
        print("-" * 60)
        print("1. For missing local images: Download the original images")
        print("2. For external URLs: Download and save locally")
        print("3. For WordPress uploads: Download from WordPress site")
        print("4. Replace failed images with working alternatives")
        print()
        print("🛠️  Next steps:")
        print("   • Run: npm run wordpress:import (to re-download)")
        print("   • Or manually download missing images")
        print("   • Update content files with correct image paths")
    else:
        print("✅ All images are working correctly!")
    
    return failed_images

def generate_replacement_list(failed_images):
    """Generate a list of images that need replacement"""
    
    if not failed_images:
        print("✅ No failed images to replace!")
        return
    
    print("\n📋 GENERATING REPLACEMENT LIST...")
    print("=" * 60)
    
    replacement_file = "failed_images_to_replace.txt"
    
    with open(replacement_file, 'w', encoding='utf-8') as f:
        f.write("# Failed Images - Need Replacement\n")
        f.write("# Generated by check_failed_images.py\n\n")
        
        for filename, failures in failed_images.items():
            f.write(f"# File: {filename}\n")
            for failure in failures:
                f.write(f"# {failure}\n")
            f.write("\n")
    
    print(f"📄 Replacement list saved to: {replacement_file}")
    print("💡 Edit this file to add replacement image URLs")

def main():
    failed_images = check_failed_images()
    generate_replacement_list(failed_images)

if __name__ == "__main__":
    main() 