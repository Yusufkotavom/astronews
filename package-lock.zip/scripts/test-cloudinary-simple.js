#!/usr/bin/env node

import 'dotenv/config';

console.log('🔧 Simple Cloudinary Test');
console.log('========================');

console.log('📋 Environment Variables:');
console.log(`   CLOUDINARY_CLOUD_NAME: ${process.env.CLOUDINARY_CLOUD_NAME || 'Not set'}`);
console.log(`   CLOUDINARY_API_KEY: ${process.env.CLOUDINARY_API_KEY ? 'Set' : 'Not set'}`);
console.log(`   CLOUDINARY_API_SECRET: ${process.env.CLOUDINARY_API_SECRET ? 'Set' : 'Not set'}`);
console.log(`   CLOUDINARY_STRATEGY: ${process.env.CLOUDINARY_STRATEGY || 'Not set'}`);

console.log('\n✅ Test completed successfully!'); 