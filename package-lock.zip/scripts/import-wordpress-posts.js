#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { WORDPRESS_CONFIG, getApiUrl, mapCategory, mapTags } from './wordpress-config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Content collection paths
const CONTENT_DIR = path.join(__dirname, '../src/content/post');
const PAGES_DIR = path.join(__dirname, '../src/content/page');
const IMAGES_DIR = path.join(__dirname, '../public/images/asset');

// Image deduplication cache - stores URL to filename mapping
const imageCache = new Map();

// Helper function to create a unique filename from URL
function createImageFilename(imageUrl) {
  try {
    const url = new URL(imageUrl);
    const urlParts = url.pathname.split('/');
    let originalFilename = urlParts[urlParts.length - 1];
    
    // If no filename in path, use domain as filename
    if (!originalFilename || originalFilename === '') {
      originalFilename = url.hostname.replace(/[^a-zA-Z0-9]/g, '-');
    }
    
    // Extract the actual filename without query parameters
    const cleanFilename = originalFilename.split('?')[0];
    
    // Create a hash from the URL to ensure uniqueness
    const urlHash = Buffer.from(imageUrl).toString('base64').substring(0, 8);
    
    // Ensure filename has an extension
    if (!cleanFilename.includes('.')) {
      return `${urlHash}-${cleanFilename}.jpg`;
    }
    
    return `${urlHash}-${cleanFilename}`;
  } catch (error) {
    // Fallback for invalid URLs
    const urlHash = Buffer.from(imageUrl).toString('base64').substring(0, 8);
    return `${urlHash}-external-image.jpg`;
  }
}

// Helper function to check if image already exists
async function imageExists(filename) {
  try {
    await fs.access(path.join(IMAGES_DIR, filename));
    return true;
  } catch {
    return false;
  }
}

// Helper function to fetch all WordPress posts with pagination
async function fetchAllWordPressPosts() {
  try {
    console.log(`🔗 Connecting to WordPress: ${WORDPRESS_CONFIG.SITE_URL}`);
    
    let allPosts = [];
    let page = 1;
    let hasMorePosts = true;
    
    while (hasMorePosts) {
      console.log(`📡 Fetching posts page ${page}...`);
      
      const apiUrl = getApiUrl(WORDPRESS_CONFIG.POSTS_ENDPOINT, {
        page: page.toString(),
        per_page: WORDPRESS_CONFIG.POSTS_PER_PAGE.toString()
      });
    
    const response = await fetch(apiUrl, {
      headers: {
        'User-Agent': 'Kotacom-Astro-Importer/1.0',
        'Accept': 'application/json'
      },
      timeout: 30000 // 30 seconds timeout
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status} - ${response.statusText}`);
    }
    
    const posts = await response.json();
      
      if (posts.length === 0) {
        hasMorePosts = false;
        console.log(`📄 No more posts found on page ${page}`);
      } else {
        allPosts = allPosts.concat(posts);
        console.log(`✅ Fetched ${posts.length} posts from page ${page}`);
        
        // Check if we got fewer posts than requested (indicating last page)
        if (posts.length < WORDPRESS_CONFIG.POSTS_PER_PAGE) {
          hasMorePosts = false;
          console.log(`📄 Last page reached (${posts.length} posts)`);
        } else {
          page++;
          // Add delay between requests to be respectful to the server
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    }
    
    console.log(`✅ Successfully fetched ${allPosts.length} total posts from WordPress`);
    return allPosts;
  } catch (error) {
    console.error('❌ Error fetching WordPress posts:', error.message);
    
    if (error.code === 'ENOTFOUND') {
      console.error('💡 Tip: Check if the WordPress URL is correct and accessible');
    } else if (error.code === 'ECONNREFUSED') {
      console.error('💡 Tip: WordPress site might be down or not accessible');
    } else if (error.message.includes('404')) {
      console.error('💡 Tip: WordPress REST API might not be enabled');
    }
    
    return [];
  }
}

// Helper function to fetch all WordPress pages with pagination
async function fetchAllWordPressPages() {
  try {
    console.log(`📄 Fetching WordPress pages...`);
    
    let allPages = [];
    let page = 1;
    let hasMorePages = true;
    
    while (hasMorePages) {
      console.log(`📡 Fetching pages page ${page}...`);
      
      const apiUrl = getApiUrl('/pages', {
        page: page.toString(),
        per_page: WORDPRESS_CONFIG.POSTS_PER_PAGE.toString()
      });
    
    const response = await fetch(apiUrl, {
      headers: {
        'User-Agent': 'Kotacom-Astro-Importer/1.0',
        'Accept': 'application/json'
      },
      timeout: 30000
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status} - ${response.statusText}`);
    }
    
    const pages = await response.json();
      
      if (pages.length === 0) {
        hasMorePages = false;
        console.log(`📄 No more pages found on page ${page}`);
      } else {
        allPages = allPages.concat(pages);
        console.log(`✅ Fetched ${pages.length} pages from page ${page}`);
        
        // Check if we got fewer pages than requested (indicating last page)
        if (pages.length < WORDPRESS_CONFIG.POSTS_PER_PAGE) {
          hasMorePages = false;
          console.log(`📄 Last page reached (${pages.length} pages)`);
        } else {
          page++;
          // Add delay between requests to be respectful to the server
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    }
    
    console.log(`✅ Successfully fetched ${allPages.length} total pages from WordPress`);
    return allPages;
  } catch (error) {
    console.error('❌ Error fetching WordPress pages:', error.message);
    return [];
  }
}

// Helper function to test WordPress connection
async function testWordPressConnection() {
  try {
    console.log(`🔍 Testing connection to: ${WORDPRESS_CONFIG.SITE_URL}`);
    
    const response = await fetch(WORDPRESS_CONFIG.SITE_URL, {
      method: 'HEAD',
      timeout: 10000
    });
    
    if (response.ok) {
      console.log('✅ WordPress site is accessible');
      return true;
    } else {
      console.log(`⚠️ WordPress site returned status: ${response.status}`);
      return false;
    }
  } catch (error) {
    console.error('❌ Error testing WordPress connection:', error.message);
    return false;
  }
}

// Helper function to download image
async function downloadImage(imageUrl, filename) {
  try {
    // Check if image already exists
    if (await imageExists(filename)) {
      console.log(`   📷 Image already exists: ${filename}`);
      return true;
    }
    
    // Validate URL
    let url;
    try {
      url = new URL(imageUrl);
    } catch (error) {
      console.error(`❌ Invalid URL: ${imageUrl}`);
      return false;
    }
    
    const response = await fetch(imageUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': WORDPRESS_CONFIG.SITE_URL
      },
      timeout: 30000
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status} - ${response.statusText}`);
    }
    
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.startsWith('image/')) {
      throw new Error(`Not an image: ${contentType}`);
    }
    
    const buffer = await response.arrayBuffer();
    const filePath = path.join(IMAGES_DIR, filename);
    
    await fs.writeFile(filePath, Buffer.from(buffer));
    console.log(`   📷 Downloaded new image: ${filename} (${contentType})`);
    return true;
  } catch (error) {
    console.error(`❌ Error downloading image ${imageUrl}:`, error.message);
    return false;
  }
}

// Helper function to process images in content
async function processImagesInContent(content, postSlug) {
  // NEW: Keep original URLs if configured to do so
  if (WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS) {
    console.log(`   📷 Converting to short WordPress URLs for ${postSlug}`);
    
    // Convert any WordPress URLs to short URLs (handles any domain)
    const fullUrlRegex = /https?:\/\/[^\/]+\/wp-content\/uploads\/([^"'\s]+)/gi;
    let processedContent = content;
    
    processedContent = processedContent.replace(fullUrlRegex, (match, path) => {
      return `/wp-content/uploads/${path}`;
    });
    
    return { content: processedContent, images: [] };
  }
  
  // NEW: Skip content images if configured to do so
  if (!WORDPRESS_CONFIG.DOWNLOAD_CONTENT_IMAGES) {
    console.log(`   📷 Skipping content images for ${postSlug} (content images disabled)`);
    return { content: content, images: [] };
  }
  
  const imageRegex = /<img[^>]+src=["']([^"']+)["'][^>]*>/gi;
  const images = [];
  let processedContent = content;
  
  let match;
  while ((match = imageRegex.exec(content)) !== null) {
    const imageUrl = match[1];
    
    // Skip data URLs and relative URLs
    if (imageUrl.startsWith('data:') || imageUrl.startsWith('#')) {
      console.log(`   📷 Skipping data/relative URL: ${imageUrl.substring(0, 50)}...`);
      continue;
    }
    
    // Normalize URL (remove query parameters and fragments)
    const normalizedUrl = imageUrl.split('?')[0].split('#')[0];
    
    // Check if we've already processed this image URL
    if (imageCache.has(normalizedUrl)) {
      const cachedFilename = imageCache.get(normalizedUrl);
      console.log(`   📷 Using cached image: ${cachedFilename}`);
      images.push(cachedFilename);
                      processedContent = processedContent.replace(
                  imageUrl,
                  `/images/asset/${cachedFilename}`
                );
      continue;
    }
    
    // Create unique filename based on URL
    const filename = createImageFilename(normalizedUrl);
    
    console.log(`   📷 Processing image: ${imageUrl.substring(0, 80)}...`);
    const success = await downloadImage(normalizedUrl, filename);
    if (success) {
      // Cache the URL to filename mapping
      imageCache.set(normalizedUrl, filename);
      images.push(filename);
                      processedContent = processedContent.replace(
                  imageUrl,
                  `/images/asset/${filename}`
                );
    } else {
      console.log(`   ❌ Failed to download image: ${imageUrl.substring(0, 80)}...`);
    }
  }
  
  return { content: processedContent, images };
}

// Helper function to clean HTML content
function cleanHtmlContent(html) {
  if (!html) return '';
  
  // Remove script tags
  html = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
  
  // Remove style tags
  html = html.replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '');
  
  // Remove comments
  html = html.replace(/<!--[\s\S]*?-->/g, '');
  
  // Remove DOCTYPE, html, head, and body tags
  html = html.replace(/<!DOCTYPE[^>]*>/gi, '');
  html = html.replace(/<html[^>]*>/gi, '');
  html = html.replace(/<\/html>/gi, '');
  html = html.replace(/<head[^>]*>[\s\S]*?<\/head>/gi, '');
  html = html.replace(/<body[^>]*>/gi, '');
  html = html.replace(/<\/body>/gi, '');
  
  // Remove WordPress-specific blocks and classes
  html = html.replace(/<!-- wp:.*? -->/g, '');
  html = html.replace(/<!-- \/wp:.*? -->/g, '');
  html = html.replace(/class="[^"]*wp-block-[^"]*"/g, '');
  html = html.replace(/class="[^"]*align[^"]*"/g, '');
  html = html.replace(/class="[^"]*size-[^"]*"/g, '');
  
  // Replace WordPress-specific CSS classes with Tailwind equivalents
  html = html.replace(/class="([^"]*?)gemini-blue([^"]*?)"/g, 'class="$1text-blue-600$2"');
  html = html.replace(/class="([^"]*?)gemini-yellow([^"]*?)"/g, 'class="$1text-yellow-500$2"');
  html = html.replace(/class="([^"]*?)gemini-green([^"]*?)"/g, 'class="$1text-green-500$2"');
  html = html.replace(/class="([^"]*?)gemini-purple([^"]*?)"/g, 'class="$1text-purple-500$2"');
  
  // Replace background classes
  html = html.replace(/class="([^"]*?)bg-gemini-blue([^"]*?)"/g, 'class="$1bg-blue-600$2"');
  html = html.replace(/class="([^"]*?)bg-gemini-yellow([^"]*?)"/g, 'class="$1bg-yellow-500$2"');
  html = html.replace(/class="([^"]*?)bg-gemini-green([^"]*?)"/g, 'class="$1bg-green-500$2"');
  html = html.replace(/class="([^"]*?)bg-gemini-purple([^"]*?)"/g, 'class="$1bg-purple-500$2"');
  
  // Replace text classes
  html = html.replace(/class="([^"]*?)text-gemini-blue([^"]*?)"/g, 'class="$1text-blue-600$2"');
  html = html.replace(/class="([^"]*?)text-gemini-yellow([^"]*?)"/g, 'class="$1text-yellow-500$2"');
  html = html.replace(/class="([^"]*?)text-gemini-green([^"]*?)"/g, 'class="$1text-green-500$2"');
  html = html.replace(/class="([^"]*?)text-gemini-purple([^"]*?)"/g, 'class="$1text-purple-500$2"');
  
  // Replace hover classes
  html = html.replace(/class="([^"]*?)hover:text-gemini-blue([^"]*?)"/g, 'class="$1hover:text-blue-600$2"');
  html = html.replace(/class="([^"]*?)hover:text-gemini-purple([^"]*?)"/g, 'class="$1hover:text-purple-600$2"');
  html = html.replace(/class="([^"]*?)hover:bg-gemini-blue([^"]*?)"/g, 'class="$1hover:bg-blue-700$2"');
  html = html.replace(/class="([^"]*?)hover:bg-gemini-yellow([^"]*?)"/g, 'class="$1hover:bg-yellow-600$2"');
  html = html.replace(/class="([^"]*?)hover:bg-gemini-green([^"]*?)"/g, 'class="$1hover:bg-green-600$2"');
  html = html.replace(/class="([^"]*?)hover:bg-gemini-purple([^"]*?)"/g, 'class="$1hover:bg-purple-600$2"');
  
  // Replace dashicons with emojis
  html = html.replace(/<span class="dashicons dashicons-book-alt[^"]*"><\/span>/g, '📚');
  html = html.replace(/<span class="dashicons dashicons-money-alt[^"]*"><\/span>/g, '💰');
  html = html.replace(/<span class="dashicons dashicons-media-text[^"]*"><\/span>/g, '📄');
  html = html.replace(/<span class="dashicons dashicons-book[^"]*"><\/span>/g, '📖');
  html = html.replace(/<span class="dashicons dashicons-format-image[^"]*"><\/span>/g, '🖼️');
  html = html.replace(/<span class="dashicons dashicons-shield-alt[^"]*"><\/span>/g, '🛡️');
  
  // Replace rh-icon classes with emojis
  html = html.replace(/<i class="rh-icon rh-25-lightbulb[^"]*"><\/i>/g, '💡');
  html = html.replace(/<i class="rh-icon rh-98-money[^"]*"><\/i>/g, '💵');
  html = html.replace(/<i class="rh-icon rh-33-truck[^"]*"><\/i>/g, '🚚');
  
  // Fix malformed HTML tags
  html = html.replace(/<br><\/p>/g, '</p>');
  html = html.replace(/<br\s*\/?><\/p>/g, '</p>');
  html = html.replace(/<br\s*\/?>\s*<\/p>/g, '</p>');
  
  // Fix self-closing tags that are not properly closed
  html = html.replace(/<br\s*\/?>/g, '<br />');
  html = html.replace(/<img([^>]*?)(?<!\/)\s*>/g, '<img$1 />');
  html = html.replace(/<input([^>]*?)(?<!\/)\s*>/g, '<input$1 />');
  html = html.replace(/<meta([^>]*?)(?<!\/)\s*>/g, '<meta$1 />');
  html = html.replace(/<link([^>]*?)(?<!\/)\s*>/g, '<link$1 />');
  
  // Fix malformed list structures - more comprehensive approach
  html = html.replace(/<li[^>]*>([^<]*<[^>]*>[^<]*<\/[^>]*>[^<]*)<\/div>/g, '<li>$1</li>');
  html = html.replace(/<li[^>]*>([^<]*<[^>]*>[^<]*<\/[^>]*>[^<]*)<\/div>/g, '<li>$1</li>');
  
  // Fix unclosed list items
  html = html.replace(/<li[^>]*>([^<]*<[^>]*>[^<]*<\/[^>]*>[^<]*)(?=<li|<\/ul|<\/ol)/g, '<li>$1</li>');
  
  // Fix malformed nested divs in lists
  html = html.replace(/<li[^>]*>([^<]*<div[^>]*>[^<]*<\/div>[^<]*)<\/div>/g, '<li>$1</li>');
  
  // Additional fixes for complex HTML structures
  html = html.replace(/<li[^>]*>([^<]*<[^>]*>[^<]*<\/[^>]*>[^<]*<[^>]*>[^<]*<\/[^>]*>[^<]*)<\/div>/g, '<li>$1</li>');
  html = html.replace(/<li[^>]*>([^<]*<[^>]*>[^<]*<\/[^>]*>[^<]*<[^>]*>[^<]*<\/[^>]*>[^<]*<[^>]*>[^<]*<\/[^>]*>[^<]*)<\/div>/g, '<li>$1</li>');
  
  // Fix any remaining unclosed list items
  html = html.replace(/<li[^>]*>([^<]*)(?=<li|<\/ul|<\/ol)/g, '<li>$1</li>');
  
  // Clean up extra whitespace
  html = html.replace(/\s+/g, ' ');
  html = html.trim();
  
  // Convert HTML entities
  html = html.replace(/&nbsp;/g, ' ');
  html = html.replace(/&amp;/g, '&');
  html = html.replace(/&lt;/g, '<');
  html = html.replace(/&gt;/g, '>');
  html = html.replace(/&quot;/g, '"');
  html = html.replace(/&#39;/g, "'");
  html = html.replace(/&#8216;/g, "'");
  html = html.replace(/&#8217;/g, "'");
  html = html.replace(/&#8220;/g, '"');
  html = html.replace(/&#8221;/g, '"');
  
  return html;
}

// Helper function to get featured image
// Helper function to get featured image URL
async function getFeaturedImageUrl(post, postSlug) {
  // NEW: Keep original WordPress URL if configured
  if (WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS) {
    if (post._embedded && post._embedded['wp:featuredmedia'] && post._embedded['wp:featuredmedia'][0]) {
      const imageUrl = post._embedded['wp:featuredmedia'][0].source_url;
      
      // Convert to short URL (handles any domain)
      const shortUrl = imageUrl.replace(/^https?:\/\/[^\/]+/, '');
      console.log(`   📷 Converting featured image to short URL: ${shortUrl}`);
      return shortUrl;
    }
    return undefined;
  }
  
  // Download featured image if configured
  if (!WORDPRESS_CONFIG.DOWNLOAD_IMAGES || !WORDPRESS_CONFIG.DOWNLOAD_FEATURED_IMAGES_ONLY) {
    return undefined;
  }
  
  if (post._embedded && post._embedded['wp:featuredmedia'] && post._embedded['wp:featuredmedia'][0]) {
    const imageUrl = post._embedded['wp:featuredmedia'][0].source_url;
    
    // Check if we've already processed this image URL
    if (imageCache.has(imageUrl)) {
      const cachedFilename = imageCache.get(imageUrl);
      console.log(`   📷 Using cached featured image: ${cachedFilename}`);
      return `/images/asset/${cachedFilename}`;
    }
    
    // Create unique filename based on URL
    const filename = createImageFilename(imageUrl);
    
    console.log(`   📷 Downloading featured image: ${filename}`);
    const success = await downloadImage(imageUrl, filename);
    if (success) {
      // Cache the URL to filename mapping
      imageCache.set(imageUrl, filename);
      return `/images/asset/${filename}`;
    }
  }
  return undefined;
}

function getFeaturedImage(post) {
  if (post._embedded && post._embedded['wp:featuredmedia'] && post._embedded['wp:featuredmedia'][0]) {
    return post._embedded['wp:featuredmedia'][0].source_url;
  }
  return undefined;
}

// Helper function to get categories
function getCategories(post) {
  if (!post._embedded || !post._embedded['wp:term']) return [];
  
  const categoryTerms = post._embedded['wp:term'].find(terms => 
    terms.length > 0 && terms[0].taxonomy === 'category'
  );
  
  if (!categoryTerms) return [];
  
  return categoryTerms.map(term => mapCategory(term.name));
}

// Helper function to get tags
function getTags(post) {
  if (!post._embedded || !post._embedded['wp:term']) return [];
  
  const tagTerms = post._embedded['wp:term'].find(terms => 
    terms.length > 0 && terms[0].taxonomy === 'post_tag'
  );
  
  if (!tagTerms) return [];
  
  const tags = tagTerms.map(term => term.name);
  return mapTags(tags);
}

// Helper function to create slug
function createSlug(title) {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim('-');
}

// Helper function to create post frontmatter
function createPostFrontmatter(post) {
  const featuredImage = getFeaturedImage(post);
  const categories = getCategories(post);
  const tags = getTags(post);
  
  // Clean description from HTML tags
  const description = post.excerpt.rendered
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim()
    .substring(0, 160);
  
  return {
    title: post.title.rendered,
    description: description,
    publishDate: new Date(post.date).toISOString(),
    author: post._embedded?.author?.[0]?.name || WORDPRESS_CONFIG.DEFAULT_AUTHOR,
    image: featuredImage,
    category: categories.length > 0 ? categories[0] : 'General',
    tags: tags,
    draft: false,
    featured: false
  };
}

// Helper function to create page frontmatter
function createPageFrontmatter(page) {
  const featuredImage = getFeaturedImage(page);
  
  // Clean description from HTML tags
  const description = page.excerpt.rendered
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim()
    .substring(0, 160);
  
  return {
    title: page.title.rendered,
    description: description,
    publishDate: new Date(page.date).toISOString(),
    author: page._embedded?.author?.[0]?.name || WORDPRESS_CONFIG.DEFAULT_AUTHOR,
    image: featuredImage,
    draft: false
  };
}

async function writeMdxFile(filePath, frontmatter, content) {
  try {
    // Convert the file path from .mdx to .md
    const mdFilePath = filePath.replace('.mdx', '.md');
    
    const frontmatterString = `---
${Object.entries(frontmatter)
  .filter(([key, value]) => value !== undefined && value !== null)
    .map(([key, value]) => {
      if (Array.isArray(value)) {
      return `${key}:
${value.map(item => `  - ${item}`).join('\n')}`;
      }
    return `${key}: ${JSON.stringify(value)}`;
    })
  .join('\n')}
---

${content}
`;
  
    await fs.writeFile(mdFilePath, frontmatterString, 'utf8');
    return true;
  } catch (error) {
    console.error(`❌ Error writing file ${mdFilePath}:`, error.message);
    return false;
  }
}

// Main import function
async function importWordPressContent() {
  console.log('🚀 Starting WordPress content import...');
  console.log(`📋 Configuration:`);
  console.log(`   - WordPress URL: ${WORDPRESS_CONFIG.SITE_URL}`);
  console.log(`   - Posts per page: ${WORDPRESS_CONFIG.POSTS_PER_PAGE}`);
  console.log(`   - Output directory: ${CONTENT_DIR}`);
  console.log(`   - Pages directory: ${PAGES_DIR}`);
  console.log(`   - Images directory: ${IMAGES_DIR}`);
  
  // Check for limit parameter
  const limit = process.argv.includes('--limit') ? 
    parseInt(process.argv[process.argv.indexOf('--limit') + 1]) : null;
  
  if (limit) {
    console.log(`   - Import limit: ${limit} posts`);
  }
  
  // Test connection first
  const isConnected = await testWordPressConnection();
  if (!isConnected) {
    console.log('\n❌ Cannot connect to WordPress. Please check:');
    console.log('   1. WordPress site is running and accessible');
    console.log('   2. WordPress REST API is enabled');
    console.log('   3. No firewall blocking the connection');
    console.log('   4. Correct URL in configuration');
    return;
  }
  
  // Ensure directories exist
  try {
    await fs.mkdir(CONTENT_DIR, { recursive: true });
    await fs.mkdir(PAGES_DIR, { recursive: true });
    await fs.mkdir(IMAGES_DIR, { recursive: true });
  } catch (error) {
    console.error('❌ Error creating directories:', error.message);
    return;
  }
  
  // Fetch all posts and pages with pagination
  const posts = await fetchAllWordPressPosts();
  const pages = await fetchAllWordPressPages();
  
  if (posts.length === 0 && pages.length === 0) {
    console.log('❌ No content found or error occurred');
    return;
  }
  
  // Apply limit if specified
  const postsToProcess = limit ? posts.slice(0, limit) : posts;
  const pagesToProcess = limit ? pages.slice(0, limit) : pages;
  
  console.log(`📊 Found ${posts.length} posts and ${pages.length} pages`);
  console.log(`📊 Processing ${postsToProcess.length} posts and ${pagesToProcess.length} pages`);
  
  let successCount = 0;
  let errorCount = 0;
  let imageCount = 0;
  
  // Process posts
  console.log('\n📝 Processing posts...');
  for (let i = 0; i < postsToProcess.length; i++) {
    const post = postsToProcess[i];
    try {
      console.log(`📝 Processing post ${i + 1}/${postsToProcess.length}: "${post.title.rendered}"`);
      
      const slug = createSlug(post.title.rendered);
      const frontmatter = createPostFrontmatter(post);
      let content = cleanHtmlContent(post.content.rendered);
      
      // Get featured image URL (original or downloaded)
      const featuredImagePath = await getFeaturedImageUrl(post, slug);
      if (featuredImagePath) {
        frontmatter.image = featuredImagePath;
        imageCount++;
      }
      
      // Process images in content (if enabled)
      const { content: processedContent, images } = await processImagesInContent(content, slug);
      content = processedContent;
      imageCount += images.length;
      
      const success = await writeMdxFile(
        path.join(CONTENT_DIR, `${slug}.mdx`), 
        frontmatter, 
        content
      );
      
      if (success) {
        successCount++;
        console.log(`✅ Successfully processed: ${post.title.rendered}`);
      } else {
        errorCount++;
        console.log(`❌ Failed to process: ${post.title.rendered}`);
      }
      
      // Add small delay to avoid overwhelming the system
      await new Promise(resolve => setTimeout(resolve, 100));
      
    } catch (error) {
      console.error(`❌ Error processing post "${post.title.rendered}":`, error.message);
      errorCount++;
    }
  }
  
  // Process pages
  console.log('\n📄 Processing pages...');
  for (let i = 0; i < pagesToProcess.length; i++) {
    const page = pagesToProcess[i];
    try {
      console.log(`📄 Processing page ${i + 1}/${pagesToProcess.length}: "${page.title.rendered}"`);
      
      const slug = createSlug(page.title.rendered);
      const frontmatter = createPageFrontmatter(page);
      let content = cleanHtmlContent(page.content.rendered);
      
      // Get featured image URL (original or downloaded)
      const featuredImagePath = await getFeaturedImageUrl(page, slug);
      if (featuredImagePath) {
        frontmatter.image = featuredImagePath;
        imageCount++;
      }
      
      // Process images in content (if enabled)
      const { content: processedContent, images } = await processImagesInContent(content, slug);
      content = processedContent;
      imageCount += images.length;
      
      const success = await writeMdxFile(
        path.join(PAGES_DIR, `${slug}.mdx`), 
        frontmatter, 
        content
      );
      
      if (success) {
        successCount++;
        console.log(`✅ Successfully processed: ${page.title.rendered}`);
      } else {
        errorCount++;
        console.log(`❌ Failed to process: ${page.title.rendered}`);
      }
      
      // Add small delay to avoid overwhelming the system
      await new Promise(resolve => setTimeout(resolve, 100));
      
    } catch (error) {
      console.error(`❌ Error processing page "${page.title.rendered}":`, error.message);
      errorCount++;
    }
  }
  
  // Summary
  console.log('\n📊 Import Summary:');
  console.log(`   ✅ Successfully imported: ${successCount} items`);
  console.log(`   ❌ Failed to import: ${errorCount} items`);
  console.log(`   🖼️  Images processed: ${imageCount}`);
  console.log(`   🔄 Unique images downloaded: ${imageCache.size}`);
  console.log(`   📁 Posts directory: ${CONTENT_DIR}`);
  console.log(`   📁 Pages directory: ${PAGES_DIR}`);
  console.log(`   📁 Images directory: ${IMAGES_DIR}`);
  
  if (successCount > 0) {
    console.log('\n🎉 WordPress content import completed successfully!');
    console.log('💡 Next steps:');
    console.log('   1. Run "npm run build" to build your site');
    console.log('   2. Run "npm run dev" to preview your site');
    console.log('   3. Check your blog at /blog');
  } else {
    console.log('\n❌ No content was imported. Please check the errors above.');
  }
}

// Run the import
importWordPressContent().catch(console.error);