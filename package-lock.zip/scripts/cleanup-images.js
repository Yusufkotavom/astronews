#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const IMAGES_DIR = path.join(__dirname, '../public/images/asset');

async function cleanupImages() {
  console.log('🧹 WordPress Image Cleanup');
  console.log('==========================\n');

  try {
    // Check if images directory exists
    try {
      await fs.access(IMAGES_DIR);
    } catch {
      console.log('✅ No images directory found - nothing to clean');
      return;
    }

    // Count existing images
    const files = await fs.readdir(IMAGES_DIR);
    const imageFiles = files.filter(file => 
      /\.(jpg|jpeg|png|webp|gif)$/i.test(file)
    );

    console.log(`📊 Found ${imageFiles.length} images in ${IMAGES_DIR}`);

    if (imageFiles.length === 0) {
      console.log('✅ No images to clean up');
      return;
    }

    // Show some examples
    console.log('\n📋 Sample image files:');
    imageFiles.slice(0, 5).forEach(file => {
      console.log(`   - ${file}`);
    });
    
    if (imageFiles.length > 5) {
      console.log(`   ... and ${imageFiles.length - 5} more files`);
    }

    // Calculate total size
    let totalSize = 0;
    for (const file of imageFiles) {
      const filePath = path.join(IMAGES_DIR, file);
      const stats = await fs.stat(filePath);
      totalSize += stats.size;
    }

    const totalSizeMB = (totalSize / (1024 * 1024)).toFixed(2);
    console.log(`\n💾 Total size: ${totalSizeMB} MB`);

    // Ask for confirmation
    console.log('\n⚠️  This will delete ALL images in the wordpress directory.');
    console.log('   You can re-import with optimized settings afterward.');
    
    // For now, just show what would be done
    console.log('\n🎯 Recommended next steps:');
    console.log('   1. Create .env file with optimized settings:');
    console.log('      DOWNLOAD_IMAGES=true');
    console.log('      DOWNLOAD_FEATURED_IMAGES_ONLY=true');
    console.log('      DOWNLOAD_CONTENT_IMAGES=false');
    console.log('      IMAGE_QUALITY=85');
    console.log('      IMAGE_FORMAT=webp');
    console.log('');
    console.log('   2. Run: npm run wordpress:import');
    console.log('   3. This will download only featured images (1 per post)');
    console.log('');
    console.log('📈 Expected results:');
    console.log(`   - Current: ${imageFiles.length} images (${totalSizeMB} MB)`);
    console.log(`   - After cleanup: ~${Math.ceil(imageFiles.length / 10)} images (much smaller)`);

  } catch (error) {
    console.error('❌ Error during cleanup:', error.message);
  }
}

// Run cleanup
cleanupImages().catch(console.error); 