import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Function to clean WordPress CSS classes
function cleanWordPressCSS(html) {
  if (!html) return '';
  
  // Replace WordPress-specific CSS classes with Tailwind equivalents
  html = html.replace(/class="([^"]*?)gemini-blue([^"]*?)"/g, 'class="$1text-blue-600$2"');
  html = html.replace(/class="([^"]*?)gemini-yellow([^"]*?)"/g, 'class="$1text-yellow-500$2"');
  html = html.replace(/class="([^"]*?)gemini-green([^"]*?)"/g, 'class="$1text-green-500$2"');
  html = html.replace(/class="([^"]*?)gemini-purple([^"]*?)"/g, 'class="$1text-purple-500$2"');
  
  // Replace background classes
  html = html.replace(/class="([^"]*?)bg-gemini-blue([^"]*?)"/g, 'class="$1bg-blue-600$2"');
  html = html.replace(/class="([^"]*?)bg-gemini-yellow([^"]*?)"/g, 'class="$1bg-yellow-500$2"');
  html = html.replace(/class="([^"]*?)bg-gemini-green([^"]*?)"/g, 'class="$1bg-green-500$2"');
  html = html.replace(/class="([^"]*?)bg-gemini-purple([^"]*?)"/g, 'class="$1bg-purple-500$2"');
  
  // Replace text classes
  html = html.replace(/class="([^"]*?)text-gemini-blue([^"]*?)"/g, 'class="$1text-blue-600$2"');
  html = html.replace(/class="([^"]*?)text-gemini-yellow([^"]*?)"/g, 'class="$1text-yellow-500$2"');
  html = html.replace(/class="([^"]*?)text-gemini-green([^"]*?)"/g, 'class="$1text-green-500$2"');
  html = html.replace(/class="([^"]*?)text-gemini-purple([^"]*?)"/g, 'class="$1text-purple-500$2"');
  
  // Replace hover classes
  html = html.replace(/class="([^"]*?)hover:text-gemini-blue([^"]*?)"/g, 'class="$1hover:text-blue-600$2"');
  html = html.replace(/class="([^"]*?)hover:text-gemini-purple([^"]*?)"/g, 'class="$1hover:text-purple-600$2"');
  html = html.replace(/class="([^"]*?)hover:bg-gemini-blue([^"]*?)"/g, 'class="$1hover:bg-blue-700$2"');
  html = html.replace(/class="([^"]*?)hover:bg-gemini-yellow([^"]*?)"/g, 'class="$1hover:bg-yellow-600$2"');
  html = html.replace(/class="([^"]*?)hover:bg-gemini-green([^"]*?)"/g, 'class="$1hover:bg-green-600$2"');
  html = html.replace(/class="([^"]*?)hover:bg-gemini-purple([^"]*?)"/g, 'class="$1hover:bg-purple-600$2"');
  
  // Replace dashicons with emojis
  html = html.replace(/<span class="dashicons dashicons-book-alt[^"]*"><\/span>/g, '📚');
  html = html.replace(/<span class="dashicons dashicons-money-alt[^"]*"><\/span>/g, '💰');
  html = html.replace(/<span class="dashicons dashicons-media-text[^"]*"><\/span>/g, '📄');
  html = html.replace(/<span class="dashicons dashicons-book[^"]*"><\/span>/g, '📖');
  html = html.replace(/<span class="dashicons dashicons-format-image[^"]*"><\/span>/g, '🖼️');
  html = html.replace(/<span class="dashicons dashicons-shield-alt[^"]*"><\/span>/g, '🛡️');
  
  // Replace rh-icon classes with emojis
  html = html.replace(/<i class="rh-icon rh-25-lightbulb[^"]*"><\/i>/g, '💡');
  html = html.replace(/<i class="rh-icon rh-98-money[^"]*"><\/i>/g, '💵');
  html = html.replace(/<i class="rh-icon rh-33-truck[^"]*"><\/i>/g, '🚚');
  
  return html;
}

// Function to process a single markdown file
function processMarkdownFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    
    // Split frontmatter and content
    const frontmatterEnd = content.indexOf('---', 3);
    if (frontmatterEnd === -1) {
      console.log(`No frontmatter found in ${filePath}`);
      return;
    }
    
    const frontmatter = content.substring(0, frontmatterEnd + 3);
    let htmlContent = content.substring(frontmatterEnd + 3);
    
    // Clean the HTML content
    const cleanedContent = cleanWordPressCSS(htmlContent);
    
    // Write back to file
    const newContent = frontmatter + cleanedContent;
    fs.writeFileSync(filePath, newContent, 'utf8');
    
    console.log(`✅ Fixed: ${path.basename(filePath)}`);
  } catch (error) {
    console.error(`❌ Error processing ${filePath}:`, error.message);
  }
}

// Function to process all markdown files in a directory
function processDirectory(dirPath) {
  try {
    const files = fs.readdirSync(dirPath);
    
    files.forEach(file => {
      if (file.endsWith('.md')) {
        const filePath = path.join(dirPath, file);
        processMarkdownFile(filePath);
      }
    });
    
    console.log(`\n🎉 Completed processing ${dirPath}`);
  } catch (error) {
    console.error(`❌ Error processing directory ${dirPath}:`, error.message);
  }
}

// Main function
async function fixWordPressCSS() {
  console.log('🔧 Fixing WordPress CSS classes in imported content...\n');
  
  const postsDir = path.join(__dirname, '../src/content/post');
  const pagesDir = path.join(__dirname, '../src/content/page');
  
  // Process posts
  if (fs.existsSync(postsDir)) {
    console.log('📝 Processing posts...');
    processDirectory(postsDir);
  }
  
  // Process pages
  if (fs.existsSync(pagesDir)) {
    console.log('\n📄 Processing pages...');
    processDirectory(pagesDir);
  }
  
  console.log('\n✨ WordPress CSS fix completed!');
  console.log('💡 New imports will automatically use the updated cleaning function.');
}

// Run the script
fixWordPressCSS().catch(console.error); 