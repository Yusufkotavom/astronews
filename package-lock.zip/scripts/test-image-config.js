#!/usr/bin/env node

import { WORDPRESS_CONFIG } from './wordpress-config.js';

console.log('🧪 Image Configuration Test');
console.log('===========================\n');

console.log('📋 Current Configuration:');
console.log(`   DOWNLOAD_IMAGES: ${WORDPRESS_CONFIG.DOWNLOAD_IMAGES}`);
console.log(`   KEEP_ORIGINAL_URLS: ${WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS}`);
console.log(`   DOWNLOAD_FEATURED_IMAGES_ONLY: ${WORDPRESS_CONFIG.DOWNLOAD_FEATURED_IMAGES_ONLY}`);
console.log(`   DOWNLOAD_CONTENT_IMAGES: ${WORDPRESS_CONFIG.DOWNLOAD_CONTENT_IMAGES}`);

console.log('\n🎯 Behavior:');
if (WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS) {
  console.log('   ✅ Will keep short WordPress URLs');
  console.log('   ✅ No local image downloads');
  console.log('   ✅ Images will point to: /wp-content/uploads/...');
} else if (WORDPRESS_CONFIG.DOWNLOAD_IMAGES) {
  if (WORDPRESS_CONFIG.DOWNLOAD_FEATURED_IMAGES_ONLY) {
    console.log('   ✅ Will download only featured images');
    console.log('   ✅ Content images will be skipped');
  } else if (WORDPRESS_CONFIG.DOWNLOAD_CONTENT_IMAGES) {
    console.log('   ✅ Will download all images (featured + content)');
  } else {
    console.log('   ✅ Will download featured images only');
  }
  console.log('   ✅ Images will be stored in: public/images/asset/');
} else {
  console.log('   ✅ No images will be downloaded');
  console.log('   ✅ No image URLs will be processed');
}

console.log('\n💡 To change configuration:');
console.log('   1. Create .env file in project root');
console.log('   2. Add your preferred settings');
console.log('   3. Run: npm run wordpress:import');

console.log('\n📚 See docs/IMAGE_CONFIGURATION.md for all options'); 