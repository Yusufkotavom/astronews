#!/usr/bin/env python3
"""
Script to replace broken images with random images from collection
Usage: python scripts/replace_broken_with_random.py
"""

import os
import re
import random
import shutil
from pathlib import Path

def get_random_image_from_collection(images_dir):
    """Get a random image from the collection"""
    image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'}
    image_files = []
    
    for img_file in images_dir.iterdir():
        if img_file.is_file() and img_file.suffix.lower() in image_extensions:
            image_files.append(img_file.name)
    
    if not image_files:
        return None
    
    return random.choice(image_files)

def replace_broken_images():
    """Replace broken images with random images from collection"""
    
    # Paths
    content_dir = Path("src/content/post")
    pages_dir = Path("src/content/page")
    images_dir = Path("public/images/asset")
    
    print("🔄 Replacing broken images with random images from collection...")
    print("=" * 70)
    
    # Collect all content files
    content_files = []
    if content_dir.exists():
        content_files.extend(content_dir.glob("*.mdx"))
        content_files.extend(content_dir.glob("*.md"))
    if pages_dir.exists():
        content_files.extend(pages_dir.glob("*.mdx"))
        content_files.extend(pages_dir.glob("*.md"))
    
    print(f"📁 Found {len(content_files)} content files to process")
    print()
    
    # Get list of existing images
    existing_images = set()
    if images_dir.exists():
        for img_file in images_dir.iterdir():
            if img_file.is_file() and img_file.suffix.lower() in {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'}:
                existing_images.add(img_file.name)
    
    print(f"📷 Found {len(existing_images)} images in collection")
    print()
    
    if not existing_images:
        print("❌ No images found in collection!")
        return
    
    # Track replacements
    total_replacements = 0
    files_modified = 0
    
    # Check each content file
    for content_file in content_files:
        print(f"📄 Processing: {content_file.name}")
        
        try:
            with open(content_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            file_replacements = 0
            
            # Find all image references that need replacement
            image_patterns = [
                (r'/images/asset/([^"\s]+)', 'local'),  # Local image references
                (r'https?://[^"\s]+\.(?:jpg|jpeg|png|gif|webp|svg)', 'external'),  # External URLs
                (r'/wp-content/uploads/([^"\s]+)', 'wordpress')  # WordPress uploads
            ]
            
            for pattern, img_type in image_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches:
                    if img_type == 'local':
                        # Check if local image exists
                        image_name = match
                        if image_name not in existing_images:
                            # Replace with random image
                            random_image = get_random_image_from_collection(images_dir)
                            if random_image:
                                content = content.replace(
                                    f'/images/asset/{image_name}',
                                    f'/images/asset/{random_image}'
                                )
                                file_replacements += 1
                                print(f"   🔄 Replaced missing local: {image_name} → {random_image}")
                    else:
                        # Replace external/WordPress URLs with random image
                        random_image = get_random_image_from_collection(images_dir)
                        if random_image:
                            if img_type == 'external':
                                content = content.replace(
                                    match,
                                    f'/images/asset/{random_image}'
                                )
                                file_replacements += 1
                                print(f"   🔄 Replaced external URL: {match[:50]}... → {random_image}")
                            elif img_type == 'wordpress':
                                content = content.replace(
                                    f'/wp-content/uploads/{match}',
                                    f'/images/asset/{random_image}'
                                )
                                file_replacements += 1
                                print(f"   🔄 Replaced WordPress upload: {match} → {random_image}")
            
            # Save file if changes were made
            if content != original_content:
                with open(content_file, 'w', encoding='utf-8') as f:
                    f.write(content)
                files_modified += 1
                total_replacements += file_replacements
                print(f"   ✅ Modified file with {file_replacements} replacements")
            else:
                print(f"   ✅ No replacements needed")
                
        except Exception as e:
            print(f"   ❌ Error processing file: {e}")
    
    print()
    print("📊 SUMMARY")
    print("=" * 70)
    print(f"📁 Content files processed: {len(content_files)}")
    print(f"📄 Files modified: {files_modified}")
    print(f"🔄 Total image replacements: {total_replacements}")
    print(f"📷 Images in collection: {len(existing_images)}")
    print()
    
    if total_replacements > 0:
        print("✅ Successfully replaced broken images with random images from collection!")
        print("💡 All broken images now point to working images in your collection.")
    else:
        print("✅ No broken images found to replace!")

def main():
    replace_broken_images()

if __name__ == "__main__":
    main() 