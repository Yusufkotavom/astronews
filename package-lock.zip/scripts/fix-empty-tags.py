#!/usr/bin/env python3
import os
import re
import glob

def fix_empty_tags():
    """Fix empty tags fields in markdown files"""
    content_dir = "src/content/post"
    
    # Find all markdown files
    md_files = glob.glob(os.path.join(content_dir, "*.md"))
    
    fixed_count = 0
    
    for file_path in md_files:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check if file has empty tags field
            if re.search(r'^tags:\s*$', content, re.MULTILINE):
                # Replace empty tags with tags: []
                new_content = re.sub(r'^tags:\s*$', 'tags: []', content, flags=re.MULTILINE)
                
                # Write back to file
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                
                print(f"✅ Fixed: {os.path.basename(file_path)}")
                fixed_count += 1
            else:
                print(f"⏭️  Skipped: {os.path.basename(file_path)} (no empty tags)")
                
        except Exception as e:
            print(f"❌ Error processing {file_path}: {e}")
    
    print(f"\n🎉 Fixed {fixed_count} files with empty tags fields")

if __name__ == "__main__":
    fix_empty_tags() 