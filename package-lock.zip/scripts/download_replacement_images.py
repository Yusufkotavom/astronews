#!/usr/bin/env python3
"""
Script to download replacement images for failed downloads
Usage: python scripts/download_replacement_images.py
"""

import os
import re
import sys
import asyncio
import aiohttp
from pathlib import Path

async def download_image(session, url, filename, images_dir):
    """Download a single image"""
    try:
        async with session.get(url, timeout=30) as response:
            if response.status == 200:
                content_type = response.headers.get('content-type', '')
                if content_type.startswith('image/'):
                    content = await response.read()
                    file_path = images_dir / filename
                    with open(file_path, 'wb') as f:
                        f.write(content)
                    print(f"✅ Downloaded: {filename}")
                    return True
                else:
                    print(f"❌ Not an image: {url} ({content_type})")
                    return False
            else:
                print(f"❌ HTTP {response.status}: {url}")
                return False
    except Exception as e:
        print(f"❌ Error downloading {url}: {e}")
        return False

async def download_replacements():
    """Download replacement images"""
    
    images_dir = Path("public/images/asset")
    replacement_file = Path("failed_images_to_replace.txt")
    
    if not replacement_file.exists():
        print("❌ No replacement file found. Run check_failed_images.py first.")
        return
    
    print("🔄 Downloading replacement images...")
    print("=" * 60)
    
    # Read replacement file
    replacements = []
    with open(replacement_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Extract URLs from the file
    url_pattern = r'https?://[^\s]+\.(?:jpg|jpeg|png|gif|webp|svg)'
    urls = re.findall(url_pattern, content)
    
    if not urls:
        print("❌ No URLs found in replacement file")
        return
    
    print(f"📷 Found {len(urls)} URLs to download")
    print()
    
    # Create images directory if it doesn't exist
    images_dir.mkdir(parents=True, exist_ok=True)
    
    # Download images
    async with aiohttp.ClientSession() as session:
        tasks = []
        for i, url in enumerate(urls, 1):
            # Create filename from URL
            url_parts = url.split('/')
            original_name = url_parts[-1].split('?')[0]
            filename = f"replacement-{i:03d}-{original_name}"
            
            task = download_image(session, url, filename, images_dir)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        successful = sum(1 for r in results if r is True)
        print(f"\n📊 Downloaded {successful}/{len(urls)} images successfully")

def main():
    asyncio.run(download_replacements())

if __name__ == "__main__":
    main() 