#!/usr/bin/env node

import { WORDPRESS_CONFIG, getApiUrl } from './wordpress-config.js';

async function debugWordPressData() {
  try {
    console.log('🔍 Debugging WordPress data structure...');
    
    // Fetch a single post with embedded data
    const apiUrl = getApiUrl('/posts?per_page=1&_embed');
    console.log(`📡 API URL: ${apiUrl}`);
    
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const posts = await response.json();
    if (posts.length === 0) {
      console.log('❌ No posts found');
      return;
    }
    
    const post = posts[0];
    console.log('\n📝 Sample Post Data:');
    console.log(`Title: ${post.title.rendered}`);
    console.log(`Categories: ${JSON.stringify(post.categories)}`);
    console.log(`Tags: ${JSON.stringify(post.tags)}`);
    
    if (post._embedded) {
      console.log('\n🔗 Embedded Data:');
      
      // Check categories
      if (post._embedded['wp:term'] && post._embedded['wp:term'][0]) {
        console.log('📂 Categories:');
        post._embedded['wp:term'][0].forEach(cat => {
          console.log(`  - ${cat.name} (ID: ${cat.id}, Slug: ${cat.slug})`);
        });
      }
      
      // Check tags
      if (post._embedded['wp:term'] && post._embedded['wp:term'][1]) {
        console.log('🏷️ Tags:');
        post._embedded['wp:term'][1].forEach(tag => {
          console.log(`  - ${tag.name} (ID: ${tag.id}, Slug: ${tag.slug})`);
        });
      }
    }
    
    // Fetch all categories
    console.log('\n📂 Fetching all categories...');
    const categoriesResponse = await fetch(getApiUrl('/categories?per_page=100'));
    const categories = await categoriesResponse.json();
    console.log('Available Categories:');
    categories.forEach(cat => {
      console.log(`  - ${cat.name} (ID: ${cat.id}, Slug: ${cat.slug})`);
    });
    
    // Fetch all tags
    console.log('\n🏷️ Fetching all tags...');
    const tagsResponse = await fetch(getApiUrl('/tags?per_page=100'));
    const tags = await tagsResponse.json();
    console.log('Available Tags:');
    tags.forEach(tag => {
      console.log(`  - ${tag.name} (ID: ${tag.id}, Slug: ${tag.slug})`);
    });
    
  } catch (error) {
    console.error('❌ Error debugging WordPress data:', error.message);
  }
}

debugWordPressData(); 