#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Test configuration
const TEST_CONFIG = {
  DOMAIN: 'images.kotacom.id',
  STRATEGY: 'cdn'
};

console.log('🧪 Cloudflare Migration Test');
console.log('============================\n');

console.log('📋 Test Configuration:');
console.log(`   Domain: ${TEST_CONFIG.DOMAIN}`);
console.log(`   Strategy: ${TEST_CONFIG.STRATEGY}`);

// Sample URLs to test
const sampleUrls = [
  'https://www.kotacom.id/wp-content/uploads/2025/06/image1.jpg',
  'http://192.168.1.18:4321/wp-content/uploads/2025/06/image2.png',
  'https://kotacom.id/wp-content/uploads/2025/06/image3.webp',
  '/wp-content/uploads/2025/06/image4.jpg', // Already short
  'https://other-domain.com/wp-content/uploads/2025/06/image5.jpg'
];

console.log('\n🔄 URL Transformation Examples:');
console.log('   Before → After');

sampleUrls.forEach(url => {
  let transformedUrl = url;
  
  // Transform full URLs to Cloudflare domain
  if (url.startsWith('http')) {
    transformedUrl = url.replace(/^https?:\/\/[^\/]+/, `https://${TEST_CONFIG.DOMAIN}`);
  } else if (url.startsWith('/wp-content/uploads/')) {
    // Already in short format, just add domain
    transformedUrl = `https://${TEST_CONFIG.DOMAIN}${url}`;
  }
  
  console.log(`   ${url}`);
  console.log(`   → ${transformedUrl}`);
  console.log('');
});

// Test content transformation
const sampleContent = `
# Sample Blog Post

Here are some images:

![Image 1](https://www.kotacom.id/wp-content/uploads/2025/06/image1.jpg)

<img src="http://192.168.1.18:4321/wp-content/uploads/2025/06/image2.png" alt="Image 2">

![Image 3](/wp-content/uploads/2025/06/image3.webp)

<figure>
  <img src="https://kotacom.id/wp-content/uploads/2025/06/image4.jpg" alt="Image 4">
</figure>
`;

console.log('📝 Content Transformation Example:');
console.log('   Original content:');
console.log(sampleContent);

// Transform the content
let transformedContent = sampleContent;

// Replace full WordPress URLs
transformedContent = transformedContent.replace(
  /https:\/\/www\.kotacom\.id\/wp-content\/uploads\//gi,
  `https://${TEST_CONFIG.DOMAIN}/wp-content/uploads/`
);

// Replace any other WordPress domains
transformedContent = transformedContent.replace(
  /https?:\/\/[^\/]+\/wp-content\/uploads\//gi,
  `https://${TEST_CONFIG.DOMAIN}/wp-content/uploads/`
);

// Add domain to short URLs
transformedContent = transformedContent.replace(
  /src="\/wp-content\/uploads\//gi,
  `src="https://${TEST_CONFIG.DOMAIN}/wp-content/uploads/`
);

transformedContent = transformedContent.replace(
  /!\[([^\]]*)\]\(\/wp-content\/uploads\//gi,
  `![$1](https://${TEST_CONFIG.DOMAIN}/wp-content/uploads/`
);

console.log('\n   Transformed content:');
console.log(transformedContent);

console.log('\n✅ Test completed!');
console.log('\n📚 Next steps:');
console.log('   1. Set up Cloudflare DNS for your domain');
console.log('   2. Create .env file with your configuration');
console.log('   3. Run: npm run cloudflare:migrate');
console.log('   4. Test image loading in your browser');

console.log('\n💡 Benefits you\'ll get:');
console.log('   ✅ Faster image loading worldwide');
console.log('   ✅ Reduced server bandwidth');
console.log('   ✅ Better SEO (faster page speed)');
console.log('   ✅ Automatic image optimization');
console.log('   ✅ DDoS protection');
console.log('   ✅ SSL/TLS encryption'); 