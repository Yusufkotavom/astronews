#!/usr/bin/env node

import { WORDPRESS_CONFIG, getApiUrl } from './wordpress-config.js';

console.log('🔍 WordPress Import Debug Tool');
console.log('==============================\n');

// Check environment variables
console.log('📋 Environment Variables:');
console.log(`   WORDPRESS_SITE_URL: ${process.env.WORDPRESS_SITE_URL || 'Not set'}`);
console.log(`   DOWNLOAD_IMAGES: ${process.env.DOWNLOAD_IMAGES || 'Not set'}`);
console.log(`   KEEP_ORIGINAL_URLS: ${process.env.KEEP_ORIGINAL_URLS || 'Not set'}`);
console.log(`   DOWNLOAD_FEATURED_IMAGES_ONLY: ${process.env.DOWNLOAD_FEATURED_IMAGES_ONLY || 'Not set'}`);
console.log(`   DOWNLOAD_CONTENT_IMAGES: ${process.env.DOWNLOAD_CONTENT_IMAGES || 'Not set'}`);

console.log('\n📋 WordPress Configuration:');
console.log(`   SITE_URL: ${WORDPRESS_CONFIG.SITE_URL}`);
console.log(`   DOWNLOAD_IMAGES: ${WORDPRESS_CONFIG.DOWNLOAD_IMAGES}`);
console.log(`   KEEP_ORIGINAL_URLS: ${WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS}`);
console.log(`   DOWNLOAD_FEATURED_IMAGES_ONLY: ${WORDPRESS_CONFIG.DOWNLOAD_FEATURED_IMAGES_ONLY}`);
console.log(`   DOWNLOAD_CONTENT_IMAGES: ${WORDPRESS_CONFIG.DOWNLOAD_CONTENT_IMAGES}`);

// Test WordPress API connection
console.log('\n🔗 Testing WordPress API Connection...');

try {
  const apiUrl = getApiUrl('/posts', { per_page: '1' });
  console.log(`   API URL: ${apiUrl}`);
  
  const response = await fetch(apiUrl, {
    headers: {
      'User-Agent': 'Kotacom-Astro-Importer/1.0',
      'Accept': 'application/json'
    },
    timeout: 10000
  });
  
  if (response.ok) {
    const posts = await response.json();
    console.log(`   ✅ Connection successful! Found ${posts.length} posts`);
    
    if (posts.length > 0) {
      const post = posts[0];
      console.log(`   📄 Sample post: "${post.title.rendered}"`);
      
      // Check for featured image
      if (post._embedded && post._embedded['wp:featuredmedia']) {
        console.log(`   📷 Featured image found: ${post._embedded['wp:featuredmedia'][0].source_url}`);
      } else {
        console.log(`   ❌ No featured image found`);
      }
      
      // Check content for images
      const content = post.content.rendered;
      const imageMatches = content.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/gi);
      if (imageMatches) {
        console.log(`   📷 Content images found: ${imageMatches.length}`);
        imageMatches.forEach((match, index) => {
          const srcMatch = match.match(/src=["']([^"']+)["']/);
          if (srcMatch) {
            console.log(`      Image ${index + 1}: ${srcMatch[1]}`);
          }
        });
      } else {
        console.log(`   ❌ No content images found`);
      }
    }
  } else {
    console.log(`   ❌ Connection failed! Status: ${response.status} - ${response.statusText}`);
  }
} catch (error) {
  console.log(`   ❌ Connection error: ${error.message}`);
}

// Check image processing logic
console.log('\n🔄 Image Processing Logic:');
if (WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS) {
  console.log('   ✅ Will keep original WordPress URLs');
  console.log('   ✅ No local image downloads');
  console.log('   ✅ Images will use: /wp-content/uploads/... format');
} else if (WORDPRESS_CONFIG.DOWNLOAD_IMAGES) {
  if (WORDPRESS_CONFIG.DOWNLOAD_FEATURED_IMAGES_ONLY) {
    console.log('   ✅ Will download only featured images');
    console.log('   ✅ Content images will be skipped');
  } else if (WORDPRESS_CONFIG.DOWNLOAD_CONTENT_IMAGES) {
    console.log('   ✅ Will download all images (featured + content)');
  } else {
    console.log('   ✅ Will download featured images only');
  }
  console.log('   ✅ Images will be stored in: public/images/asset/');
} else {
  console.log('   ✅ No images will be downloaded');
  console.log('   ✅ No image URLs will be processed');
}

// Common issues and solutions
console.log('\n🔧 Common Issues & Solutions:');

console.log('\n1. Images not showing up:');
console.log('   - Check if KEEP_ORIGINAL_URLS=true in your .env file');
console.log('   - Ensure WordPress site is accessible');
console.log('   - Verify image URLs in browser');

console.log('\n2. Images downloading when you don\'t want them to:');
console.log('   - Set DOWNLOAD_IMAGES=false in your .env file');
console.log('   - Set KEEP_ORIGINAL_URLS=true in your .env file');

console.log('\n3. WordPress connection issues:');
console.log('   - Check WORDPRESS_SITE_URL in your .env file');
console.log('   - Ensure WordPress REST API is enabled');
console.log('   - Test site accessibility in browser');

console.log('\n4. Image URL format issues:');
console.log('   - Current URLs should be: /wp-content/uploads/...');
console.log('   - Full URLs will be converted to short format');
console.log('   - Check import script for URL transformation');

console.log('\n📝 Recommended .env settings for your case:');
console.log('   WORDPRESS_SITE_URL=https://kotacom.id');
console.log('   KEEP_ORIGINAL_URLS=true');
console.log('   DOWNLOAD_IMAGES=false');
console.log('   DOWNLOAD_FEATURED_IMAGES_ONLY=false');
console.log('   DOWNLOAD_CONTENT_IMAGES=false');

console.log('\n✅ Debug completed!');
console.log('\n💡 Next steps:');
console.log('   1. Check your .env file settings');
console.log('   2. Run: npm run wordpress:import');
console.log('   3. Check generated content files');
console.log('   4. Test image loading in browser'); 