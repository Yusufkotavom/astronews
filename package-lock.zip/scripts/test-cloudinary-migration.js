#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Test configuration
const TEST_CONFIG = {
  CLOUD_NAME: 'your-cloud-name',
  FOLDER: 'kotacom',
  TRANSFORMATION: 'f_auto,q_auto'
};

console.log('☁️  Cloudinary Migration Test');
console.log('=============================\n');

console.log('📋 Test Configuration:');
console.log(`   Cloud Name: ${TEST_CONFIG.CLOUD_NAME}`);
console.log(`   Folder: ${TEST_CONFIG.FOLDER}`);
console.log(`   Transformation: ${TEST_CONFIG.TRANSFORMATION}`);

// Sample URLs to test
const sampleUrls = [
  'https://www.kotacom.id/wp-content/uploads/2025/06/image1.jpg',
  'http://192.168.1.18:4321/wp-content/uploads/2025/06/image2.png',
  'https://kotacom.id/wp-content/uploads/2025/06/image3.webp',
  '/wp-content/uploads/2025/06/image4.jpg', // Already short
  'https://other-domain.com/wp-content/uploads/2025/06/image5.jpg'
];

console.log('\n🔄 URL Transformation Examples:');
console.log('   Before → After');

sampleUrls.forEach(url => {
  let transformedUrl = url;
  
  // Transform WordPress URLs to Cloudinary URLs
  if (url.includes('/wp-content/uploads/')) {
    // Extract the image path
    const imagePath = url.replace(/^https?:\/\/[^\/]+\/wp-content\/uploads\//, '');
    transformedUrl = `https://res.cloudinary.com/${TEST_CONFIG.CLOUD_NAME}/image/upload/${TEST_CONFIG.TRANSFORMATION}/${TEST_CONFIG.FOLDER}/${imagePath}`;
  }
  
  console.log(`   ${url}`);
  console.log(`   → ${transformedUrl}`);
  console.log('');
});

// Test content transformation
const sampleContent = `
# Sample Blog Post

Here are some images:

![Image 1](https://www.kotacom.id/wp-content/uploads/2025/06/image1.jpg)

<img src="http://192.168.1.18:4321/wp-content/uploads/2025/06/image2.png" alt="Image 2">

![Image 3](/wp-content/uploads/2025/06/image3.webp)

<figure>
  <img src="https://kotacom.id/wp-content/uploads/2025/06/image4.jpg" alt="Image 4">
</figure>
`;

console.log('📝 Content Transformation Example:');
console.log('   Original content:');
console.log(sampleContent);

// Transform the content
let transformedContent = sampleContent;

// Replace full WordPress URLs
transformedContent = transformedContent.replace(
  /https?:\/\/[^\/]+\/wp-content\/uploads\/([^"'\s]+)/gi,
  (match, imagePath) => {
    return `https://res.cloudinary.com/${TEST_CONFIG.CLOUD_NAME}/image/upload/${TEST_CONFIG.TRANSFORMATION}/${TEST_CONFIG.FOLDER}/${imagePath}`;
  }
);

// Replace short WordPress URLs
transformedContent = transformedContent.replace(
  /\/wp-content\/uploads\/([^"'\s]+)/gi,
  (match, imagePath) => {
    return `https://res.cloudinary.com/${TEST_CONFIG.CLOUD_NAME}/image/upload/${TEST_CONFIG.TRANSFORMATION}/${TEST_CONFIG.FOLDER}/${imagePath}`;
  }
);

console.log('\n   Transformed content:');
console.log(transformedContent);

// Show different transformation examples
console.log('\n🎨 Cloudinary Transformation Examples:');
console.log('   Basic optimization:');
console.log(`   https://res.cloudinary.com/${TEST_CONFIG.CLOUD_NAME}/image/upload/f_auto,q_auto/${TEST_CONFIG.FOLDER}/image.jpg`);

console.log('\n   Responsive thumbnail:');
console.log(`   https://res.cloudinary.com/${TEST_CONFIG.CLOUD_NAME}/image/upload/f_auto,q_auto,w_300,h_200,c_fill/${TEST_CONFIG.FOLDER}/image.jpg`);

console.log('\n   High-quality version:');
console.log(`   https://res.cloudinary.com/${TEST_CONFIG.CLOUD_NAME}/image/upload/f_auto,q_80,w_1200/${TEST_CONFIG.FOLDER}/image.jpg`);

console.log('\n   Progressive JPEG:');
console.log(`   https://res.cloudinary.com/${TEST_CONFIG.CLOUD_NAME}/image/upload/f_auto,q_auto,fl_progressive/${TEST_CONFIG.FOLDER}/image.jpg`);

console.log('\n✅ Test completed!');
console.log('\n📚 Next steps:');
console.log('   1. Sign up for Cloudinary: https://cloudinary.com/console');
console.log('   2. Get your Cloud Name from the dashboard');
console.log('   3. Create .env file with your configuration');
console.log('   4. Run: npm run cloudinary:migrate');
console.log('   5. Test image loading in your browser');

console.log('\n💡 Benefits you\'ll get:');
console.log('   ✅ Automatic WebP/AVIF format selection');
console.log('   ✅ Automatic quality optimization');
console.log('   ✅ Global CDN delivery');
console.log('   ✅ Responsive image transformations');
console.log('   ✅ Advanced image editing capabilities');
console.log('   ✅ Cost-effective pricing');

console.log('\n💰 Free Tier Includes:');
console.log('   ✅ 25 GB storage');
console.log('   ✅ 25 GB bandwidth/month');
console.log('   ✅ 25,000 transformations/month');
console.log('   ✅ All transformation features'); 