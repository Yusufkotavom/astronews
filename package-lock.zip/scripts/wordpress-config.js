// Load environment variables from .env file
import 'dotenv/config';

// WordPress Configuration
export const WORDPRESS_CONFIG = {
  // WordPress Site URL
  SITE_URL: process.env.WORDPRESS_SITE_URL || 'https://kotacom.id',
  
  // API Endpoints
  API_BASE: '/wp-json/wp/v2',
  POSTS_ENDPOINT: '/posts',
  CATEGORIES_ENDPOINT: '/categories',
  TAGS_ENDPOINT: '/tags',
  
  // API Parameters - Increased limits for better pagination
  POSTS_PER_PAGE: parseInt(process.env.WORDPRESS_POSTS_PER_PAGE) || 100,
  MAX_POSTS: parseInt(process.env.WORDPRESS_MAX_POSTS) || 10000, // Maximum posts to import
  EMBED_PARAM: '_embed',
  
  // Content Settings
  MAX_CONTENT_LENGTH: 5000,
  EXCERPT_LENGTH: 160,
  
  // Image Settings
  FEATURED_IMAGE_SIZE: 'medium',
  IMAGE_QUALITY: 80,
  
  // NEW: Image Download Control
  DOWNLOAD_IMAGES: process.env.DOWNLOAD_IMAGES === 'true' || false, // Don't download images by default
  DOWNLOAD_FEATURED_IMAGES_ONLY: process.env.DOWNLOAD_FEATURED_IMAGES_ONLY === 'true' || false, // Keep original URLs
  DOWNLOAD_CONTENT_IMAGES: process.env.DOWNLOAD_CONTENT_IMAGES === 'true' || false, // Keep original URLs
  KEEP_ORIGINAL_URLS: process.env.KEEP_ORIGINAL_URLS === 'true' || false, // Keep original WordPress URLs
  IMAGE_FORMAT: process.env.IMAGE_FORMAT || 'webp',
  
  // Author Settings
  DEFAULT_AUTHOR: 'Kotacom Team',
  
  // Pagination Settings
  REQUEST_DELAY: 500, // Delay between API requests in milliseconds
  TIMEOUT: 30000, // Request timeout in milliseconds
  
  // Category Mapping (WordPress category to Astro category)
  CATEGORY_MAPPING: {
    'uncategorized': 'General',
    'uncategorized-id': 'General',
    'percetakan': 'Percetakan',
    'jasa-pembuatan-website': 'Web Development',
    'jasa': 'Jasa',
    'blog': 'Blog',
    'software': 'Software',
    'macbook': 'Macbook',
    'pc-windows': 'PC Windows',
    'service-macbook': 'Service Macbook',
    'service-komputer': 'Service Komputer',
    'service-laptop-surabaya': 'Service Laptop',
    'service-pc-surabaya': 'Service PC',
    'jasa-recovery-data': 'Recovery Data',
    'recovery-data': 'Recovery Data',
    'jasa-install-software-windows': 'Install Software',
    'windows': 'Windows',
    'jasa-root-android': 'Android',
    'android': 'Android',
    'jasa-upgrade-ssd-macbook': 'Upgrade SSD',
    'jasa-upgrade-ssd-windows': 'Upgrade SSD',
    'pasang-cctv': 'CCTV',
    'pasang-home-karaoke': 'Karaoke',
    'karaoke': 'Karaoke',
    'home-karaoke': 'Karaoke',
    'jual-pc-karaoke': 'Karaoke',
    'pasang-peredam-suara': 'Peredam Suara',
    'rakit-pc': 'Rakit PC',
    'sewa-rental': 'Sewa Rental',
    'jual-ebook': 'Ebook',
    'jual-installer-windows': 'Installer Windows',
    'windows-original': 'Windows Original',
    'gps-tracker': 'GPS Tracker',
    'ac-service-maintain': 'AC Service',
    'ai-news': 'AI News',
    'jasa-install': 'Jasa Install',
    'jasa-isi-film-surabaya': 'Jasa Isi Film',
    'download-software': 'Download Software',
    'game': 'Game PC',
    'install-ulang-macbook': 'Install Ulang Macbook',
    'service-hardware-laptop-macbook-pc': 'Service Hardware',
    'kasir': 'Kasir'
  },
  
  // Tag Mapping
  TAG_MAPPING: {
    'jasa-cetak-buku': 'Jasa Cetak Buku',
    'percetakan': 'Percetakan',
    'website': 'Website',
    'web-development': 'Web Development',
    'seo': 'SEO',
    'marketing': 'Marketing',
    'digital-marketing': 'Digital Marketing',
    'bisnis': 'Business',
    'surabaya': 'Surabaya',
    'jakarta': 'Jakarta',
    'bandung': 'Bandung',
    'technology': 'Technology',
    'ai': 'AI',
    'software': 'Software',
    'hardware': 'Hardware',
    'macbook': 'Macbook',
    'windows': 'Windows',
    'android': 'Android',
    'service': 'Service',
    'maintenance': 'Maintenance',
    'repair': 'Repair',
    'upgrade': 'Upgrade',
    'install': 'Install',
    'recovery': 'Recovery',
    'data': 'Data',
    'cctv': 'CCTV',
    'karaoke': 'Karaoke',
    'ac': 'AC',
    'gps': 'GPS',
    'blog': 'Blog',
    'tutorial': 'Tutorial',
    'tips': 'Tips',
    'review': 'Review',
    'news': 'News',
    'artikel': 'Article',
    'berita': 'News',
    'wordpress': 'WordPress',
    'responsive-design': 'Responsive Design',
    'optimization': 'Optimization',
    'trends': 'Trends',
    'development': 'Development',
    'design': 'Design',
    'ui': 'UI',
    'ux': 'UX',
    'mobile': 'Mobile',
    'desktop': 'Desktop',
    'laptop': 'Laptop',
    'pc': 'PC',
    'server': 'Server',
    'cloud': 'Cloud',
    'security': 'Security',
    'backup': 'Backup',
    'network': 'Network',
    'internet': 'Internet',
    'online': 'Online',
    'digital': 'Digital',
    'modern': 'Modern',
    'professional': 'Professional',
    'quality': 'Quality',
    'fast': 'Fast',
    'reliable': 'Reliable',
    'affordable': 'Affordable',
    'murah': 'Murah',
    'terbaik': 'Terbaik',
    'cepat': 'Cepat',
    'aman': 'Aman',
    'terpercaya': 'Terpercaya'
  }
};

// Helper function to get full API URL
export function getApiUrl(endpoint, params = {}) {
  const url = new URL(WORDPRESS_CONFIG.API_BASE + endpoint, WORDPRESS_CONFIG.SITE_URL);
  
  // Add default parameters
  if (endpoint === WORDPRESS_CONFIG.POSTS_ENDPOINT || endpoint === '/pages') {
    url.searchParams.set('per_page', WORDPRESS_CONFIG.POSTS_PER_PAGE.toString());
    url.searchParams.set('_embed', '1');
    url.searchParams.set('status', 'publish'); // Only published content
  }
  
  // Add custom parameters
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });
  
  return url.toString();
}

// Helper function to map WordPress category to Astro category
export function mapCategory(wordpressCategory) {
  if (!wordpressCategory) return 'General';
  const lowerCategory = wordpressCategory.toLowerCase();
  return WORDPRESS_CONFIG.CATEGORY_MAPPING[lowerCategory] || wordpressCategory;
}

// Helper function to map WordPress tags to Astro tags
export function mapTags(wordpressTags) {
  if (!wordpressTags || wordpressTags.length === 0) return [];
  return wordpressTags.map(tag => {
    if (!tag) return null;
    const lowerTag = tag.toLowerCase();
    return WORDPRESS_CONFIG.TAG_MAPPING[lowerTag] || tag;
  }).filter(tag => tag !== null);
}