#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { WORDPRESS_CONFIG } from './wordpress-config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Cloudflare Configuration
const CLOUDFLARE_CONFIG = {
  // Your Cloudflare domain (e.g., 'images.yourdomain.com' or 'yourdomain.com')
  DOMAIN: process.env.CLOUDFLARE_DOMAIN || 'images.kotacom.id',
  
  // Cloudflare Images API (if using Cloudflare Images service)
  IMAGES_API_TOKEN: process.env.CLOUDFLARE_IMAGES_API_TOKEN,
  ACCOUNT_ID: process.env.CLOUDFLARE_ACCOUNT_ID,
  
  // R2 Storage (if using Cloudflare R2)
  R2_ACCESS_KEY_ID: process.env.CLOUDFLARE_R2_ACCESS_KEY_ID,
  R2_SECRET_ACCESS_KEY: process.env.CLOUDFLARE_R2_SECRET_ACCESS_KEY,
  R2_BUCKET: process.env.CLOUDFLARE_R2_BUCKET || 'kotacom-images',
  R2_ENDPOINT: process.env.CLOUDFLARE_R2_ENDPOINT,
  
  // Migration Strategy: 'cdn', 'images', 'r2', or 'hybrid'
  STRATEGY: process.env.CLOUDFLARE_STRATEGY || 'cdn',
  
  // URL transformation
  TRANSFORM_URLS: process.env.TRANSFORM_URLS === 'true' || true,
  
  // Backup original URLs
  BACKUP_ORIGINAL: process.env.BACKUP_ORIGINAL === 'true' || true
};

console.log('☁️  Cloudflare Image Migration Tool');
console.log('===================================\n');

console.log('📋 Configuration:');
console.log(`   Domain: ${CLOUDFLARE_CONFIG.DOMAIN}`);
console.log(`   Strategy: ${CLOUDFLARE_CONFIG.STRATEGY}`);
console.log(`   Transform URLs: ${CLOUDFLARE_CONFIG.TRANSFORM_URLS}`);
console.log(`   Backup Original: ${CLOUDFLARE_CONFIG.BACKUP_ORIGINAL}`);

// Strategy 1: CDN Proxy (Simplest - just change domain)
async function migrateToCDN() {
  console.log('\n🔄 Strategy: CDN Proxy');
  console.log('   This will change image URLs to use your Cloudflare domain');
  console.log('   Example: https://www.kotacom.id/wp-content/uploads/... → https://images.kotacom.id/wp-content/uploads/...');
  
  const contentDir = path.join(__dirname, '../src/content');
  const files = await getAllMdxFiles(contentDir);
  
  console.log(`\n📁 Found ${files.length} content files to process`);
  
  let processedCount = 0;
  let imageCount = 0;
  
  for (const file of files) {
    const content = await fs.readFile(file, 'utf-8');
    const originalContent = content;
    
    // Replace WordPress domain with Cloudflare domain
    const newContent = content.replace(
      /https:\/\/www\.kotacom\.id\/wp-content\/uploads\//gi,
      `https://${CLOUDFLARE_CONFIG.DOMAIN}/wp-content/uploads/`
    );
    
    // Also replace any other WordPress domains
    const newContent2 = newContent.replace(
      /https?:\/\/[^\/]+\/wp-content\/uploads\//gi,
      `https://${CLOUDFLARE_CONFIG.DOMAIN}/wp-content/uploads/`
    );
    
    if (newContent2 !== originalContent) {
      await fs.writeFile(file, newContent2);
      processedCount++;
      
      // Count images
      const imageMatches = newContent2.match(/https:\/\/[^\/]+\/wp-content\/uploads\//gi);
      if (imageMatches) {
        imageCount += imageMatches.length;
      }
    }
  }
  
  console.log(`✅ Processed ${processedCount} files`);
  console.log(`📷 Updated ${imageCount} image URLs`);
  console.log(`🌐 Images now point to: https://${CLOUDFLARE_CONFIG.DOMAIN}/wp-content/uploads/...`);
}

// Strategy 2: Cloudflare Images (Upload to Cloudflare Images service)
async function migrateToCloudflareImages() {
  console.log('\n🔄 Strategy: Cloudflare Images');
  console.log('   This will upload images to Cloudflare Images service');
  console.log('   Requires Cloudflare Images API token');
  
  if (!CLOUDFLARE_CONFIG.IMAGES_API_TOKEN || !CLOUDFLARE_CONFIG.ACCOUNT_ID) {
    console.log('❌ Error: CLOUDFLARE_IMAGES_API_TOKEN and CLOUDFLARE_ACCOUNT_ID required');
    return;
  }
  
  // Implementation would go here
  console.log('⚠️  Cloudflare Images migration not yet implemented');
  console.log('   This requires downloading images and uploading to Cloudflare Images API');
}

// Strategy 3: R2 Storage (Upload to Cloudflare R2)
async function migrateToR2() {
  console.log('\n🔄 Strategy: Cloudflare R2');
  console.log('   This will upload images to Cloudflare R2 storage');
  console.log('   Requires R2 access keys');
  
  if (!CLOUDFLARE_CONFIG.R2_ACCESS_KEY_ID || !CLOUDFLARE_CONFIG.R2_SECRET_ACCESS_KEY) {
    console.log('❌ Error: R2 access keys required');
    return;
  }
  
  // Implementation would go here
  console.log('⚠️  R2 migration not yet implemented');
  console.log('   This requires downloading images and uploading to R2');
}

// Helper function to get all MDX files
async function getAllMdxFiles(dir) {
  const files = [];
  
  async function scanDirectory(currentDir) {
    const items = await fs.readdir(currentDir, { withFileTypes: true });
    
    for (const item of items) {
      const fullPath = path.join(currentDir, item.name);
      
      if (item.isDirectory()) {
        await scanDirectory(fullPath);
      } else if (item.name.endsWith('.md') || item.name.endsWith('.mdx')) {
        files.push(fullPath);
      }
    }
  }
  
  await scanDirectory(dir);
  return files;
}

// Main migration function
async function runMigration() {
  console.log('\n🚀 Starting migration...\n');
  
  switch (CLOUDFLARE_CONFIG.STRATEGY) {
    case 'cdn':
      await migrateToCDN();
      break;
    case 'images':
      await migrateToCloudflareImages();
      break;
    case 'r2':
      await migrateToR2();
      break;
    default:
      console.log('❌ Unknown strategy. Use: cdn, images, or r2');
  }
  
  console.log('\n✅ Migration completed!');
  console.log('\n📚 Next steps:');
  console.log('   1. Set up Cloudflare DNS for your domain');
  console.log('   2. Configure Cloudflare proxy (orange cloud)');
  console.log('   3. Test image loading');
  console.log('   4. Monitor performance in Cloudflare dashboard');
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runMigration().catch(console.error);
}

export { runMigration, CLOUDFLARE_CONFIG }; 