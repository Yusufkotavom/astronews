#!/usr/bin/env node

import { getCollection } from 'astro:content';

async function debugSearch() {
  console.log('🔍 Debugging Search Functionality');
  console.log('==================================\n');

  try {
    // Test 1: Get all posts
    console.log('📝 Test 1: Getting all posts...');
    const allPosts = await getCollection('post');
    console.log(`✅ Found ${allPosts.length} posts`);
    
    if (allPosts.length > 0) {
      console.log('📋 Sample posts:');
      allPosts.slice(0, 3).forEach((post, index) => {
        console.log(`   ${index + 1}. "${post.data.title}" (${post.slug})`);
        console.log(`      Description: ${post.data.description?.substring(0, 100)}...`);
        console.log(`      Category: ${post.data.category}`);
        console.log(`      Tags: ${post.data.tags?.join(', ') || 'None'}`);
        console.log('');
      });
    }

    // Test 2: Get all pages
    console.log('📄 Test 2: Getting all pages...');
    const allPages = await getCollection('page');
    console.log(`✅ Found ${allPages.length} pages`);
    
    if (allPages.length > 0) {
      console.log('📋 Sample pages:');
      allPages.slice(0, 3).forEach((page, index) => {
        console.log(`   ${index + 1}. "${page.data.title}" (${page.slug})`);
        console.log(`      Description: ${page.data.description?.substring(0, 100)}...`);
        console.log('');
      });
    }

    // Test 3: Search functionality test
    console.log('🔍 Test 3: Testing search functionality...');
    const searchQuery = 'windows';
    
    const postResults = allPosts.filter((post) => {
      const title = post.data.title?.toLowerCase() || '';
      const description = post.data.description?.toLowerCase() || '';
      const content = post.body?.toLowerCase() || '';
      const category = post.data.category?.toLowerCase() || '';
      const tags = post.data.tags?.join(' ').toLowerCase() || '';
      const author = post.data.author?.toLowerCase() || '';
      const searchTerm = searchQuery.toLowerCase();
      
      return title.includes(searchTerm) || 
             description.includes(searchTerm) || 
             content.includes(searchTerm) ||
             category.includes(searchTerm) ||
             tags.includes(searchTerm) ||
             author.includes(searchTerm);
    });

    console.log(`✅ Found ${postResults.length} posts matching "${searchQuery}"`);
    
    if (postResults.length > 0) {
      console.log('📋 Matching posts:');
      postResults.forEach((post, index) => {
        console.log(`   ${index + 1}. "${post.data.title}"`);
      });
    }

    // Test 4: Test different search terms
    console.log('\n🔍 Test 4: Testing different search terms...');
    const testTerms = ['website', 'service', 'blog', 'contact', 'windows', 'sticky'];
    
    testTerms.forEach(term => {
      const results = allPosts.filter((post) => {
        const title = post.data.title?.toLowerCase() || '';
        const description = post.data.description?.toLowerCase() || '';
        const content = post.body?.toLowerCase() || '';
        const searchTerm = term.toLowerCase();
        
        return title.includes(searchTerm) || 
               description.includes(searchTerm) || 
               content.includes(searchTerm);
      });
      
      console.log(`   "${term}": ${results.length} results`);
    });

    console.log('\n✅ Search functionality test completed!');
    console.log('\n💡 If you see results above, the search should work.');
    console.log('💡 If no results, check the content files and search implementation.');

  } catch (error) {
    console.error('❌ Error during search test:', error);
  }
}

// Run the debug function
debugSearch().catch(console.error); 