#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { WORDPRESS_CONFIG } from './wordpress-config.js';
import cloudinary from 'cloudinary';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configure Cloudinary
cloudinary.v2.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

// Cloudinary Configuration
const CLOUDINARY_CONFIG = {
  // Cloudinary credentials
  CLOUD_NAME: process.env.CLOUDINARY_CLOUD_NAME,
  API_KEY: process.env.CLOUDINARY_API_KEY,
  API_SECRET: process.env.CLOUDINARY_API_SECRET,
  
  // Upload settings
  FOLDER: process.env.CLOUDINARY_FOLDER || 'kotacom',
  TRANSFORMATION: process.env.CLOUDINARY_TRANSFORMATION || 'f_auto,q_auto',
  
  // Migration Strategy: 'upload' or 'url-only'
  STRATEGY: process.env.CLOUDINARY_STRATEGY || 'upload',
  
  // URL transformation
  TRANSFORM_URLS: process.env.TRANSFORM_URLS === 'true' || true,
  
  // Backup original URLs
  BACKUP_ORIGINAL: process.env.BACKUP_ORIGINAL === 'true' || true
};

console.log('☁️  Cloudinary Image Migration Tool');
console.log('===================================\n');

console.log('📋 Configuration:');
console.log(`   Cloud Name: ${CLOUDINARY_CONFIG.CLOUD_NAME || 'Not set'}`);
console.log(`   Strategy: ${CLOUDINARY_CONFIG.STRATEGY}`);
console.log(`   Folder: ${CLOUDINARY_CONFIG.FOLDER}`);
console.log(`   Transformation: ${CLOUDINARY_CONFIG.TRANSFORMATION}`);
console.log(`   Transform URLs: ${CLOUDINARY_CONFIG.TRANSFORM_URLS}`);

// Strategy 1: Upload to Cloudinary (Full migration)
async function migrateToCloudinary() {
  console.log('\n🔄 Strategy: Upload to Cloudinary');
  console.log('   This will download images from WordPress and upload to Cloudinary');
  
  if (!CLOUDINARY_CONFIG.CLOUD_NAME || !CLOUDINARY_CONFIG.API_KEY || !CLOUDINARY_CONFIG.API_SECRET) {
    console.log('❌ Error: CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, and CLOUDINARY_API_SECRET required');
    console.log('💡 Get these from: https://cloudinary.com/console');
    return;
  }
  
  console.log('✅ Cloudinary credentials verified');
  console.log('📁 Scanning for content files...');
  
  const contentDir = path.join(__dirname, '../src/content');
  const files = await getAllMdxFiles(contentDir);
  
  console.log(`📁 Found ${files.length} content files to process`);
  
  if (files.length === 0) {
    console.log('❌ No content files found to process');
    return;
  }
  
  let processedCount = 0;
  let imageCount = 0;
  let uploadCount = 0;
  
  console.log('🔄 Processing files...');
  
  for (const file of files) {
    try {
      const content = await fs.readFile(file, 'utf-8');
      const originalContent = content;
      
      // Find all image URLs that need replacement
      const wordpressUrlPattern = /(https?:\/\/[^\/]+\/wp-content\/uploads\/[^"'\s]+)/gi;
      const shortUrlPattern = /(\/wp-content\/uploads\/[^"'\s]+)/gi;
      const localImagePattern = /(\/images\/asset\/[^"'\s]+)/gi;
      
      let newContent = content;
      const foundImages = new Set();
      
      // Collect all image URLs
      let match;
      while ((match = wordpressUrlPattern.exec(content)) !== null) {
        foundImages.add(match[1]);
      }
      
      while ((match = shortUrlPattern.exec(content)) !== null) {
        // Convert short URL to full URL
        const fullUrl = `https://${WORDPRESS_CONFIG.SITE_URL.replace(/^https?:\/\//, '')}${match[1]}`;
        foundImages.add(fullUrl);
      }
      
      // Collect local image paths
      while ((match = localImagePattern.exec(content)) !== null) {
        foundImages.add(match[1]);
      }
      
      console.log(`📄 Processing ${file.name}: Found ${foundImages.size} images`);
      
      // Process each image
      for (const imageUrl of foundImages) {
        try {
          console.log(`   📷 Processing: ${imageUrl.substring(0, 60)}...`);
          
          let imageData;
          let originalFilename;
          
          if (imageUrl.startsWith('/images/asset/')) {
            // Local image - read from file system
            const localImagePath = path.join(__dirname, '../public', imageUrl);
            try {
              imageData = await fs.readFile(localImagePath);
              originalFilename = path.basename(imageUrl);
              console.log(`   📁 Reading local image: ${originalFilename}`);
            } catch (fileError) {
              console.log(`   ❌ Local image not found: ${imageUrl}`);
              continue;
            }
          } else {
            // External/WordPress image - download
            const response = await fetch(imageUrl, {
              headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8'
              },
              timeout: 30000
            });
            
            if (!response.ok) {
              console.log(`   ❌ Failed to download: ${response.status} ${response.statusText}`);
              continue;
            }
            
            imageData = Buffer.from(await response.arrayBuffer());
            const urlParts = imageUrl.split('/');
            originalFilename = urlParts[urlParts.length - 1].split('?')[0];
          }
          
          // Extract filename from URL
          const cloudinaryPath = `${CLOUDINARY_CONFIG.FOLDER}/${originalFilename}`;
          
          // Upload to Cloudinary using SDK
          try {
            const uploadResult = await new Promise((resolve, reject) => {
              const uploadStream = cloudinary.v2.uploader.upload_stream(
                {
                  public_id: cloudinaryPath,
                  transformation: CLOUDINARY_CONFIG.TRANSFORMATION,
                  folder: CLOUDINARY_CONFIG.FOLDER
                },
                (error, result) => {
                  if (error) {
                    reject(error);
                  } else {
                    resolve(result);
                  }
                }
              );
              
              // Pipe the image data to the upload stream
              uploadStream.end(imageData);
            });
            
            console.log(`   ✅ Uploaded: ${originalFilename} → ${uploadResult.secure_url.substring(0, 60)}...`);
            
            // Replace URL in content
            newContent = newContent.replace(new RegExp(imageUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), uploadResult.secure_url);
            
            uploadCount++;
            imageCount++;
            
          } catch (uploadError) {
            console.log(`   ❌ Upload failed: ${uploadError.message}`);
          }
          
        } catch (error) {
          console.log(`   ❌ Error processing image ${imageUrl}: ${error.message}`);
        }
      }
      
      // Save updated content
      if (newContent !== originalContent) {
        await fs.writeFile(file, newContent);
        processedCount++;
        console.log(`   ✅ Updated file with ${imageCount} image replacements`);
      } else {
        console.log(`   ✅ No changes needed`);
      }
      
    } catch (error) {
      console.log(`❌ Error processing ${file}: ${error.message}`);
    }
  }
  
  console.log(`\n📊 SUMMARY`);
  console.log(`✅ Processed ${processedCount} files`);
  console.log(`📷 Found ${imageCount} images`);
  console.log(`☁️  Uploaded ${uploadCount} images to Cloudinary`);
  console.log(`🌐 Images now point to: https://res.cloudinary.com/${CLOUDINARY_CONFIG.CLOUD_NAME}/image/upload/...`);
  
  if (uploadCount > 0) {
    console.log(`\n💡 Next steps:`);
    console.log(`   1. Check your Cloudinary dashboard: https://cloudinary.com/console`);
    console.log(`   2. Test image loading in your browser`);
    console.log(`   3. Monitor usage and costs`);
  }
}

// Strategy 2: URL Transformation (Change URLs to Cloudinary format)
async function transformToCloudinaryUrls() {
  console.log('\n🔄 Strategy: URL Transformation');
  console.log('   This will change image URLs to use Cloudinary format');
  console.log('   Example: /wp-content/uploads/image.jpg → https://res.cloudinary.com/your-cloud/image/upload/f_auto,q_auto/kotacom/image.jpg');
  
  if (!CLOUDINARY_CONFIG.CLOUD_NAME) {
    console.log('❌ Error: CLOUDINARY_CLOUD_NAME required');
    console.log('💡 Get this from: https://cloudinary.com/console');
    return;
  }
  
  console.log('📁 Scanning for content files...');
  const contentDir = path.join(__dirname, '../src/content');
  const files = await getAllMdxFiles(contentDir);
  
  console.log(`📁 Found ${files.length} content files to process`);
  
  if (files.length === 0) {
    console.log('❌ No content files found to process');
    return;
  }
  
  // For testing, process only first 10 files
  const filesToProcess = files.slice(0, 10);
  console.log(`🧪 Processing first ${filesToProcess.length} files for testing...`);
  
  let processedCount = 0;
  let imageCount = 0;
  
  console.log('🔄 Processing files...');
  for (const file of filesToProcess) {
    try {
      const content = await fs.readFile(file, 'utf-8');
      const originalContent = content;
      
      // Transform WordPress URLs to Cloudinary URLs
      let newContent = content;
      
      // Replace full WordPress URLs
      newContent = newContent.replace(
        /https?:\/\/[^\/]+\/wp-content\/uploads\/([^"'\s]+)/gi,
        (match, imagePath) => {
          const cloudinaryUrl = `https://res.cloudinary.com/${CLOUDINARY_CONFIG.CLOUD_NAME}/image/upload/${CLOUDINARY_CONFIG.TRANSFORMATION}/${CLOUDINARY_CONFIG.FOLDER}/${imagePath}`;
          return cloudinaryUrl;
        }
      );
      
      // Replace short WordPress URLs
      newContent = newContent.replace(
        /\/wp-content\/uploads\/([^"'\s]+)/gi,
        (match, imagePath) => {
          const cloudinaryUrl = `https://res.cloudinary.com/${CLOUDINARY_CONFIG.CLOUD_NAME}/image/upload/${CLOUDINARY_CONFIG.TRANSFORMATION}/${CLOUDINARY_CONFIG.FOLDER}/${imagePath}`;
          return cloudinaryUrl;
        }
      );
      
      if (newContent !== originalContent) {
        await fs.writeFile(file, newContent);
        processedCount++;
        
        // Count images
        const imageMatches = newContent.match(/https:\/\/res\.cloudinary\.com\/[^\/]+\/image\/upload/g);
        if (imageMatches) {
          imageCount += imageMatches.length;
        }
      }
    } catch (error) {
      console.log(`❌ Error processing ${file}: ${error.message}`);
    }
  }
  
  console.log(`✅ Processed ${processedCount} files`);
  console.log(`📷 Updated ${imageCount} image URLs`);
  console.log(`🌐 Images now point to: https://res.cloudinary.com/${CLOUDINARY_CONFIG.CLOUD_NAME}/image/upload/...`);
}

// Helper function to get all MDX files
async function getAllMdxFiles(dir) {
  const files = [];
  
  async function scanDirectory(currentDir) {
    const items = await fs.readdir(currentDir, { withFileTypes: true });
    
    for (const item of items) {
      const fullPath = path.join(currentDir, item.name);
      
      if (item.isDirectory()) {
        await scanDirectory(fullPath);
      } else if (item.name.endsWith('.md') || item.name.endsWith('.mdx')) {
        files.push(fullPath);
      }
    }
  }
  
  await scanDirectory(dir);
  return files;
}

// Main migration function
async function runMigration() {
  console.log('\n🚀 Starting migration...\n');
  
  try {
    switch (CLOUDINARY_CONFIG.STRATEGY) {
      case 'upload':
        console.log('📤 Using upload strategy...');
        await migrateToCloudinary();
        break;
      case 'url-only':
        console.log('🔗 Using url-only strategy...');
        await transformToCloudinaryUrls();
        break;
      default:
        console.log('❌ Unknown strategy. Use: upload or url-only');
    }
    
    console.log('\n✅ Migration completed!');
    console.log('\n📚 Next steps:');
    console.log('   1. Test image loading in your browser');
    console.log('   2. Monitor Cloudinary dashboard for usage');
    console.log('   3. Optimize transformations as needed');
    console.log('   4. Set up Cloudinary webhooks if needed');
  } catch (error) {
    console.error('❌ Migration failed:', error);
  }
}

// Run if called directly
console.log('🔧 Script starting...');
console.log('🔧 Environment check:');
console.log(`   CLOUDINARY_CLOUD_NAME: ${process.env.CLOUDINARY_CLOUD_NAME || 'Not set'}`);
console.log(`   CLOUDINARY_STRATEGY: ${process.env.CLOUDINARY_STRATEGY || 'Not set'}`);
console.log('🔧 Running migration...');
runMigration().catch(console.error);

export { runMigration, CLOUDINARY_CONFIG }; 