#!/usr/bin/env node

// Load environment variables from .env file
import 'dotenv/config';

import { WORDPRESS_CONFIG, getApiUrl } from './wordpress-config.js';

console.log('🔍 WordPress + Cloudinary Setup Checker');
console.log('=======================================\n');

// Check environment variables
console.log('📋 Environment Variables Check:');
console.log(`   WORDPRESS_SITE_URL: ${process.env.WORDPRESS_SITE_URL || '❌ Not set'}`);
console.log(`   DOWNLOAD_IMAGES: ${process.env.DOWNLOAD_IMAGES || '❌ Not set'}`);
console.log(`   DOWNLOAD_FEATURED_IMAGES_ONLY: ${process.env.DOWNLOAD_FEATURED_IMAGES_ONLY || '❌ Not set'}`);
console.log(`   DOWNLOAD_CONTENT_IMAGES: ${process.env.DOWNLOAD_CONTENT_IMAGES || '❌ Not set'}`);
console.log(`   KEEP_ORIGINAL_URLS: ${process.env.KEEP_ORIGINAL_URLS || '❌ Not set'}`);
console.log(`   CLOUDINARY_CLOUD_NAME: ${process.env.CLOUDINARY_CLOUD_NAME || '❌ Not set'}`);
console.log(`   CLOUDINARY_API_KEY: ${process.env.CLOUDINARY_API_KEY ? '✅ Set' : '❌ Not set'}`);
console.log(`   CLOUDINARY_API_SECRET: ${process.env.CLOUDINARY_API_SECRET ? '✅ Set' : '❌ Not set'}`);

console.log('\n📋 WordPress Configuration:');
console.log(`   SITE_URL: ${WORDPRESS_CONFIG.SITE_URL}`);
console.log(`   DOWNLOAD_IMAGES: ${WORDPRESS_CONFIG.DOWNLOAD_IMAGES}`);
console.log(`   DOWNLOAD_FEATURED_IMAGES_ONLY: ${WORDPRESS_CONFIG.DOWNLOAD_FEATURED_IMAGES_ONLY}`);
console.log(`   DOWNLOAD_CONTENT_IMAGES: ${WORDPRESS_CONFIG.DOWNLOAD_CONTENT_IMAGES}`);
console.log(`   KEEP_ORIGINAL_URLS: ${WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS}`);

// Test WordPress API connection
console.log('\n🔗 Testing WordPress API Connection...');

try {
  const apiUrl = getApiUrl('/posts', { per_page: '1' });
  console.log(`   API URL: ${apiUrl}`);
  
  const response = await fetch(apiUrl, {
    headers: {
      'User-Agent': 'Kotacom-Astro-Importer/1.0',
      'Accept': 'application/json'
    },
    timeout: 10000
  });
  
  if (response.ok) {
    const posts = await response.json();
    console.log(`   ✅ Connection successful! Found ${posts.length} posts`);
    
    if (posts.length > 0) {
      const post = posts[0];
      console.log(`   📄 Sample post: "${post.title.rendered}"`);
      
      // Check for featured image
      if (post._embedded && post._embedded['wp:featuredmedia']) {
        console.log(`   📷 Featured image found: ${post._embedded['wp:featuredmedia'][0].source_url}`);
      } else {
        console.log(`   ❌ No featured image found`);
      }
      
      // Check content for images
      const content = post.content.rendered;
      const imageMatches = content.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/gi);
      if (imageMatches) {
        console.log(`   📷 Content images found: ${imageMatches.length}`);
        imageMatches.forEach((match, index) => {
          const srcMatch = match.match(/src=["']([^"']+)["']/);
          if (srcMatch) {
            console.log(`      Image ${index + 1}: ${srcMatch[1]}`);
          }
        });
      } else {
        console.log(`   ❌ No content images found`);
      }
    }
  } else {
    console.log(`   ❌ Connection failed! Status: ${response.status} - ${response.statusText}`);
  }
} catch (error) {
  console.log(`   ❌ Connection error: ${error.message}`);
}

// Check current configuration
console.log('\n🔄 Current Configuration Analysis:');

if (WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS) {
  console.log('   ⚠️  Currently set to KEEP original URLs');
  console.log('   ⚠️  This will NOT download images for Cloudinary migration');
} else if (WORDPRESS_CONFIG.DOWNLOAD_IMAGES) {
  if (WORDPRESS_CONFIG.DOWNLOAD_FEATURED_IMAGES_ONLY) {
    console.log('   ✅ Will download featured images only');
  } else if (WORDPRESS_CONFIG.DOWNLOAD_CONTENT_IMAGES) {
    console.log('   ✅ Will download all images (featured + content)');
  } else {
    console.log('   ✅ Will download featured images only');
  }
} else {
  console.log('   ❌ No image downloads configured');
}

// Cloudinary setup check
console.log('\n☁️  Cloudinary Setup Check:');

if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET) {
  console.log('   ✅ Cloudinary credentials found');
  console.log(`   ✅ Cloud Name: ${process.env.CLOUDINARY_CLOUD_NAME}`);
  console.log('   ✅ API Key: Set');
  console.log('   ✅ API Secret: Set');
} else {
  console.log('   ❌ Cloudinary credentials missing');
  console.log('   💡 Get them from: https://cloudinary.com/console');
}

// Recommendations
console.log('\n📝 Recommendations for Cloudinary Migration:');

console.log('\n1. Update your .env file with these settings:');
console.log('   # WordPress Configuration');
console.log('   WORDPRESS_SITE_URL=https://www.kotacom.id');
console.log('   WORDPRESS_POSTS_PER_PAGE=100');
console.log('   WORDPRESS_MAX_POSTS=10000');
console.log('');
console.log('   # Image Download (for Cloudinary migration)');
console.log('   DOWNLOAD_IMAGES=true');
console.log('   DOWNLOAD_FEATURED_IMAGES_ONLY=false');
console.log('   DOWNLOAD_CONTENT_IMAGES=true');
console.log('   KEEP_ORIGINAL_URLS=false');
console.log('');
console.log('   # Cloudinary Configuration');
console.log('   CLOUDINARY_CLOUD_NAME=dezryhhki');
console.log('   CLOUDINARY_API_KEY=313786613192279');
console.log('   CLOUDINARY_API_SECRET=MS8d8zz0BSXtStDauEKwgo');
console.log('   CLOUDINARY_FOLDER=kotacom');
console.log('   CLOUDINARY_STRATEGY=upload');

console.log('\n2. Migration Steps:');
console.log('   Step 1: Run WordPress import to download images');
console.log('   Step 2: Run Cloudinary migration to upload images');
console.log('   Step 3: Update content URLs to use Cloudinary');

console.log('\n3. Commands to run:');
console.log('   npm run wordpress:import          # Download images from WordPress');
console.log('   npm run cloudinary:migrate        # Upload to Cloudinary');
console.log('   npm run cloudinary:test-demo      # Test URL transformation');

// Issues found
console.log('\n🔧 Issues Found:');

let issues = [];

if (!process.env.WORDPRESS_SITE_URL) {
  issues.push('WORDPRESS_SITE_URL not set');
}

if (WORDPRESS_CONFIG.KEEP_ORIGINAL_URLS) {
  issues.push('KEEP_ORIGINAL_URLS=true - will not download images');
}

if (!process.env.CLOUDINARY_CLOUD_NAME) {
  issues.push('CLOUDINARY_CLOUD_NAME not set');
}

if (!process.env.CLOUDINARY_API_KEY) {
  issues.push('CLOUDINARY_API_KEY not set');
}

if (!process.env.CLOUDINARY_API_SECRET) {
  issues.push('CLOUDINARY_API_SECRET not set');
}

if (issues.length === 0) {
  console.log('   ✅ No issues found! Ready for migration.');
} else {
  console.log('   ❌ Issues found:');
  issues.forEach(issue => console.log(`      - ${issue}`));
}

console.log('\n✅ Setup check completed!');
console.log('\n💡 Next steps:');
console.log('   1. Fix any issues found above');
console.log('   2. Update your .env file with recommended settings');
console.log('   3. Run: npm run wordpress:import');
console.log('   4. Run: npm run cloudinary:migrate'); 